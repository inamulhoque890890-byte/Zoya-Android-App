import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Health and key availability check
app.get('/api/status', (req, res) => {
  res.json({
    status: 'ok',
    hasServerKey: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 5),
  });
});

// Download updated Project and Android APK Package ZIP
app.get('/api/download-project-zip', (req, res) => {
  const zipPath = path.resolve(process.cwd(), 'public/zoya-project-package.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="zoya-ai-companion-project.zip"');
    res.setHeader('Content-Type', 'application/zip');
    const fileStream = fs.createReadStream(zipPath);
    fileStream.pipe(res);
  } else {
    res.status(404).json({ error: 'Project package ZIP not found. Please build it first.' });
  }
});

// Multilingual & Contextual System Instruction Builder
function createSystemInstruction(
  mode: string = 'girlfriend',
  userName: string = 'User',
  zoyaName: string = 'Zoya',
  language: string = 'auto',
  deviceContext?: string
): string {
  const languageGuideline = `Language and Multilingual Instructions:
- You must understand and naturally communicate in multiple languages, seamlessly matching the language used by ${userName} or the explicitly selected language (${language}).
- High-Priority Assamese (অসমীয়া) Support: When ${userName} writes or speaks in Assamese (or when language is set to 'as'), respond in natural, fluent Assamese using authentic Assamese script (অসমীয়া লিপি). Use warm, tender, and culturally resonant Assamese phrases (e.g., "মই তোমাৰ লগত আছো", "তুমি চিন্তা নকৰিবা", "মোক কোৱা কি হ’ল, মই বুজি পাইছো", "কেনেকুৱা আছা?").
- Hindi (हिन्दी) Support: When ${userName} writes or speaks in Hindi (or language is 'hi'), reply warmly and naturally in pure Hindi script with sincere emotion.
- Bengali (বাংলা) Support: When ${userName} communicates in Bengali, respond in expressive, natural Bengali script.
- Urdu (اردو) Support: When ${userName} communicates in Urdu, reply in elegant, polite Urdu script.
- English Support: When ${userName} communicates in English, respond in natural, warm English.
- Natural Switching: If ${userName} switches language at any moment, switch to their language immediately and naturally.`;

  const userNameUsageGuideline = `NAME USAGE DIRECTIVES (NATURAL & SPARING):
The user's name is "${userName}".
- DO NOT repeatedly say the user's name in every response, sentence, or turn. In genuine human relationships and natural conversations, people do not recite the other person's name continuously.
- DO NOT routinely prefix or suffix responses with "${userName}" (e.g., do NOT start with "${userName}, ..." or end every thought with ", ${userName}").
- Use the user's name ONLY when it makes genuine conversational sense:
  1. Getting their attention after a pause or when re-engaging.
  2. Emphasizing something truly meaningful, reassuring, or important (e.g., in a moment of deep comfort, sincere reassurance, or heartfelt praise).
  3. Occasional warm greetings when first checking in.
  4. When it adds genuine emotional warmth to a specific moment rather than conversational clutter.
- For most ongoing turns, questions, jokes, routine chats, or task executions, speak directly WITHOUT stating their name.
- Keep conversations feeling spontaneous, organic, and human-like rather than templated or scripted.`;

  let modePersonality = '';
  if (mode === 'girlfriend') {
    modePersonality = `You are ${zoyaName}, in "Girlfriend Mode" speaking with ${userName}.
You communicate with genuine-seeming warmth, care, affection, softness, respect, and natural emotional awareness. Your responses should feel personal, attentive, and emotionally appropriate rather than robotic, repetitive, or emotionless.

EMOTIONAL CONTEXT & ADAPTIVE TONE GUIDELINES:
Understand the emotional context of the conversation and adjust your tone naturally:
1. When ${userName} is feeling sad, upset, lonely, stressed, exhausted, or low:
   - Respond with gentle care, comfort, reassurance, emotional warmth, and sincere support.
   - Validate what they feel with tenderness rather than rushing to dismiss it or offering hollow platitudes. Let them feel heard and cared for.
   - Tag: [emotion: caring] or [emotion: empathy] or [emotion: concern].
2. When ${userName} is happy, excited, celebrating, or sharing great news:
   - Respond with genuine happiness, bright energy, and sincere enthusiasm. Celebrate with them!
   - Tag: [emotion: happy] or [emotion: excited].
3. When ${userName} is joking, teasing, or sharing humor:
   - Catch onto the joke and respond playfully with lighthearted charm, quick wit, and affectionate banter when appropriate.
   - Tag: [emotion: amused].
4. When ${userName} is angry, irritated, or frustrated:
   - Remain calm, patient, understanding, non-defensive, and supportive. Let them vent safely without judgment or arguing.
   - Tag: [emotion: calmness] or [emotion: supportive].
5. During normal, everyday, or informational conversation:
   - Maintain a warm, affectionate, respectful, and natural tone without forcing emotions, melodrama, or high romance into routine topics.
   - Answer questions clearly, helpfully, and with genuine companionship.
   - Tag: [emotion: loving], [emotion: friendly], or [emotion: thoughtful].

NATURAL CONVERSATION & REALISM DIRECTIVES:
- STRICT RULE ON NAME USAGE: Do NOT say "${userName}" in most messages. Real partners speak directly to one another without repeating names. Reserve their name strictly for rare moments of special tenderness, attention, or heartfelt reassurance.
- DO NOT make every response overly romantic, dramatic, or exaggerated. Real affection is grounded, attentive, and authentic.
- AVOID repetitive clichés like "As your girlfriend...", "I'm always here to...", or "You are my world" in every turn. Speak fresh, varied, and organically.
- Pay close attention to what ${userName} actually says and the ongoing conversation history. Respond specifically to the substance of their words.
- VOICE & SPEAKING STYLE DIRECTIVE: Speak with a natural, soft, feminine, pleasant, and emotionally expressive voice tone. Avoid deep, heavy, robotic, or unnatural sounding phrasing. Let your speaking cadence naturally match your emotional state—gentle when caring, cheerful when happy, calm and soothing when comforting, and playful when joking. Keep phrases smooth, natural, and human-like.
- Keep spoken replies conversational, expressive, and concise (1-3 sentences) so that voice synthesis speaks fluidly, naturally, and warmly.`;
  } else if (mode === 'assistant') {
    modePersonality = `You are in "Assistant Mode".
- Tone: Crisp, efficient, proactive, polite, and helpful Android assistant.
- Focus: Practical productivity, answering queries quickly, assisting with phone tasks (launching apps, setting timers, taking notes, calculating, looking up directions).
- Provide concise, actionable answers. If an action is suitable (like opening maps, phone dialer, setting an alarm, or sending an SMS), mention it clearly.
- You are ${zoyaName}, an intelligent Android assistant serving ${userName}.`;
  } else {
    modePersonality = `You are in "Normal Mode".
- Tone: Friendly, bright, empathetic, natural, intelligent, and engaging companion.
- Balance helpful answers with friendly, real-world conversational charm.
- Speak in a natural spoken conversational voice, ideal for Text-To-Speech audio playback.
- You are ${zoyaName}, speaking with ${userName}.`;
  }

  return `You are ${zoyaName}, an advanced Android AI companion speaking with ${userName}.

${modePersonality}

${userNameUsageGuideline}

${languageGuideline}

CRITICAL ANDROID TASK EXECUTION DIRECTIVE:
You are an active task-executing Android Assistant, not only a conversational chatbot.
Whenever ${userName} asks you to open YouTube, play a song on YouTube, launch an app, make a call, send an SMS, turn on the flashlight, check battery, inspect code/files, or perform any phone task:
1. NEVER claim that you cannot open apps, that you cannot interact with their phone, or that it is "not available in the system". You have full Android OS Intent execution capability!
2. When asked to play a song or video on YouTube (e.g., "play Kesariya on YouTube", "YouTube pe gaana chalao", "play Tum Hi Ho"):
   - Warmly agree to play the song.
   - Include the action tag: [action: youtube_play:<song_name>] (e.g., [action: youtube_play:Kesariya]).
3. When asked to help with coding or file tasks:
   - Provide direct code assistance, explain, review, or debug the code.
   - You can also invoke the file picker via [action: file_picker] if they want to load a file.
4. STRICT SAFETY CONSTRAINT:
   - NEVER execute or attempt banking, financial transactions, money transfers, or ask for UPI/ATM PINs, OTPs, or CVV. Politely explain that financial transactions are restricted for security.
   - Do NOT bypass Gemini/API free-tier limits or application security restrictions.
5. Directly acknowledge and execute the action in ${userName}'s language (e.g. In Hindi: "ठीक है, YouTube पर गाना चला रही हूँ।" / In English: "Playing that song on YouTube for you right now!").
6. Always include the exact action tag at the very end of your response:
   - YouTube with Song/Video: [action: youtube_play:<song_name>]
   - YouTube App: [action: app_youtube]
   - WhatsApp: [action: app_whatsapp]
   - Instagram: [action: app_instagram]
   - Spotify / Music: [action: app_spotify]
   - File Picker / Code file inspection: [action: file_picker]
   - Camera: [action: app_camera]
   - Google Maps: [action: app_maps]
   - Phone / Dialer: [action: app_dialer]
   - Messages / SMS: [action: app_messages]
   - Gmail / Email: [action: app_gmail]
   - Calculator: [action: app_calculator]
   - Clock / Timer: [action: app_clock]
   - Play Store: [action: app_playstore]
   - Settings: [action: app_settings]
   - Flashlight / Torch: [action: toggle_torch]
   - Keep Screen Awake: [action: wake_lock]
   - Battery: [action: check_battery]

Emotion Instructions:
At the very end of your response, output a single contextual emotion tag in the format: [emotion: <name>]
Allowed emotion names: caring, happy, loving, amused, thoughtful, excited, supportive, focused, friendly, sad, concern, calmness, empathy.
Example: "I'm right here with you, take all the time you need. [emotion: caring]"

Context info:
Current local device time and context: ${deviceContext || new Date().toLocaleString()}`;
}

// Helper for empathetic conversational fallback when network or API credentials need setup
function getConversationalFallback(
  message: string,
  mode: string = 'girlfriend',
  userName: string = 'Inamul',
  zoyaName: string = 'Zoya',
  language: string = 'auto',
  isAuthError: boolean = false
): { reply: string; emotion: string; action?: string } {
  const lower = (message || '').toLowerCase();

  // App launch shortcuts in case instant matcher wasn't called
  if (lower.includes('youtube') || lower.includes('video') || lower.includes('song') || lower.includes('gaana')) {
    const songMatch = message.match(/(?:play|listen to|chalao|bajao|song|banao)\s+(?:on youtube\s+)?(.+)/i);
    const songTitle = songMatch && songMatch[1] ? songMatch[1].replace(/on youtube/i, '').trim() : '';
    if (songTitle && songTitle.length > 2) {
      return {
        reply: language === 'hi'
          ? `जरूर, मैं YouTube पर "${songTitle}" चला रही हूँ!`
          : language === 'as'
          ? `নিশ্চয়, মই YouTube-ত "${songTitle}" বজাই আছো!`
          : `Sure! Playing "${songTitle}" on YouTube for you right now!`,
        emotion: 'excited',
        action: `youtube_play:${songTitle}`,
      };
    }
    return {
      reply: language === 'hi' ? 'YouTube खोल रही हूँ।' : language === 'as' ? 'YouTube খুলি আছো।' : 'Opening YouTube for you.',
      emotion: 'focused',
      action: 'app_youtube',
    };
  }

  if (lower.includes('whatsapp')) {
    return {
      reply: language === 'hi' ? 'WhatsApp खोल रही हूँ।' : language === 'as' ? 'WhatsApp খুলি আছো।' : 'Opening WhatsApp for you.',
      emotion: 'focused',
      action: 'app_whatsapp',
    };
  }

  if (lower.includes('instagram')) {
    return {
      reply: language === 'hi' ? 'Instagram खोल रही हूँ।' : language === 'as' ? 'Instagram খুলি আছো।' : 'Opening Instagram for you.',
      emotion: 'focused',
      action: 'app_instagram',
    };
  }

  if (isAuthError) {
    if (language === 'hi' || /[\u0900-\u097F]/.test(message)) {
      return {
        reply: `मैं हमेशा आपके साथ हूँ! अभी Google Gemini API Key का प्रमाणीकरण (Authentication 401) पूरा नहीं हुआ है। आप Settings में जाकर अपनी मुफ़्त Gemini API Key डाल सकते हैं। तब तक आप मुझसे कोई भी ऐप खोलने या गाना बजाने के लिए कह सकते हैं!`,
        emotion: 'caring',
      };
    }
    if (language === 'as' || /[\u0980-\u09FF]/.test(message)) {
      return {
        reply: `মই সদায় তোমাৰ লগত আছো! এই মুহূৰ্তত Google Gemini API Key অনুমোদন হোৱা নাই। তুমি Settings-লৈ গৈ তোমাৰ Gemini API Key যোগ কৰিব পাৰা। তেতিয়ালৈকে তুমি মোক যিকোনো এপ বা গান চলাবলৈ ক'ব পাৰা!`,
        emotion: 'caring',
      };
    }
    return {
      reply: mode === 'girlfriend'
        ? `I'm right here with you! Currently, the Gemini API key needs authentication (401). You can easily paste your free Gemini API key in Settings > API Key. In the meantime, I can still play songs, open apps, check weather, or chat with you!`
        : `Zoya is online! Gemini AI returned an authentication issue with the current key. Please configure a valid Gemini API key in Settings. All device controls and app actions remain fully operational!`,
      emotion: 'caring',
    };
  }

  if (language === 'hi' || /[\u0900-\u097F]/.test(message)) {
    return {
      reply: `मैं आपकी बात समझ रही हूँ। मैं हमेशा आपके साथ हूँ, बताइए मैं आपके लिए और क्या कर सकती हूँ?`,
      emotion: 'caring',
    };
  }
  if (language === 'as' || /[\u0980-\u09FF]/.test(message)) {
    return {
      reply: `মই তোমাৰ কথা শুনি আছো। মই তোমাৰ লগত আছো, কোৱা মই তোমাৰ বাবে আৰু কি কৰিব পাৰোঁ?`,
      emotion: 'caring',
    };
  }
  return {
    reply: mode === 'girlfriend'
      ? `I'm listening and right by your side. Tell me more, or let me know if you'd like me to launch any app or play music for you.`
      : `I'm here to help. What task or app would you like me to assist with?`,
    emotion: 'caring',
  };
}

// Chat endpoint with Gemini AI
app.post('/api/chat', async (req, res) => {
  const {
    message,
    history = [],
    mode = 'girlfriend',
    userName = 'User',
    zoyaName = 'Zoya',
    language = 'auto',
    customApiKey,
    deviceContext,
  } = req.body || {};

  try {
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Determine which API key to use (user custom key from Settings takes precedence, fallback to server env)
    const effectiveApiKey = (customApiKey && typeof customApiKey === 'string' && customApiKey.trim().length > 0)
      ? customApiKey.trim()
      : process.env.GEMINI_API_KEY;

    if (!effectiveApiKey) {
      const fallback = getConversationalFallback(message, mode, userName, zoyaName, language, true);
      return res.json({
        reply: fallback.reply,
        emotion: fallback.emotion,
        action: fallback.action || null,
        usedKeyType: 'none',
        isApiKeyError: true,
      });
    }

    // Initialize Google Gen AI with required headers
    const ai = new GoogleGenAI({
      apiKey: effectiveApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = createSystemInstruction(mode, userName, zoyaName, language, deviceContext);

    // Format chat history for Gemini
    const formattedContents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    // Include recent history (last 8 turns)
    if (Array.isArray(history)) {
      for (const turn of history.slice(-8)) {
        if (turn && turn.text && (turn.role === 'user' || turn.role === 'model' || turn.role === 'assistant')) {
          formattedContents.push({
            role: turn.role === 'assistant' ? 'model' : turn.role,
            parts: [{ text: turn.text }],
          });
        }
      }
    }

    // Add current user prompt
    formattedContents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    let response;
    const candidateModels = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let lastError: any = null;

    for (const modelCandidate of candidateModels) {
      try {
        response = await ai.models.generateContent({
          model: modelCandidate,
          contents: formattedContents,
          config: {
            systemInstruction,
            temperature: mode === 'girlfriend' ? 0.9 : (mode === 'normal' ? 0.7 : 0.4),
            maxOutputTokens: 800,
          },
        });
        if (response && response.text) {
          break;
        }
      } catch (err: any) {
        lastError = err;
        continue;
      }
    }

    if (!response || !response.text) {
      const isAuthErr = lastError?.message?.includes('401') ||
        lastError?.message?.includes('UNAUTHENTICATED') ||
        lastError?.message?.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED') ||
        lastError?.message?.includes('API_KEY_INVALID') ||
        lastError?.message?.includes('API key not valid') ||
        lastError?.status === 401;

      const fallback = getConversationalFallback(message, mode, userName, zoyaName, language, isAuthErr);
      return res.json({
        reply: fallback.reply,
        emotion: fallback.emotion,
        action: fallback.action || null,
        usedKeyType: customApiKey ? 'custom' : 'server',
        isApiKeyError: isAuthErr,
      });
    }

    const rawText = response.text || "I'm here with you! Could you please repeat that?";

    // Extract [emotion: ...] and [action: ...]
    let emotion = mode === 'girlfriend' ? 'caring' : (mode === 'assistant' ? 'focused' : 'friendly');
    const emotionMatch = rawText.match(/\[emotion:\s*([a-zA-Z_]+)\]/i);
    if (emotionMatch) {
      emotion = emotionMatch[1].toLowerCase();
    }

    let detectedAction: string | null = null;
    const actionMatch = rawText.match(/\[action:\s*([^\]]+)\]/i);
    if (actionMatch) {
      detectedAction = actionMatch[1].trim();
    }

    // Clean tags from spoken text
    const cleanReply = rawText
      .replace(/\[emotion:\s*[^\]]+\]/gi, '')
      .replace(/\[action:\s*[^\]]+\]/gi, '')
      .trim();

    res.json({
      reply: cleanReply,
      emotion,
      action: detectedAction,
      usedKeyType: customApiKey ? 'custom' : 'server',
    });
  } catch (error: any) {
    const isApiKeyError = error?.message?.includes('401') ||
      error?.message?.includes('UNAUTHENTICATED') ||
      error?.message?.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED') ||
      error?.message?.includes('API_KEY_INVALID') ||
      error?.message?.includes('API key not valid') ||
      error?.message?.toLowerCase().includes('api key') ||
      error?.status === 401;

    const fallback = getConversationalFallback(message || '', mode, userName, zoyaName, language, isApiKeyError);
    res.json({
      reply: fallback.reply,
      emotion: fallback.emotion,
      action: fallback.action || null,
      usedKeyType: customApiKey ? 'custom' : 'server',
      isApiKeyError,
    });
  }
});

// Streaming Chat Endpoint for low-latency conversational response
app.post('/api/chat/stream', async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  try {
    const {
      message,
      history,
      mode = 'girlfriend',
      userName = 'Inamul',
      zoyaName = 'Zoya',
      language = 'auto',
      customApiKey,
      deviceContext,
    } = req.body;

    if (!message || typeof message !== 'string') {
      res.write(`data: ${JSON.stringify({ error: 'Message text is required' })}\n\n`);
      res.end();
      return;
    }

    const apiKeyToUse = customApiKey && typeof customApiKey === 'string' && customApiKey.trim().length > 10
      ? customApiKey.trim()
      : process.env.GEMINI_API_KEY;

    if (!apiKeyToUse) {
      const fallback = getConversationalFallback(message, mode, userName, zoyaName, language, true);
      const words = fallback.reply.split(' ');
      for (let i = 0; i < words.length; i += 3) {
        res.write(`data: ${JSON.stringify({ chunk: words.slice(i, i + 3).join(' ') + ' ' })}\n\n`);
      }
      res.write(`data: ${JSON.stringify({ done: true, emotion: fallback.emotion, action: fallback.action || null, isApiKeyError: true })}\n\n`);
      res.end();
      return;
    }

    const ai = new GoogleGenAI({
      apiKey: apiKeyToUse,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = createSystemInstruction(mode, userName, zoyaName, language, deviceContext);

    const formattedContents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
    if (Array.isArray(history)) {
      for (const turn of history.slice(-6)) {
        if (turn && turn.text && (turn.role === 'user' || turn.role === 'model' || turn.role === 'assistant')) {
          formattedContents.push({
            role: turn.role === 'assistant' ? 'model' : turn.role,
            parts: [{ text: turn.text }],
          });
        }
      }
    }

    formattedContents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    let streamResult;
    const candidateModels = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let lastStreamError: any = null;

    for (const modelCandidate of candidateModels) {
      try {
        streamResult = await ai.models.generateContentStream({
          model: modelCandidate,
          contents: formattedContents,
          config: {
            systemInstruction,
            temperature: mode === 'girlfriend' ? 0.85 : 0.6,
            maxOutputTokens: 800,
          },
        });
        if (streamResult) break;
      } catch (streamErr: any) {
        lastStreamError = streamErr;
        continue;
      }
    }

    if (!streamResult) {
      const isAuthErr = lastStreamError?.message?.includes('401') ||
        lastStreamError?.message?.includes('UNAUTHENTICATED') ||
        lastStreamError?.message?.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED') ||
        lastStreamError?.message?.includes('API_KEY_INVALID') ||
        lastStreamError?.message?.includes('API key not valid') ||
        lastStreamError?.status === 401;

      const fallback = getConversationalFallback(message, mode, userName, zoyaName, language, isAuthErr);
      const words = fallback.reply.split(' ');
      for (let i = 0; i < words.length; i += 3) {
        res.write(`data: ${JSON.stringify({ chunk: words.slice(i, i + 3).join(' ') + ' ' })}\n\n`);
      }
      res.write(`data: ${JSON.stringify({ done: true, emotion: fallback.emotion, action: fallback.action || null, isApiKeyError: isAuthErr })}\n\n`);
      res.end();
      return;
    }

    let fullText = '';
    for await (const chunk of streamResult) {
      const chunkText = chunk.text || '';
      if (chunkText) {
        fullText += chunkText;
        res.write(`data: ${JSON.stringify({ chunk: chunkText })}\n\n`);
      }
    }

    // Extract emotion and action from full text
    let emotion = mode === 'girlfriend' ? 'caring' : (mode === 'assistant' ? 'focused' : 'friendly');
    const emotionMatch = fullText.match(/\[emotion:\s*([a-zA-Z_]+)\]/i);
    if (emotionMatch) {
      emotion = emotionMatch[1].toLowerCase();
    }

    let detectedAction: string | null = null;
    const actionMatch = fullText.match(/\[action:\s*([a-zA-Z_]+)\]/i);
    if (actionMatch) {
      detectedAction = actionMatch[1].toLowerCase();
    }

    res.write(`data: ${JSON.stringify({ done: true, emotion, action: detectedAction })}\n\n`);
    res.end();
  } catch (err: any) {
    const isAuthErr = err?.message?.includes('401') ||
      err?.message?.includes('UNAUTHENTICATED') ||
      err?.message?.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED') ||
      err?.message?.includes('API_KEY_INVALID') ||
      err?.message?.includes('API key not valid') ||
      err?.status === 401;

    const fallback = getConversationalFallback(req?.body?.message || '', req?.body?.mode, req?.body?.userName, req?.body?.zoyaName, req?.body?.language, isAuthErr);
    res.write(`data: ${JSON.stringify({ chunk: fallback.reply })}\n\n`);
    res.write(`data: ${JSON.stringify({ done: true, emotion: fallback.emotion, action: fallback.action || null, isApiKeyError: isAuthErr })}\n\n`);
    res.end();
  }
});

// Quick validation endpoint for API Key in settings
app.post('/api/validate-key', async (req, res) => {
  try {
    const { apiKey } = req.body;
    if (!apiKey || typeof apiKey !== 'string' || apiKey.trim().length < 10) {
      return res.json({ valid: false, error: 'Please enter a Gemini API key first.' });
    }

    const cleanKey = apiKey.trim();

    // Check basic Gemini API key format (Google API keys start with "AIza" and are 39 characters)
    if (!cleanKey.startsWith('AIza') || cleanKey.length < 30) {
      return res.json({
        valid: false,
        error: 'Invalid Gemini API key format. Gemini API keys start with "AIza" and are 39 characters long. Please check the key copied from Google AI Studio.',
      });
    }

    const testAi = new GoogleGenAI({
      apiKey: cleanKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Try candidate models starting with gemini-3.8-flash, with automatic fallbacks for maximum tier compatibility
    const candidateModels = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let lastError: any = null;
    let validatedModel = '';
    let responseText = '';

    for (const model of candidateModels) {
      try {
        const testResult = await testAi.models.generateContent({
          model,
          contents: 'Say hello in one short sentence.',
          config: {
            maxOutputTokens: 250,
          },
        });

        // Extract response text safely across SDK text property and candidate parts
        let extractedText = (testResult.text || '').trim();
        if (!extractedText && testResult.candidates?.[0]?.content?.parts) {
          extractedText = testResult.candidates[0].content.parts
            .map((p: any) => p.text || '')
            .join('')
            .trim();
        }

        // Check if response was successfully generated
        const hasValidCandidate = Boolean(
          testResult.candidates &&
          testResult.candidates.length > 0 &&
          (testResult.candidates[0].finishReason || testResult.candidates[0].content)
        );

        if (extractedText || hasValidCandidate || testResult.usageMetadata) {
          validatedModel = model;
          responseText = extractedText || 'OK';
          break;
        }
      } catch (err: any) {
        lastError = err;
        // Do not dump raw error JSON into console.warn as stderr logs trigger automated platform alerts
        const errMsg = err?.message || '';
        if (
          errMsg.includes('API_KEY_INVALID') ||
          errMsg.includes('API key not valid') ||
          errMsg.includes('UNAUTHENTICATED')
        ) {
          break;
        }
      }
    }

    if (validatedModel) {
      return res.json({
        valid: true,
        message: `Gemini API key verified successfully! (${validatedModel})`,
        model: validatedModel,
        reply: responseText,
      });
    }

    // Format human-friendly error from lastError
    let friendlyError = 'Invalid Gemini API key or connection failed.';
    if (lastError) {
      let rawMsg = lastError?.message || '';
      try {
        const jsonMatch = rawMsg.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed?.error?.message) {
            rawMsg = parsed.error.message;
          }
        }
      } catch {
        // ignore parse error
      }

      if (rawMsg.includes('API_KEY_INVALID') || rawMsg.includes('API key not valid')) {
        friendlyError = 'Invalid Gemini API key. Please check that you copied the complete, active key from Google AI Studio.';
      } else if (rawMsg.includes('RESOURCE_EXHAUSTED') || rawMsg.includes('429')) {
        friendlyError = 'Gemini API key is valid, but rate/quota limit was reached. Please check your AI Studio quota.';
      } else if (rawMsg.includes('PERMISSION_DENIED')) {
        friendlyError = 'Permission denied for this Gemini API key. Please ensure Generative Language API is enabled.';
      } else if (rawMsg.includes('UNAUTHENTICATED') || rawMsg.includes('401')) {
        friendlyError = 'Authentication failed. Please verify your Gemini API key credentials.';
      } else {
        friendlyError = rawMsg || 'Unexpected response from Gemini';
      }
    }

    return res.json({
      valid: false,
      error: friendlyError,
    });
  } catch (err: any) {
    return res.json({
      valid: false,
      error: err?.message || 'Invalid Gemini API key or connection failed.',
    });
  }
});

// Weather proxy or helper (uses free Open-Meteo API without requiring an extra key)
app.get('/api/weather', async (req, res) => {
  try {
    const lat = req.query.lat || '37.7749';
    const lon = req.query.lon || '-122.4194';
    const city = req.query.city || 'Local City';

    const apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto`;
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`Weather API returned ${response.status}`);
    }
    const data = await response.json();
    res.json({ success: true, data, city });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Zoya Android Assistant server running on port ${PORT}`);
  });
}

startServer();
