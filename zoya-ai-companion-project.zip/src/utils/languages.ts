import { LanguageCode, LanguageOption } from '../types';

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  {
    code: 'auto',
    name: 'Auto Detect',
    nativeName: 'Auto (স্বয়ংক্রিয়)',
    bcp47: 'en-US',
  },
  {
    code: 'as',
    name: 'Assamese',
    nativeName: 'অসমীয়া',
    bcp47: 'as-IN',
  },
  {
    code: 'hi',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    bcp47: 'hi-IN',
  },
  {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    bcp47: 'en-US',
  },
  {
    code: 'bn',
    name: 'Bengali',
    nativeName: 'বাংলা',
    bcp47: 'bn-IN',
  },
  {
    code: 'ur',
    name: 'Urdu',
    nativeName: 'اردو',
    bcp47: 'ur-IN',
  },
];

/**
 * Detect script / language family from text.
 * Especially checks for Assamese specific characters (ৰ, ৱ) and Eastern Nagari script.
 */
export function detectLanguageFromText(text: string): LanguageCode {
  if (!text) return 'en';

  // Assamese specific characters: 'ৰ' (\u09F0) and 'ৱ' (\u09F1)
  if (/[\u09F0\u09F1]/.test(text)) {
    return 'as';
  }

  // Eastern Nagari script (Bengali / Assamese range: \u0980 - \u09FF)
  if (/[\u0980-\u09FF]/.test(text)) {
    // If text contains Assamese characteristic words or phrasing
    if (/(আছ|কেনেকুৱা|কি খবৰ|ভাল|নহয়|তোমাৰ|মই|নকৰিবা|হ’ল|কিয়|ধন্যবাদ)/i.test(text)) {
      return 'as';
    }
    return 'bn';
  }

  // Devanagari script (Hindi, Marathi, etc: \u0900 - \u097F)
  if (/[\u0900-\u097F]/.test(text)) {
    return 'hi';
  }

  // Arabic / Perso-Arabic script (Urdu: \u0600 - \u06FF)
  if (/[\u0600-\u06FF]/.test(text)) {
    return 'ur';
  }

  return 'en';
}

export function getLanguageBCP47(code: LanguageCode, textSample?: string): string {
  if (code === 'auto') {
    if (textSample) {
      const detected = detectLanguageFromText(textSample);
      return getLanguageBCP47(detected);
    }
    return 'en-US';
  }

  switch (code) {
    case 'as':
      return 'as-IN';
    case 'hi':
      return 'hi-IN';
    case 'bn':
      return 'bn-IN';
    case 'ur':
      return 'ur-IN';
    case 'en':
    default:
      return 'en-US';
  }
}
