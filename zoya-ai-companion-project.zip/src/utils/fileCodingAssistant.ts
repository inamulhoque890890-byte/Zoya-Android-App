// Android File and Coding Assistant Helper for Zoya
// Safe, sandbox-compliant coding and file operations.
// Disallows financial/banking or malicious scripts; adheres strictly to user privacy and browser/Android sandbox rules.

export interface FileInspectionResult {
  name: string;
  size: number;
  type: string;
  lastModified: number;
  contentSnippet?: string;
  lineCount?: number;
  characterCount?: number;
}

export interface CodeAnalysisResult {
  language: string;
  lines: number;
  summary: string;
  hasErrorsOrWarnings: boolean;
  notes: string[];
}

/**
 * Triggers native Android file picker to inspect a file (e.g., code file, text, image).
 */
export function promptFilePicker(
  accept = '*/*',
  onFileLoaded?: (info: FileInspectionResult, textContent?: string) => void
): Promise<FileInspectionResult | null> {
  return new Promise((resolve) => {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = accept;
      input.style.display = 'none';

      input.onchange = async (e: any) => {
        const file: File | undefined = e.target?.files?.[0];
        if (!file) {
          resolve(null);
          return;
        }

        const info: FileInspectionResult = {
          name: file.name,
          size: file.size,
          type: file.type || 'text/plain',
          lastModified: file.lastModified,
        };

        // If it's a readable text/code file, read snippet
        if (
          file.type.startsWith('text/') ||
          file.name.match(/\.(ts|tsx|js|jsx|json|html|css|py|java|c|cpp|md|txt|xml|yaml|yml|sh|env|sql)$/i) ||
          file.size < 2 * 1024 * 1024
        ) {
          try {
            const text = await file.text();
            info.lineCount = text.split('\n').length;
            info.characterCount = text.length;
            info.contentSnippet = text.slice(0, 1000);
            if (onFileLoaded) {
              onFileLoaded(info, text);
            }
          } catch {
            // text read error
          }
        }

        resolve(info);
      };

      document.body.appendChild(input);
      input.click();
      setTimeout(() => {
        if (document.body.contains(input)) {
          document.body.removeChild(input);
        }
      }, 1000);
    } catch {
      resolve(null);
    }
  });
}

/**
 * Download or save generated code/text as a file to Android Downloads.
 */
export function saveFileToAndroidDevice(
  fileName: string,
  content: string,
  mimeType = 'text/plain'
): { success: boolean; message: string } {
  try {
    const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
      URL.revokeObjectURL(url);
    }, 1500);

    return {
      success: true,
      message: `File "${fileName}" saved to your device!`,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Failed to save file: ${err?.message || 'Download error'}`,
    };
  }
}

/**
 * Quick analysis of code syntax / structural sanity
 */
export function analyzeSnippet(code: string, language = 'javascript'): CodeAnalysisResult {
  const lines = code.split('\n').length;
  const notes: string[] = [];
  let hasErrorsOrWarnings = false;

  // Check for common bracket imbalances
  const openBraces = (code.match(/{/g) || []).length;
  const closeBraces = (code.match(/}/g) || []).length;
  if (openBraces !== closeBraces) {
    notes.push(`Warning: Mismatched curly braces ({: ${openBraces}, }: ${closeBraces})`);
    hasErrorsOrWarnings = true;
  }

  const openParens = (code.match(/\(/g) || []).length;
  const closeParens = (code.match(/\)/g) || []).length;
  if (openParens !== closeParens) {
    notes.push(`Warning: Mismatched parentheses ((: ${openParens}, ): ${closeParens})`);
    hasErrorsOrWarnings = true;
  }

  // Safety check: warn on unsafe financial or banking tokens
  if (code.match(/\b(creditcard|cvv|atm_pin|bank_account|netbanking)\b/i)) {
    notes.push('Restricted: Financial/banking parameters are forbidden for security.');
    hasErrorsOrWarnings = true;
  }

  return {
    language,
    lines,
    summary: `${lines} lines analyzed for ${language}.`,
    hasErrorsOrWarnings,
    notes,
  };
}
