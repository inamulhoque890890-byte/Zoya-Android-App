import { EmotionType, VoiceSettings, LanguageCode } from '../types';
import { detectLanguageFromText, getLanguageBCP47 } from './languages';

export interface BoyVoiceOption {
  id: string;
  name: string;
  subtitle: string;
  category: 'curated' | 'system';
  lang: string;
  pitch: number;
  rate: number;
  voiceURI?: string;
  samplePhrase: string;
  description: string;
  tag: string;
}

export const CURATED_BOY_VOICES: BoyVoiceOption[] = [
  {
    id: 'aarav',
    name: 'Aarav',
    subtitle: 'Young Indian Boy • Energetic & Warm',
    category: 'curated',
    lang: 'en-IN',
    pitch: 1.01,
    rate: 1.0,
    samplePhrase: "Hey Inamul! I'm Aarav. Ready to have fun and get tasks done together!",
    description: 'Bright, energetic Indian boy cadence with friendly warmth.',
    tag: 'Energetic • Indian Boy',
  },
  {
    id: 'kabir',
    name: 'Kabir',
    subtitle: 'Cool & Calm Brother',
    category: 'curated',
    lang: 'en-IN',
    pitch: 0.98,
    rate: 0.98,
    samplePhrase: "Hey there! Kabir here. Take it easy, I'm right here to back you up.",
    description: 'Relaxed, supportive, warm young brotherly tone.',
    tag: 'Calm • Brotherly',
  },
  {
    id: 'rohan',
    name: 'Rohan',
    subtitle: 'Smart & Tech Youth',
    category: 'curated',
    lang: 'en-IN',
    pitch: 1.0,
    rate: 1.02,
    samplePhrase: "Hi! I'm Rohan. Tell me what app or music you need, and I'll handle it right away!",
    description: 'Enthusiastic, clear student assistant voice.',
    tag: 'Smart • Assistant',
  },
  {
    id: 'leo',
    name: 'Leo',
    subtitle: 'Playful & Animated Boy',
    category: 'curated',
    lang: 'en-US',
    pitch: 1.02,
    rate: 1.02,
    samplePhrase: "What's up! Leo here, always excited to explore something awesome with you!",
    description: 'Upbeat, cheerful teen companion voice.',
    tag: 'Playful • Animated',
  },
  {
    id: 'alex',
    name: 'Alex',
    subtitle: 'Classic Confident Boy',
    category: 'curated',
    lang: 'en-US',
    pitch: 0.98,
    rate: 1.0,
    samplePhrase: "Hello! Alex here, clear, natural, and ready to assist you on your device.",
    description: 'Crisp, natural, confident masculine tone.',
    tag: 'Clear • Confident',
  },
  {
    id: 'zayd',
    name: 'Zayd',
    subtitle: 'Gentle & Caring Brother',
    category: 'curated',
    lang: 'en-IN',
    pitch: 0.99,
    rate: 0.97,
    samplePhrase: "Assalamu Alaikum! I'm Zayd. It is truly a pleasure to spend time with you.",
    description: 'Polite, soothing, gentle youthful tone.',
    tag: 'Gentle • Caring',
  },
  {
    id: 'aryan',
    name: 'Aryan',
    subtitle: 'Dynamic & Swift Youth',
    category: 'curated',
    lang: 'en-IN',
    pitch: 1.01,
    rate: 1.03,
    samplePhrase: "Hey! Aryan on the line. Let's make today super productive!",
    description: 'Punchy, modern, quick-witted young man.',
    tag: 'Fast • Dynamic',
  },
  {
    id: 'dev',
    name: 'Dev',
    subtitle: 'Desi Hindi Youth',
    category: 'curated',
    lang: 'hi-IN',
    pitch: 1.0,
    rate: 1.0,
    samplePhrase: "नमस्ते! मैं देव हूँ। बताइए आज हम क्या नया करने वाले हैं?",
    description: 'Bilingual Hindi-English friendly Indian boy tone.',
    tag: 'Hindi • Desi Youth',
  },
];

export function isBoyOrMaleVoice(v: SpeechSynthesisVoice): boolean {
  const name = (v.name || '').toLowerCase();
  const uri = (v.voiceURI || '').toLowerCase();
  const text = `${name} ${uri}`;

  const femaleKeywords = [
    'female', 'woman', 'girl', 'zira', 'samantha', 'karen', 'victoria',
    'serena', 'fiona', 'ava', 'jenny', 'aria', 'emma', 'swara',
    'tanisha', 'ananya', 'kalpana', 'priya', 'madhur (female)', 'neerja',
    'heera', 'geeta', 'leila', 'alice'
  ];
  if (femaleKeywords.some((k) => text.includes(k))) return false;

  const maleKeywords = [
    'male', 'man', 'boy', 'david', 'george', 'mark', 'guy', 'richard',
    'james', 'daniel', 'alex', 'fred', 'tom', 'bruce', 'junior',
    'albert', 'ralph', 'oliver', 'william', 'henry', 'lucas', 'benjamin',
    'mason', 'ethan', 'rishi', 'aravind', 'kiran male', 'bashkar',
    'madhur (male)', 'deepak', 'amit', 'rohit', 'kabir', 'aarav', 'neil'
  ];
  if (maleKeywords.some((k) => text.includes(k))) return true;
  if (text.includes('#male')) return true;

  return false;
}

export function getAllBoysVoices(systemVoices: SpeechSynthesisVoice[] = []): BoyVoiceOption[] {
  const result: BoyVoiceOption[] = [...CURATED_BOY_VOICES];

  for (const v of systemVoices) {
    if (isBoyOrMaleVoice(v)) {
      const existing = result.find((r) => r.voiceURI === v.voiceURI);
      if (!existing) {
        result.push({
          id: `system_${v.voiceURI || v.name}`,
          name: v.name,
          subtitle: `System Voice • ${v.lang}`,
          category: 'system',
          lang: v.lang,
          pitch: 1.0,
          rate: 1.0,
          voiceURI: v.voiceURI,
          samplePhrase: `Hello! This is ${v.name}. Voice preview working successfully.`,
          description: `Device native TTS male voice (${v.lang}).`,
          tag: 'System TTS',
        });
      }
    }
  }

  return result;
}

export function isRoboticVoice(v: SpeechSynthesisVoice): boolean {
  const name = (v.name || '').toLowerCase();
  const uri = (v.voiceURI || '').toLowerCase();
  const text = `${name} ${uri}`;
  return (
    text.includes('espeak') ||
    text.includes('klatt') ||
    text.includes('robot') ||
    text.includes('desktop') ||
    text.includes('pico') ||
    text.includes('compact')
  );
}

// Speech Synthesis Helper
class SpeechController {
  private synth: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private onVoicesLoadedCallbacks: Array<(voices: SpeechSynthesisVoice[]) => void> = [];
  private onSpeakingChangeCallbacks: Array<(isSpeaking: boolean) => void> = [];
  private onBoundaryCallbacks: Array<(charIndex: number, name: string) => void> = [];
  private isPrewarmed = false;
  private keepAliveTimer: any = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  public onSpeakingChange(cb: (isSpeaking: boolean) => void): () => void {
    this.onSpeakingChangeCallbacks.push(cb);
    return () => {
      this.onSpeakingChangeCallbacks = this.onSpeakingChangeCallbacks.filter((c) => c !== cb);
    };
  }

  public onBoundary(cb: (charIndex: number, name: string) => void): () => void {
    this.onBoundaryCallbacks.push(cb);
    return () => {
      this.onBoundaryCallbacks = this.onBoundaryCallbacks.filter((c) => c !== cb);
    };
  }

  private notifySpeaking(speaking: boolean) {
    for (const cb of this.onSpeakingChangeCallbacks) {
      try {
        cb(speaking);
      } catch (err) {
        console.warn('Speaking callback error:', err);
      }
    }
  }

  private notifyBoundary(charIndex: number, name: string) {
    for (const cb of this.onBoundaryCallbacks) {
      try {
        cb(charIndex, name);
      } catch (err) {
        console.warn('Boundary callback error:', err);
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    const available = this.synth.getVoices();
    if (available && available.length > 0) {
      this.voices = available;
      this.onVoicesLoadedCallbacks.forEach((cb) => cb(this.voices));
    }
  }

  /**
   * Pre-warm speech synthesis engine on first click / touch.
   * Eliminates the ~500ms audio engine startup delay on mobile Android Chrome.
   */
  public prewarm() {
    if (this.isPrewarmed || !this.synth) return;
    try {
      const silent = new SpeechSynthesisUtterance('');
      silent.volume = 0;
      this.synth.speak(silent);
      this.isPrewarmed = true;
    } catch {
      // ignore
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.synth && this.voices.length === 0) {
      this.loadVoices();
    }
    return this.voices;
  }

  private startKeepAlive() {
    this.stopKeepAlive();
    this.keepAliveTimer = setInterval(() => {
      if (this.synth && this.synth.speaking) {
        try {
          this.synth.pause();
          this.synth.resume();
        } catch {
          // ignore
        }
      } else {
        this.stopKeepAlive();
      }
    }, 7000);
  }

  private stopKeepAlive() {
    if (this.keepAliveTimer) {
      clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }
  }

  public onVoicesAvailable(cb: (voices: SpeechSynthesisVoice[]) => void) {
    if (this.voices.length > 0) {
      cb(this.voices);
    } else {
      this.onVoicesLoadedCallbacks.push(cb);
    }
  }

  public stop() {
    this.stopKeepAlive();
    if (typeof window !== 'undefined') {
      (window as any).__zoyaActiveUtterance = null;
    }
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {
        // ignore
      }
      this.currentUtterance = null;
      this.notifySpeaking(false);
    }
  }

  public isSpeaking(): boolean {
    return Boolean(this.synth && this.synth.speaking);
  }

  public speak(
    text: string,
    settings: VoiceSettings,
    emotion?: EmotionType,
    onEnd?: () => void,
    onError?: (err: any) => void,
    languageOverride?: LanguageCode
  ) {
    if (!this.synth) {
      if (onEnd) onEnd();
      return;
    }

    this.stop();

    // Clean text of emojis, markdown, links, brackets or technical markers for pristine, smooth pronunciation
    const speechText = text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // Convert [Title](URL) -> Title
      .replace(/https?:\/\/\S+/gi, '') // Strip raw URLs
      .replace(/[*_#`~[\]]/g, '') // Strip markdown formatting symbols
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!speechText) {
      if (onEnd) onEnd();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(speechText);
    this.currentUtterance = utterance;
    if (typeof window !== 'undefined') {
      (window as any).__zoyaActiveUtterance = utterance;
    }

    // Detect language
    const langCode = (languageOverride && languageOverride !== 'auto')
      ? languageOverride
      : (settings.language && settings.language !== 'auto')
      ? settings.language
      : detectLanguageFromText(speechText);

    const bcp47 = getLanguageBCP47(langCode, speechText);
    utterance.lang = bcp47;

    const isBoysVoice = settings.voiceProfile === 'boys_voice';

    // Base pitch & rate:
    // Natural human voice baseline is 1.0. Slight variation preserves natural resonance without metallic robotic distortion.
    let basePitch = isBoysVoice
      ? (settings.selectedBoyVoicePitch || 1.0)
      : (settings.pitch || 1.0);
    let baseRate = isBoysVoice
      ? (settings.selectedBoyVoiceRate || 1.0)
      : (settings.rate || 1.0);

    let targetPitch = basePitch;
    let targetRate = baseRate;

    // Micro-emotional cadences: keep pitch within [0.95, 1.04] to eliminate any robotic chipmunk or metallic audio artifacts
    if (emotion === 'loving') {
      targetPitch = Math.min(1.02, basePitch * 1.01);
      targetRate = Math.max(0.94, baseRate * 0.96);
    } else if (emotion === 'caring' || emotion === 'empathy') {
      targetPitch = Math.min(1.02, basePitch * 1.01);
      targetRate = Math.max(0.94, baseRate * 0.96);
    } else if (emotion === 'supportive') {
      targetPitch = Math.min(1.01, basePitch * 1.005);
      targetRate = Math.max(0.95, baseRate * 0.97);
    } else if (emotion === 'amused') {
      targetPitch = Math.min(1.03, basePitch * 1.015);
      targetRate = Math.min(1.05, baseRate * 1.02);
    } else if (emotion === 'happy') {
      targetPitch = Math.min(1.03, basePitch * 1.015);
      targetRate = Math.min(1.05, baseRate * 1.02);
    } else if (emotion === 'excited' || emotion === 'surprise') {
      targetPitch = Math.min(1.04, basePitch * 1.02);
      targetRate = Math.min(1.06, baseRate * 1.03);
    } else if (emotion === 'calmness') {
      targetPitch = Math.max(0.97, basePitch * 0.99);
      targetRate = Math.max(0.93, baseRate * 0.96);
    } else if (emotion === 'sad' || emotion === 'concern') {
      targetPitch = Math.max(0.96, basePitch * 0.98);
      targetRate = Math.max(0.92, baseRate * 0.95);
    } else if (emotion === 'thoughtful') {
      targetPitch = basePitch;
      targetRate = Math.max(0.94, baseRate * 0.97);
    } else if (emotion === 'shyness') {
      targetPitch = Math.min(1.02, basePitch * 1.01);
      targetRate = Math.max(0.94, baseRate * 0.96);
    } else if (emotion === 'focused') {
      targetPitch = Math.min(1.02, basePitch * 1.005);
      targetRate = Math.min(1.05, baseRate * 1.01);
    }

    // Strictly enforce natural human bounds
    targetPitch = Math.min(1.05, Math.max(0.95, targetPitch));
    targetRate = Math.min(1.10, Math.max(0.90, targetRate));

    utterance.pitch = Math.round(targetPitch * 100) / 100;
    utterance.rate = Math.round(targetRate * 100) / 100;

    // Native Android Bridge Check
    const android = typeof window !== 'undefined' ? (window as any).Android : null;
    if (android && typeof android.speak === 'function') {
      try {
        this.notifySpeaking(true);
        (window as any).onAndroidSpeechTtsStart = () => {
          this.notifySpeaking(true);
        };
        (window as any).onAndroidSpeechTtsEnd = () => {
          this.notifySpeaking(false);
          if (onEnd) onEnd();
        };

        android.speak(speechText, targetPitch, targetRate);
        return;
      } catch (err) {
        console.warn('Native Android TTS error, falling back to WebSpeech:', err);
      }
    }

    const available = this.getVoices();
    let selectedVoice: SpeechSynthesisVoice | undefined;

    if (isBoysVoice) {
      if (settings.selectedBoyVoiceURI) {
        selectedVoice = available.find((v) => v.voiceURI === settings.selectedBoyVoiceURI);
      }

      if (!selectedVoice) {
        const langMatches = available.filter((v) => v.lang.toLowerCase().startsWith(langCode.toLowerCase()));
        selectedVoice = langMatches.find((v) => isBoyOrMaleVoice(v) && !isRoboticVoice(v));

        if (!selectedVoice) {
          selectedVoice = available.find((v) => isBoyOrMaleVoice(v) && !isRoboticVoice(v));
        }

        if (!selectedVoice) {
          selectedVoice = available.find((v) => isBoyOrMaleVoice(v));
        }

        if (!selectedVoice) {
          selectedVoice = available.find((v) => {
            const name = (v.name || '').toLowerCase();
            return !name.includes('female') && !name.includes('samantha') && !isRoboticVoice(v);
          });
        }
      }
    } else {
      // Zoya Original Voice Selection: prioritize natural, high-fidelity feminine voices
      if (settings.voiceURI) {
        selectedVoice = available.find((v) => v.voiceURI === settings.voiceURI);
      }

      if (!selectedVoice) {
        const findBestFeminineVoice = (langPrefix: string, preferredNames: string[]) => {
          const langVoices = available.filter((v) => v.lang.toLowerCase().startsWith(langPrefix.toLowerCase()));
          if (langVoices.length === 0) return undefined;

          // Prefer non-robotic voices
          const naturalLangVoices = langVoices.filter((v) => !isRoboticVoice(v));
          const searchPool = naturalLangVoices.length > 0 ? naturalLangVoices : langVoices;

          // 1. Check for specific natural/neural preferred voice names
          for (const pref of preferredNames) {
            const match = searchPool.find((v) => v.name.toLowerCase().includes(pref.toLowerCase()));
            if (match) return match;
          }

          // 2. Check for explicit "female" or "natural" / "online" / "neural"
          const explicitFemale = searchPool.find(
            (v) =>
              v.name.toLowerCase().includes('female') ||
              v.name.toLowerCase().includes('natural') ||
              v.name.toLowerCase().includes('neural') ||
              v.name.toLowerCase().includes('online')
          );
          if (explicitFemale) return explicitFemale;

          // 3. Avoid male or deep voice names
          const nonMale = searchPool.find(
            (v) =>
              !v.name.toLowerCase().includes('male') &&
              !v.name.toLowerCase().includes('david') &&
              !v.name.toLowerCase().includes('george') &&
              !v.name.toLowerCase().includes('mark') &&
              !v.name.toLowerCase().includes('guy') &&
              !v.name.toLowerCase().includes('richard') &&
              !v.name.toLowerCase().includes('james')
          );
          if (nonMale) return nonMale;

          return searchPool[0];
        };

        if (langCode === 'as') {
          selectedVoice = available.find(
            (v) =>
              !isRoboticVoice(v) &&
              (v.lang.toLowerCase().includes('as-in') ||
                v.lang.toLowerCase().startsWith('as') ||
                v.name.toLowerCase().includes('assamese'))
          );
          if (!selectedVoice) {
            selectedVoice =
              findBestFeminineVoice('bn', ['tanisha', 'google বাংলা', 'google', 'female', 'natural']) ||
              findBestFeminineVoice('hi', ['swara', 'google हिन्दी', 'madhur', 'kalpana', 'female', 'natural']);
          }
        } else if (langCode === 'hi') {
          selectedVoice = findBestFeminineVoice('hi', [
            'swara',
            'google हिन्दी',
            'google hindi',
            'madhur',
            'kalpana',
            'ananya',
            'female',
            'natural',
          ]);
        } else if (langCode === 'bn') {
          selectedVoice = findBestFeminineVoice('bn', ['tanisha', 'google বাংলা', 'google', 'female', 'natural']);
        } else if (langCode === 'ur') {
          selectedVoice = findBestFeminineVoice('ur', ['google', 'female', 'natural']);
        }

        if (!selectedVoice) {
          selectedVoice = findBestFeminineVoice('en', [
            'aria online (natural)',
            'jenny online (natural)',
            'ava online (natural)',
            'emma online (natural)',
            'sonia online (natural)',
            'natural',
            'neural',
            'google us english',
            'google uk english female',
            'samantha',
            'karen',
            'victoria',
            'serena',
            'ava',
            'allison',
            'jenny',
            'aria',
            'emma',
            'female',
          ]);
        }
      }
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    utterance.onstart = () => {
      this.notifySpeaking(true);
    };

    utterance.onboundary = (event: any) => {
      this.notifyBoundary(event.charIndex || 0, event.name || 'word');
    };

    utterance.onend = () => {
      this.stopKeepAlive();
      this.currentUtterance = null;
      if (typeof window !== 'undefined') {
        (window as any).__zoyaActiveUtterance = null;
      }
      this.notifySpeaking(false);
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      this.stopKeepAlive();
      this.currentUtterance = null;
      if (typeof window !== 'undefined') {
        (window as any).__zoyaActiveUtterance = null;
      }
      this.notifySpeaking(false);
      if (onError) onError(e);
      else if (onEnd) onEnd();
    };

    try {
      this.startKeepAlive();
      this.synth.speak(utterance);
    } catch (e) {
      this.stopKeepAlive();
      console.warn('Speech synthesis speak error:', e);
      this.notifySpeaking(false);
      if (onEnd) onEnd();
    }
  }

  /**
   * Dedicated voice preview method for playing sample clips of Boys voices or Zoya voices
   */
  public previewVoice(
    phrase: string,
    pitch: number = 1.0,
    rate: number = 1.0,
    voiceURI?: string,
    lang: string = 'en-US',
    onEnd?: () => void,
    onError?: (err: any) => void
  ) {
    if (!this.synth) {
      if (onEnd) onEnd();
      return;
    }

    this.stop();

    const utterance = new SpeechSynthesisUtterance(phrase);
    this.currentUtterance = utterance;
    if (typeof window !== 'undefined') {
      (window as any).__zoyaActiveUtterance = utterance;
    }
    utterance.lang = lang;
    utterance.pitch = Math.min(1.05, Math.max(0.95, pitch));
    utterance.rate = Math.min(1.10, Math.max(0.90, rate));

    const available = this.getVoices();
    let selectedVoice: SpeechSynthesisVoice | undefined;

    if (voiceURI) {
      selectedVoice = available.find((v) => v.voiceURI === voiceURI);
    }

    if (!selectedVoice) {
      const maleVoice = available.find((v) => isBoyOrMaleVoice(v) && !isRoboticVoice(v));
      selectedVoice = maleVoice || available.find((v) => !isRoboticVoice(v)) || available[0];
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    utterance.onstart = () => {
      this.notifySpeaking(true);
    };

    utterance.onend = () => {
      this.stopKeepAlive();
      this.currentUtterance = null;
      if (typeof window !== 'undefined') {
        (window as any).__zoyaActiveUtterance = null;
      }
      this.notifySpeaking(false);
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      this.stopKeepAlive();
      this.currentUtterance = null;
      if (typeof window !== 'undefined') {
        (window as any).__zoyaActiveUtterance = null;
      }
      this.notifySpeaking(false);
      if (onError) onError(e);
      else if (onEnd) onEnd();
    };

    try {
      this.startKeepAlive();
      this.synth.speak(utterance);
    } catch (e) {
      this.stopKeepAlive();
      console.warn('Speech synthesis preview error:', e);
      this.notifySpeaking(false);
      if (onEnd) onEnd();
    }
  }
}

export const speechController = new SpeechController();

// Speech Recognition (Microphone) Options
export interface SpeechRecognizerOptions {
  onResult: (transcript: string, isFinal: boolean) => void;
  onStart: () => void;
  onEnd: () => void;
  onError: (error: string) => void;
  // Fast silence threshold in ms (defaults to 750ms for lightning speed)
  silenceTimeoutMs?: number;
  language?: LanguageCode;
}

/**
 * Creates high-performance SpeechRecognizer with early intent triggers
 * and low-latency silence auto-finalization.
 */
export function createSpeechRecognizer(callbacks: SpeechRecognizerOptions) {
  if (typeof window === 'undefined') return null;

  // 1. Native Android SpeechRecognizer Bridge
  const android = (window as any).Android;
  if (android && typeof android.startListening === 'function') {
    (window as any).onAndroidSpeechReady = () => {
      callbacks.onStart();
    };
    (window as any).onAndroidSpeechResult = (text: string, isFinal: boolean) => {
      callbacks.onResult(text, isFinal);
    };
    (window as any).onAndroidSpeechEnd = () => {
      callbacks.onEnd();
    };
    (window as any).onAndroidSpeechError = (error: string) => {
      callbacks.onError(error);
    };

    return {
      start: () => {
        try {
          android.startListening();
        } catch (e: any) {
          callbacks.onError(e?.message || 'Native listening failed');
        }
      },
      stop: () => {
        try {
          android.stopListening();
        } catch {
          // ignore
        }
      },
      abort: () => {
        try {
          android.stopListening();
        } catch {
          // ignore
        }
      },
    };
  }

  // 2. Browser WebSpeech API Fallback
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return null;
  }

  try {
    const recognizer = new SpeechRecognition();
    recognizer.continuous = false;
    recognizer.interimResults = true;
    const targetLang = getLanguageBCP47(callbacks.language || 'auto');
    recognizer.lang = targetLang;
    recognizer.maxAlternatives = 1;

    let silenceTimer: any = null;
    let latestTranscript = '';
    let hasTriggeredFinal = false;

    const clearSilenceTimer = () => {
      if (silenceTimer) {
        clearTimeout(silenceTimer);
        silenceTimer = null;
      }
    };

    recognizer.onstart = () => {
      hasTriggeredFinal = false;
      latestTranscript = '';
      callbacks.onStart();
    };

    recognizer.onresult = (event: any) => {
      clearSilenceTimer();
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      if (finalTranscript) {
        hasTriggeredFinal = true;
        clearSilenceTimer();
        callbacks.onResult(finalTranscript.trim(), true);
        try {
          recognizer.stop();
        } catch {
          // ignore
        }
      } else if (interimTranscript) {
        latestTranscript = interimTranscript.trim();
        callbacks.onResult(latestTranscript, false);

        // Fast Silence Finalizer:
        // WebSpeech often lingers for 1.5s after user stops talking.
        // We set a brief silence timer (e.g. 700ms) to auto-finalize and respond with minimum delay.
        const timeout = callbacks.silenceTimeoutMs || 700;
        silenceTimer = setTimeout(() => {
          if (!hasTriggeredFinal && latestTranscript.length > 0) {
            hasTriggeredFinal = true;
            callbacks.onResult(latestTranscript, true);
            try {
              recognizer.stop();
            } catch {
              // ignore
            }
          }
        }, timeout);
      }
    };

    recognizer.onerror = (event: any) => {
      clearSilenceTimer();
      console.warn('Speech recognition error:', event.error);
      callbacks.onError(event.error);
    };

    recognizer.onend = () => {
      clearSilenceTimer();
      // If ended naturally and we have a transcript that was not finalized, finalize it now
      if (!hasTriggeredFinal && latestTranscript.length > 0) {
        hasTriggeredFinal = true;
        callbacks.onResult(latestTranscript, true);
      }
      callbacks.onEnd();
    };

    return recognizer;
  } catch (err: any) {
    console.warn('Failed to initialize SpeechRecognition:', err);
    return null;
  }
}
