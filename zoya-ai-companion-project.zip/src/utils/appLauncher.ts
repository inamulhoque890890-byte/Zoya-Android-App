// Comprehensive Android App Launcher Utility
// Uses fastest native Android Intent schemes, specialized URI protocols, and web fallbacks.

export interface AndroidAppDef {
  id: string;
  name: string;
  aliases: string[];
  category: 'media' | 'social' | 'communication' | 'tools' | 'navigation' | 'productivity';
  icon: string;
  color: string;
  packageName: string;
  // Native Android Intent URI (standard in Chrome for Android / PWAs / WebViews)
  intentUri: string;
  // Direct custom protocol (e.g., vnd.youtube://, whatsapp://, etc.)
  nativeScheme?: string;
  // Web fallback URL
  fallbackUrl: string;
}

export const ANDROID_APPS: AndroidAppDef[] = [
  {
    id: 'youtube',
    name: 'YouTube',
    aliases: [
      'youtube',
      'yt',
      'you tube',
      'यूट्यूब',
      'युट्यूब',
      'यूटुब',
      'youtube app',
      'play video',
      'play music on youtube',
      'video',
      'videos',
      'यूट्यूब चलाओ',
      'यूट्यूब खोलो',
    ],
    category: 'media',
    icon: 'PlayCircle',
    color: '#EF4444',
    packageName: 'com.google.android.youtube',
    intentUri: 'intent://www.youtube.com/#Intent;package=com.google.android.youtube;scheme=https;end',
    nativeScheme: 'vnd.youtube://',
    fallbackUrl: 'https://www.youtube.com',
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    aliases: [
      'whatsapp',
      'what\'s app',
      'whats app',
      'wa',
      'व्हाट्सएप',
      'व्हाट्सऐप',
      'व्हाट्स एप',
      'whatsapp messenger',
    ],
    category: 'communication',
    icon: 'MessageCircle',
    color: '#22C55E',
    packageName: 'com.whatsapp',
    intentUri: 'intent://send#Intent;package=com.whatsapp;scheme=whatsapp;end',
    nativeScheme: 'whatsapp://send',
    fallbackUrl: 'https://web.whatsapp.com',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    aliases: [
      'instagram',
      'insta',
      'ig',
      'reels',
      'इंस्टाग्राम',
      'इंस्टा',
      'instagram app',
    ],
    category: 'social',
    icon: 'Camera',
    color: '#E1306C',
    packageName: 'com.instagram.android',
    intentUri: 'intent://instagram.com/#Intent;package=com.instagram.android;scheme=https;end',
    nativeScheme: 'instagram://app',
    fallbackUrl: 'https://www.instagram.com',
  },
  {
    id: 'spotify',
    name: 'Spotify',
    aliases: [
      'spotify',
      'music',
      'songs',
      'स्पॉटिफ़ाई',
      'गाना',
      'म्यूजिक',
      'गाने',
      'संगीत',
      'गाना चलाओ',
      'spotify music',
      'play songs',
      'play music',
    ],
    category: 'media',
    icon: 'Music',
    color: '#1DB954',
    packageName: 'com.spotify.music',
    intentUri: 'intent://open.spotify.com/#Intent;package=com.spotify.music;scheme=https;end',
    nativeScheme: 'spotify://',
    fallbackUrl: 'https://open.spotify.com',
  },
  {
    id: 'camera',
    name: 'Camera',
    aliases: [
      'camera',
      'open camera',
      'take photo',
      'take picture',
      'selfie',
      'cam',
      'कैमरा',
      'फोटो',
      'तस्वीर',
      'सेल्फी',
      'फोटो खींचो',
    ],
    category: 'media',
    icon: 'Aperture',
    color: '#06B6D4',
    packageName: 'com.android.camera',
    intentUri: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end',
    fallbackUrl: '',
  },
  {
    id: 'maps',
    name: 'Google Maps',
    aliases: [
      'maps',
      'google maps',
      'navigation',
      'gps',
      'directions',
      'navigate',
      'मैप्स',
      'गूगल मैप्स',
      'नक्शा',
      'नेविगेशन',
      'रास्ता',
    ],
    category: 'navigation',
    icon: 'Compass',
    color: '#3B82F6',
    packageName: 'com.google.android.apps.maps',
    intentUri: 'intent://maps.google.com/#Intent;package=com.google.android.apps.maps;scheme=https;end',
    nativeScheme: 'geo:0,0?q=',
    fallbackUrl: 'https://www.google.com/maps',
  },
  {
    id: 'chrome',
    name: 'Google Chrome',
    aliases: [
      'chrome',
      'google chrome',
      'browser',
      'internet',
      'web browser',
      'क्रोम',
      'ब्राउज़र',
    ],
    category: 'tools',
    icon: 'Globe',
    color: '#F59E0B',
    packageName: 'com.android.chrome',
    intentUri: 'intent://www.google.com/#Intent;package=com.android.chrome;scheme=https;end',
    nativeScheme: 'googlechrome://',
    fallbackUrl: 'https://www.google.com',
  },
  {
    id: 'gmail',
    name: 'Gmail',
    aliases: [
      'gmail',
      'google mail',
      'email',
      'mail',
      'inbox',
      'जीमेल',
      'ईमेल',
      'मेल',
    ],
    category: 'communication',
    icon: 'Mail',
    color: '#EA4335',
    packageName: 'com.google.android.gm',
    intentUri: 'intent://#Intent;package=com.google.android.gm;scheme=mailto;end',
    nativeScheme: 'googlegmail://',
    fallbackUrl: 'https://mail.google.com',
  },
  {
    id: 'dialer',
    name: 'Phone / Dialer',
    aliases: [
      'dialer',
      'phone',
      'call',
      'make a call',
      'phone dialer',
      'phone app',
      'फोन',
      'कॉल',
      'डायल',
      'फोन लगाओ',
    ],
    category: 'communication',
    icon: 'Phone',
    color: '#10B981',
    packageName: 'com.android.dialer',
    intentUri: 'intent:#Intent;action=android.intent.action.DIAL;end',
    nativeScheme: 'tel:',
    fallbackUrl: 'tel:',
  },
  {
    id: 'messages',
    name: 'Messages / SMS',
    aliases: [
      'messages',
      'sms',
      'text message',
      'messaging',
      'texts',
      'मैसेज',
      'एसएमएस',
    ],
    category: 'communication',
    icon: 'MessageSquare',
    color: '#6366F1',
    packageName: 'com.google.android.apps.messaging',
    intentUri: 'intent:#Intent;action=android.intent.action.SENDTO;end',
    nativeScheme: 'sms:',
    fallbackUrl: 'sms:',
  },
  {
    id: 'calculator',
    name: 'Calculator',
    aliases: [
      'calculator',
      'calc',
      'calculate',
      'कैलकुलेटर',
      'हिसाब',
    ],
    category: 'tools',
    icon: 'Calculator',
    color: '#8B5CF6',
    packageName: 'com.google.android.calculator',
    intentUri: 'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_CALCULATOR;end',
    fallbackUrl: 'https://www.google.com/search?q=calculator',
  },
  {
    id: 'clock',
    name: 'Clock & Alarms',
    aliases: [
      'clock',
      'alarm',
      'alarms',
      'stopwatch',
      'timer',
      'अलार्म',
      'घड़ी',
      'टाइमर',
    ],
    category: 'tools',
    icon: 'Clock',
    color: '#F97316',
    packageName: 'com.google.android.deskclock',
    intentUri: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end',
    fallbackUrl: '',
  },
  {
    id: 'playstore',
    name: 'Play Store',
    aliases: [
      'play store',
      'google play',
      'app store',
      'playstore',
      'download apps',
      'प्ले स्टोर',
      'ऐप स्टोर',
    ],
    category: 'tools',
    icon: 'ShoppingBag',
    color: '#00A859',
    packageName: 'com.android.vending',
    intentUri: 'intent://#Intent;package=com.android.vending;scheme=market;end',
    nativeScheme: 'market://',
    fallbackUrl: 'https://play.google.com/store',
  },
  {
    id: 'settings',
    name: 'Android Settings',
    aliases: [
      'settings',
      'phone settings',
      'system settings',
      'android settings',
      'सेटिंग्स',
      'सेटिंग',
      'फोन सेटिंग्स',
    ],
    category: 'tools',
    icon: 'Settings',
    color: '#64748B',
    packageName: 'com.android.settings',
    intentUri: 'intent:#Intent;action=android.settings.SETTINGS;end',
    fallbackUrl: '',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    aliases: ['facebook', 'fb', 'meta', 'फेसबुक'],
    category: 'social',
    icon: 'Facebook',
    color: '#1877F2',
    packageName: 'com.facebook.katana',
    intentUri: 'intent://#Intent;package=com.facebook.katana;scheme=fb;end',
    nativeScheme: 'fb://',
    fallbackUrl: 'https://www.facebook.com',
  },
  {
    id: 'twitter',
    name: 'X / Twitter',
    aliases: ['twitter', 'x', 'x app', 'tweets', 'ट्विटर'],
    category: 'social',
    icon: 'Twitter',
    color: '#1DA1F2',
    packageName: 'com.twitter.android',
    intentUri: 'intent://twitter.com/#Intent;package=com.twitter.android;scheme=https;end',
    nativeScheme: 'twitter://',
    fallbackUrl: 'https://twitter.com',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    aliases: ['telegram', 'tg', 'telegram messenger', 'टेलीग्राम'],
    category: 'communication',
    icon: 'Send',
    color: '#2AABEE',
    packageName: 'org.telegram.messenger',
    intentUri: 'intent://#Intent;package=org.telegram.messenger;scheme=tg;end',
    nativeScheme: 'tg://',
    fallbackUrl: 'https://web.telegram.org',
  },
  {
    id: 'netflix',
    name: 'Netflix',
    aliases: ['netflix', 'movies', 'watch movies', 'नेटफ्लिक्स'],
    category: 'media',
    icon: 'Tv',
    color: '#E50914',
    packageName: 'com.netflix.mediaclient',
    intentUri: 'intent://#Intent;package=com.netflix.mediaclient;scheme=nflx;end',
    nativeScheme: 'nflx://',
    fallbackUrl: 'https://www.netflix.com',
  },
  {
    id: 'photos',
    name: 'Google Photos',
    aliases: ['photos', 'google photos', 'gallery', 'photo gallery', 'pictures', 'गैलरी', 'तस्वीरें'],
    category: 'media',
    icon: 'Image',
    color: '#4285F4',
    packageName: 'com.google.android.apps.photos',
    intentUri: 'intent://#Intent;package=com.google.android.apps.photos;scheme=https;end',
    fallbackUrl: 'https://photos.google.com',
  },
  {
    id: 'reddit',
    name: 'Reddit',
    aliases: ['reddit'],
    category: 'social',
    icon: 'MessageSquare',
    color: '#FF4500',
    packageName: 'com.reddit.frontpage',
    intentUri: 'intent://reddit.com/#Intent;package=com.reddit.frontpage;scheme=https;end',
    nativeScheme: 'reddit://',
    fallbackUrl: 'https://www.reddit.com',
  },
  {
    id: 'snapchat',
    name: 'Snapchat',
    aliases: ['snapchat', 'snap'],
    category: 'social',
    icon: 'Camera',
    color: '#FFFC00',
    packageName: 'com.snapchat.android',
    intentUri: 'intent://#Intent;package=com.snapchat.android;scheme=snapchat;end',
    nativeScheme: 'snapchat://',
    fallbackUrl: 'https://www.snapchat.com',
  },
  {
    id: 'discord',
    name: 'Discord',
    aliases: ['discord'],
    category: 'communication',
    icon: 'MessageCircle',
    color: '#5865F2',
    packageName: 'com.discord',
    intentUri: 'intent://#Intent;package=com.discord;scheme=discord;end',
    nativeScheme: 'discord://',
    fallbackUrl: 'https://discord.com/app',
  },
  {
    id: 'uber',
    name: 'Uber',
    aliases: ['uber', 'cab', 'taxi', 'ride'],
    category: 'navigation',
    icon: 'Car',
    color: '#000000',
    packageName: 'com.ubercab',
    intentUri: 'intent://#Intent;package=com.ubercab;scheme=uber;end',
    nativeScheme: 'uber://',
    fallbackUrl: 'https://m.uber.com',
  },
];

/**
 * Launch an Android application with maximum speed & reliability.
 * Supports optional dynamic query/song to search or play in YouTube or other media/search apps.
 */
export function launchAndroidApp(
  app: AndroidAppDef,
  options?: { query?: string; songName?: string }
): { success: boolean; message: string; method?: string } {
  const query = options?.query || options?.songName;

  // Haptic feedback
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  if (android && typeof android.vibrate === 'function') {
    try {
      android.vibrate(35);
    } catch {
      // ignore
    }
  } else if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate(35);
    } catch {
      // ignore
    }
  }

  // Camera special handling: invoke native camera capture input
  if (app.id === 'camera') {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.setAttribute('capture', 'environment');
      input.style.display = 'none';
      document.body.appendChild(input);
      input.click();
      setTimeout(() => {
        if (document.body.contains(input)) {
          document.body.removeChild(input);
        }
      }, 1000);
      notifyActionExecuted(app, 'camera_viewfinder');
      return { success: true, message: 'Opening Camera viewfinder', method: 'native_camera' };
    } catch {
      // fallback
    }
  }

  // 1. YouTube specialized deep-link query handling
  if (app.id === 'youtube' && query) {
    const encodedQuery = encodeURIComponent(query);
    const ytAppIntent = `intent://www.youtube.com/results?search_query=${encodedQuery}#Intent;package=com.google.android.youtube;scheme=https;end`;
    const ytAppNative = `vnd.youtube://results?search_query=${encodedQuery}`;
    const ytWebUrl = `https://www.youtube.com/results?search_query=${encodedQuery}`;

    // Try native android bridge first
    if (android && typeof android.launchApp === 'function' && app.packageName) {
      try {
        const launched = android.launchApp(app.packageName, ytAppNative);
        if (launched) {
          notifyActionExecuted(app, 'native_bridge_yt_song');
          return { success: true, message: `Playing "${query}" on YouTube`, method: 'native_bridge' };
        }
      } catch (e) {
        console.warn('Native YouTube query launch failed, fallback to Intent/web:', e);
      }
    }

    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
    if (isAndroid) {
      try {
        const link = document.createElement('a');
        link.href = ytAppIntent;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
          if (document.body.contains(link)) {
            document.body.removeChild(link);
          }
        }, 500);

        setTimeout(() => {
          if (document.hidden) return;
          try {
            window.open(ytWebUrl, '_blank', 'noopener,noreferrer');
          } catch {
            // ignore
          }
        }, 1200);

        notifyActionExecuted(app, 'youtube_song_intent');
        return { success: true, message: `Playing "${query}" on YouTube`, method: 'youtube_song_intent' };
      } catch {
        window.open(ytWebUrl, '_blank', 'noopener,noreferrer');
        return { success: true, message: `Playing "${query}" on YouTube`, method: 'web_fallback' };
      }
    } else {
      window.open(ytWebUrl, '_blank', 'noopener,noreferrer');
      notifyActionExecuted(app, 'web_fallback_song');
      return { success: true, message: `Playing "${query}" on YouTube`, method: 'web_fallback' };
    }
  }

  // 2. Native Android App Bridge Launching
  if (android && typeof android.launchApp === 'function' && app.packageName) {
    try {
      const launchUri = app.id === 'youtube'
        ? (app.nativeScheme || app.fallbackUrl)
        : (app.fallbackUrl || app.intentUri || '');
      const launched = android.launchApp(app.packageName, launchUri);
      if (launched) {
        notifyActionExecuted(app, 'native_bridge');
        return { success: true, message: `Launching ${app.name} app on Android`, method: 'native_bridge' };
      }
    } catch (e) {
      console.warn('Native launch failed, proceeding with intent URI fallback:', e);
    }
  }

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);

  // Preferred target URI
  let targetUri = app.fallbackUrl;
  if (isAndroid) {
    targetUri = app.nativeScheme || app.intentUri || app.fallbackUrl;
  }

  // Attempt intent or deep link launch
  try {
    if (targetUri.startsWith('tel:') || targetUri.startsWith('sms:') || targetUri.startsWith('mailto:')) {
      window.location.href = targetUri;
      notifyActionExecuted(app, 'protocol_scheme');
      return { success: true, message: `Opened ${app.name}`, method: 'protocol_scheme' };
    }

    if (isAndroid && (targetUri.startsWith('intent:') || targetUri.includes('://'))) {
      // Create hidden link to trigger Android Intent without navigation abortion
      const link = document.createElement('a');
      link.href = targetUri;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
      }, 500);

      // Fallback timer: if the app is not installed or intent fails, open fallback URL
      if (app.fallbackUrl && app.fallbackUrl.startsWith('http')) {
        setTimeout(() => {
          if (document.hidden) return; // User successfully switched into the native app
          try {
            window.open(app.fallbackUrl, '_blank', 'noopener,noreferrer');
          } catch {
            // popup blocked, handled gracefully
          }
        }, 1200);
      }
      notifyActionExecuted(app, 'android_intent');
      return { success: true, message: `Launching ${app.name}`, method: 'android_intent' };
    }

    // Standard web fallback / desktop / browser
    if (app.fallbackUrl) {
      const link = document.createElement('a');
      link.href = app.fallbackUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
      }, 500);

      try {
        window.open(app.fallbackUrl, '_blank', 'noopener,noreferrer');
      } catch {
        // window.open blocked
      }
      notifyActionExecuted(app, 'web_fallback');
      return { success: true, message: `Opened ${app.name}`, method: 'web_fallback' };
    }

    if (app.intentUri) {
      window.location.href = app.intentUri;
      notifyActionExecuted(app, 'intent_uri');
      return { success: true, message: `Launched ${app.name}`, method: 'intent_uri' };
    }

    return { success: true, message: `Launching ${app.name}` };
  } catch (err: any) {
    console.warn(`Failed to launch ${app.name}:`, err);
    if (app.fallbackUrl) {
      try {
        window.open(app.fallbackUrl, '_blank', 'noopener,noreferrer');
      } catch {
        // ignore
      }
    }
    notifyActionExecuted(app, 'error_fallback');
    return { success: true, message: `Opened ${app.name}` };
  }
}

/**
 * Dedicated helper to launch YouTube and play or search for a specific requested song/video
 */
export function launchYouTubeWithSong(songQuery: string): { success: boolean; message: string } {
  const ytApp = findAndroidApp('youtube') || ANDROID_APPS[0];
  return launchAndroidApp(ytApp, { songName: songQuery });
}

/**
 * Dedicated helper to launch WhatsApp with pre-filled message and optional contact
 */
export function launchWhatsAppWithMessage(
  recipient?: string,
  message?: string
): { success: boolean; message: string; method?: string } {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  const cleanMsg = (message || '').trim();
  const encodedMsg = encodeURIComponent(cleanMsg);

  // If phone number is given
  const isPhoneNumber = recipient && /^\+?[0-9\s-]{7,15}$/.test(recipient.trim());
  let targetUrl = 'https://api.whatsapp.com/send?';
  if (isPhoneNumber) {
    const cleanNum = recipient!.replace(/[^0-9]/g, '');
    targetUrl += `phone=${cleanNum}&`;
  }
  if (encodedMsg) {
    targetUrl += `text=${encodedMsg}`;
  }

  const nativeScheme = isPhoneNumber
    ? `whatsapp://send?phone=${recipient!.replace(/[^0-9]/g, '')}${encodedMsg ? `&text=${encodedMsg}` : ''}`
    : `whatsapp://send?text=${encodedMsg}`;

  // Native bridge if available
  if (android && typeof android.launchApp === 'function') {
    try {
      const launched = android.launchApp('com.whatsapp', nativeScheme);
      if (launched) {
        return { success: true, message: `Opening WhatsApp chat${recipient ? ` with ${recipient}` : ''}`, method: 'native_bridge' };
      }
    } catch {
      // fallback
    }
  }

  // Web / intent launch
  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    const intentUri = `intent://send?text=${encodedMsg}#Intent;package=com.whatsapp;scheme=whatsapp;end`;
    const link = document.createElement('a');
    link.href = intentUri;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) document.body.removeChild(link);
    }, 500);

    setTimeout(() => {
      if (document.hidden) return;
      try {
        window.open(targetUrl, '_blank', 'noopener,noreferrer');
      } catch {
        // ignore
      }
    }, 1200);
    return { success: true, message: `Opening WhatsApp${recipient ? ` for ${recipient}` : ''}`, method: 'intent' };
  }

  window.open(targetUrl, '_blank', 'noopener,noreferrer');
  return { success: true, message: `Opening WhatsApp${recipient ? ` for ${recipient}` : ''}`, method: 'web' };
}

/**
 * Dedicated helper to launch Instagram to a specific profile or search query
 */
export function launchInstagramUser(
  usernameOrQuery: string
): { success: boolean; message: string; method?: string } {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  const clean = usernameOrQuery.replace(/^@/, '').trim();
  const igUrl = `https://www.instagram.com/${encodeURIComponent(clean)}/`;
  const igIntent = `intent://instagram.com/_u/${encodeURIComponent(clean)}#Intent;package=com.instagram.android;scheme=https;end`;

  if (android && typeof android.launchApp === 'function') {
    try {
      const launched = android.launchApp('com.instagram.android', `instagram://user?username=${encodeURIComponent(clean)}`);
      if (launched) {
        return { success: true, message: `Opening Instagram profile @${clean}`, method: 'native_bridge' };
      }
    } catch {
      // fallback
    }
  }

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    const link = document.createElement('a');
    link.href = igIntent;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) document.body.removeChild(link);
    }, 500);

    setTimeout(() => {
      if (document.hidden) return;
      window.open(igUrl, '_blank', 'noopener,noreferrer');
    }, 1200);
    return { success: true, message: `Opening Instagram profile @${clean}`, method: 'intent' };
  }

  window.open(igUrl, '_blank', 'noopener,noreferrer');
  return { success: true, message: `Opening Instagram profile @${clean}`, method: 'web' };
}

/**
 * Dedicated helper to launch Phone Dialer with pre-dialed number or contact
 */
export function launchPhoneCall(
  recipient: string
): { success: boolean; message: string; method?: string } {
  const cleanNumber = recipient.replace(/[^\d+*#]/g, '');
  const telUri = cleanNumber ? `tel:${cleanNumber}` : 'tel:';

  try {
    window.location.href = telUri;
    return { success: true, message: `Dialing ${recipient}`, method: 'tel_protocol' };
  } catch {
    return { success: false, message: `Could not open dialer for ${recipient}` };
  }
}

/**
 * Dedicated helper to launch SMS messaging app with recipient and message body
 */
export function launchSMS(
  recipient: string,
  message?: string
): { success: boolean; message: string; method?: string } {
  const cleanNumber = recipient.replace(/[^\d+]/g, '');
  const encodedMsg = message ? encodeURIComponent(message) : '';
  const smsUri = cleanNumber
    ? `sms:${cleanNumber}?body=${encodedMsg}`
    : `sms:?body=${encodedMsg}`;

  try {
    window.location.href = smsUri;
    return { success: true, message: `Opening SMS composer${recipient ? ` for ${recipient}` : ''}`, method: 'sms_protocol' };
  } catch {
    return { success: false, message: 'Could not launch SMS app' };
  }
}

/**
 * Dedicated helper to launch Google Maps turn-by-turn navigation or directions
 */
export function launchNavigation(
  destination: string
): { success: boolean; message: string; method?: string } {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  const encodedDest = encodeURIComponent(destination.trim());
  const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedDest}`;
  const nativeNav = `google.navigation:q=${encodedDest}`;

  if (android && typeof android.launchApp === 'function') {
    try {
      const launched = android.launchApp('com.google.android.apps.maps', nativeNav);
      if (launched) {
        return { success: true, message: `Navigating to ${destination}`, method: 'native_bridge' };
      }
    } catch {
      // fallback
    }
  }

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    const navIntent = `intent://maps.google.com/maps?daddr=${encodedDest}#Intent;package=com.google.android.apps.maps;scheme=https;end`;
    const link = document.createElement('a');
    link.href = navIntent;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) document.body.removeChild(link);
    }, 500);

    setTimeout(() => {
      if (document.hidden) return;
      window.open(mapsUrl, '_blank', 'noopener,noreferrer');
    }, 1200);
    return { success: true, message: `Navigating to ${destination}`, method: 'intent' };
  }

  window.open(mapsUrl, '_blank', 'noopener,noreferrer');
  return { success: true, message: `Opening directions to ${destination}`, method: 'web' };
}

/**
 * Dedicated helper to launch Spotify and play/search a specific song
 */
export function launchSpotifyWithSong(
  songQuery: string
): { success: boolean; message: string; method?: string } {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  const encodedSong = encodeURIComponent(songQuery.trim());
  const webUrl = `https://open.spotify.com/search/${encodedSong}`;
  const nativeUri = `spotify:search:${encodedSong}`;

  if (android && typeof android.launchApp === 'function') {
    try {
      const launched = android.launchApp('com.spotify.music', nativeUri);
      if (launched) {
        return { success: true, message: `Playing "${songQuery}" on Spotify`, method: 'native_bridge' };
      }
    } catch {
      // fallback
    }
  }

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    const intentUri = `intent://open.spotify.com/search/${encodedSong}#Intent;package=com.spotify.music;scheme=https;end`;
    const link = document.createElement('a');
    link.href = intentUri;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) document.body.removeChild(link);
    }, 500);

    setTimeout(() => {
      if (document.hidden) return;
      window.open(webUrl, '_blank', 'noopener,noreferrer');
    }, 1200);
    return { success: true, message: `Playing "${songQuery}" on Spotify`, method: 'intent' };
  }

  window.open(webUrl, '_blank', 'noopener,noreferrer');
  return { success: true, message: `Playing "${songQuery}" on Spotify`, method: 'web' };
}

/**
 * Dedicated helper to launch Web Search via Google
 */
export function launchWebSearch(
  query: string
): { success: boolean; message: string; method?: string } {
  const encoded = encodeURIComponent(query.trim());
  const searchUrl = `https://www.google.com/search?q=${encoded}`;
  window.open(searchUrl, '_blank', 'noopener,noreferrer');
  return { success: true, message: `Searching for "${query}"`, method: 'web' };
}

/**
 * Dedicated helper to launch Camera with capture
 */
export function launchCamera(
  _mode: 'photo' | 'selfie' = 'photo'
): { success: boolean; message: string; method?: string } {
  try {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.setAttribute('capture', _mode === 'selfie' ? 'user' : 'environment');
    input.style.display = 'none';
    document.body.appendChild(input);
    input.click();
    setTimeout(() => {
      if (document.body.contains(input)) {
        document.body.removeChild(input);
      }
    }, 1000);
    return { success: true, message: 'Opening camera viewfinder', method: 'camera_capture' };
  } catch {
    const camApp = findAndroidApp('camera');
    if (camApp) return launchAndroidApp(camApp);
    return { success: false, message: 'Camera unavailable' };
  }
}

/**
 * Dedicated helper to trigger timer on Android or Web
 */
export function launchClockTimer(
  seconds: number,
  label?: string
): { success: boolean; message: string; method?: string } {
  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    const intentUri = `intent:#Intent;action=android.intent.action.SET_TIMER;i.android.intent.extra.alarm.LENGTH=${seconds};${label ? `S.android.intent.extra.alarm.MESSAGE=${encodeURIComponent(label)};` : ''}end`;
    const link = document.createElement('a');
    link.href = intentUri;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) document.body.removeChild(link);
    }, 500);
    return { success: true, message: `Timer set for ${Math.round(seconds / 60)} minutes`, method: 'android_timer_intent' };
  }

  // Web fallback: trigger Google timer search
  const mins = Math.max(1, Math.round(seconds / 60));
  window.open(`https://www.google.com/search?q=set+timer+for+${mins}+minutes`, '_blank', 'noopener,noreferrer');
  return { success: true, message: `Timer set for ${mins} minutes`, method: 'web_timer' };
}

function notifyActionExecuted(app: AndroidAppDef, method: string) {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(
        new CustomEvent('zoya:action_executed', {
          detail: {
            type: 'app',
            app,
            method,
            timestamp: Date.now(),
          },
        })
      );
    } catch {
      // ignore
    }
  }
}

/**
 * Clean Hindi, Hinglish, Assamese, and English action verbs and suffixes
 * to isolate the core app target.
 */
function stripAppAffixes(text: string): string {
  let cleaned = text
    .toLowerCase()
    .replace(/[?.!,।;:]/g, ' ')
    .trim();

  // Strip prefixes
  const prefixes = [
    'open ',
    'launch ',
    'start ',
    'play ',
    'run ',
    'go to ',
    'switch to ',
    'please open ',
    'can you open ',
    'খোलो ',
    'खोल ',
    'चलाओ ',
    'चालू करो ',
    'शुरू करो ',
    'बजाओ ',
    'खोলা ',
    'খোলক ',
  ];
  for (const prefix of prefixes) {
    if (cleaned.startsWith(prefix)) {
      cleaned = cleaned.slice(prefix.length).trim();
    }
  }

  // Strip suffixes
  const suffixes = [
    ' खोलो ना',
    ' खोल दो ना',
    ' खोल दो',
    ' खोलो',
    ' खोल',
    ' open करो',
    ' open कर दो',
    ' open kardo',
    ' open karo',
    ' chala do',
    ' chalao',
    ' kholo',
    ' khol do',
    ' चला दो',
    ' चलाओ',
    ' चालू करो',
    ' चालू कर दो',
    ' शुरू करो',
    ' बजाओ',
    ' दिखाओ',
    ' लगाओ',
    ' app',
    ' ऐप',
    ' খোলা',
    ' খুলি দিয়া',
    ' খোলক',
  ];
  for (const suffix of suffixes) {
    if (cleaned.endsWith(suffix)) {
      cleaned = cleaned.slice(0, -suffix.length).trim();
    }
  }

  return cleaned.trim();
}

/**
 * Find matching Android app by name or alias, with multi-lingual support.
 */
export function findAndroidApp(query: string): AndroidAppDef | null {
  const raw = query.trim().toLowerCase();
  if (!raw) return null;

  const candidates = [raw, stripAppAffixes(raw)];

  for (const clean of candidates) {
    if (!clean) continue;

    // 1. Exact match on ID or Name
    for (const app of ANDROID_APPS) {
      if (app.id === clean || app.name.toLowerCase() === clean) {
        return app;
      }
    }

    // 2. Exact match on any alias
    for (const app of ANDROID_APPS) {
      if (app.aliases.some((a) => a.toLowerCase() === clean)) {
        return app;
      }
    }

    // 3. Substring match: query contains alias, or alias contains query
    for (const app of ANDROID_APPS) {
      if (
        app.aliases.some(
          (a) =>
            clean.includes(a.toLowerCase()) ||
            (a.length > 2 && a.toLowerCase().includes(clean))
        )
      ) {
        return app;
      }
    }
  }

  return null;
}
