import { AndroidActionItem } from '../types';
import { findAndroidApp, launchAndroidApp } from './appLauncher';
import { promptFilePicker } from './fileCodingAssistant';

export const ANDROID_ACTIONS: AndroidActionItem[] = [
  {
    id: 'dialer',
    title: 'Phone Dialer',
    description: 'Open native Android phone dialer to call friends or family',
    category: 'communication',
    icon: 'PhoneCall',
    actionType: 'tel',
    target: 'tel:',
    badge: 'Standard Intent',
  },
  {
    id: 'sms',
    title: 'Send SMS',
    description: 'Launch native Android Messages app to draft a text',
    category: 'communication',
    icon: 'MessageSquare',
    actionType: 'sms',
    target: 'sms:',
    badge: 'Standard Intent',
  },
  {
    id: 'whatsapp',
    title: 'WhatsApp Chat',
    description: 'Send quick message via WhatsApp Messenger',
    category: 'communication',
    icon: 'Share2',
    actionType: 'url',
    target: 'https://wa.me/',
    badge: 'App Intent',
  },
  {
    id: 'gmail',
    title: 'Email / Gmail',
    description: 'Compose an email in Gmail or default Android mail app',
    category: 'communication',
    icon: 'Mail',
    actionType: 'mailto',
    target: 'mailto:',
    badge: 'Standard Intent',
  },
  {
    id: 'maps',
    title: 'Google Maps',
    description: 'Open Google Maps for turn-by-turn navigation & places',
    category: 'navigation',
    icon: 'Compass',
    actionType: 'url',
    target: 'https://www.google.com/maps',
    badge: 'Navigation',
  },
  {
    id: 'torch',
    title: 'Flashlight / Torch',
    description: 'Toggle rear camera LED flash using Android camera hardware',
    category: 'tools',
    icon: 'Flashlight',
    actionType: 'torch',
    badge: 'Hardware API',
  },
  {
    id: 'timer',
    title: 'Timer & Alarm',
    description: 'Set quick countdown timers with audio chimes and vibration',
    category: 'tools',
    icon: 'Clock',
    actionType: 'timer',
    badge: 'Device Utility',
  },
  {
    id: 'wakeLock',
    title: 'Keep Screen Awake',
    description: 'Prevent phone screen from sleeping during conversations',
    category: 'tools',
    icon: 'Sun',
    actionType: 'wakeLock',
    badge: 'Power Mgmt',
  },
  {
    id: 'search',
    title: 'Google Search',
    description: 'Instant web lookup for facts, news, and queries',
    category: 'navigation',
    icon: 'Search',
    actionType: 'url',
    target: 'https://www.google.com',
    badge: 'Web Tool',
  },
  {
    id: 'youtube',
    title: 'YouTube',
    description: 'Launch YouTube app or web for music and videos',
    category: 'media',
    icon: 'PlayCircle',
    actionType: 'url',
    target: 'https://www.youtube.com',
    badge: 'Media App',
  },
  {
    id: 'camera',
    title: 'Camera & Gallery',
    description: 'Trigger phone camera viewfinder or select photos',
    category: 'media',
    icon: 'Camera',
    actionType: 'url',
    badge: 'Media API',
  },
  {
    id: 'share',
    title: 'Android Share Sheet',
    description: 'Share text or links with any installed Android app',
    category: 'tools',
    icon: 'Share2',
    actionType: 'share',
    badge: 'System Sheet',
  },
  {
    id: 'file_picker',
    title: 'Files & Code Inspector',
    description: 'Safely inspect documents, code files, or scripts on Android',
    category: 'tools',
    icon: 'FolderOpen',
    actionType: 'file',
    badge: 'Sandbox Safe',
  },
];

// Torch controller
let activeMediaStream: MediaStream | null = null;
let activeTrack: MediaStreamTrack | null = null;
let isTorchActive = false;

export async function toggleFlashlight(): Promise<{ active: boolean; error?: string }> {
  // 1. Native Android Bridge
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  if (android && typeof android.toggleTorch === 'function') {
    try {
      const nowActive = android.toggleTorch();
      isTorchActive = Boolean(nowActive);
      return { active: isTorchActive };
    } catch (e: any) {
      return { active: false, error: e?.message || 'Native torch failed' };
    }
  }

  // 2. Web MediaStream API Fallback
  try {
    if (isTorchActive && activeTrack) {
      // Turn off
      await (activeTrack as any).applyConstraints({ advanced: [{ torch: false }] });
      activeTrack.stop();
      activeMediaStream?.getTracks().forEach((t) => t.stop());
      activeMediaStream = null;
      activeTrack = null;
      isTorchActive = false;
      return { active: false };
    }

    // Turn on
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return { active: false, error: 'Camera hardware API not supported on this browser' };
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' },
    });

    const track = stream.getVideoTracks()[0];
    if (!track) {
      return { active: false, error: 'No rear camera found' };
    }

    const capabilities = (track as any).getCapabilities?.() || {};
    if (!capabilities.torch) {
      // Turn off stream
      track.stop();
      return { active: false, error: 'Torch constraint not supported by this camera hardware' };
    }

    await (track as any).applyConstraints({
      advanced: [{ torch: true }],
    });

    activeMediaStream = stream;
    activeTrack = track;
    isTorchActive = true;
    return { active: true };
  } catch (err: any) {
    console.warn('Flashlight error:', err);
    return { active: false, error: err?.message || 'Unable to access camera flash' };
  }
}

export function getTorchStatus(): boolean {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  if (android && typeof android.isTorchOn === 'function') {
    return android.isTorchOn();
  }
  return isTorchActive;
}

// Wake Lock controller
let activeWakeLock: any = null;

export async function toggleScreenWakeLock(): Promise<{ active: boolean; error?: string }> {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  if (android && typeof android.keepScreenAwake === 'function') {
    try {
      const nextState = !activeWakeLock;
      android.keepScreenAwake(nextState);
      activeWakeLock = nextState ? true : null;
      return { active: nextState };
    } catch (e: any) {
      return { active: false, error: e?.message || 'Native wakelock failed' };
    }
  }

  try {
    if (activeWakeLock) {
      await activeWakeLock.release();
      activeWakeLock = null;
      return { active: false };
    }

    if ('wakeLock' in navigator && (navigator as any).wakeLock) {
      activeWakeLock = await (navigator as any).wakeLock.request('screen');
      activeWakeLock.addEventListener('release', () => {
        activeWakeLock = null;
      });
      return { active: true };
    } else {
      return { active: false, error: 'Screen Wake Lock API not supported on this browser.' };
    }
  } catch (err: any) {
    return { active: false, error: err?.message || 'WakeLock request rejected' };
  }
}

export function getWakeLockStatus(): boolean {
  return Boolean(activeWakeLock);
}

// Battery API
export async function getDeviceBatteryInfo(): Promise<{
  supported: boolean;
  level?: number;
  charging?: boolean;
}> {
  const android = typeof window !== 'undefined' ? (window as any).Android : null;
  if (android && typeof android.getBatteryLevel === 'function') {
    try {
      const level = android.getBatteryLevel();
      const charging = typeof android.isBatteryCharging === 'function' ? android.isBatteryCharging() : false;
      if (level >= 0) {
        return {
          supported: true,
          level,
          charging,
        };
      }
    } catch {
      // ignore
    }
  }

  if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
    try {
      const battery: any = await (navigator as any).getBattery();
      return {
        supported: true,
        level: Math.round((battery.level || 1) * 100),
        charging: Boolean(battery.charging),
      };
    } catch {
      return { supported: false };
    }
  }
  return { supported: false };
}

// Execute an Android Action
export async function executeAndroidAction(
  action: AndroidActionItem,
  payload?: { phone?: string; message?: string; query?: string }
): Promise<{ success: boolean; message?: string }> {
  // Haptic feedback
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    navigator.vibrate(35);
  }

  switch (action.actionType) {
    case 'tel': {
      const number = payload?.phone || '';
      window.location.href = `tel:${number}`;
      return { success: true, message: `Opened Phone Dialer ${number ? `(${number})` : ''}` };
    }
    case 'sms': {
      const number = payload?.phone || '';
      const text = encodeURIComponent(payload?.message || '');
      window.location.href = `sms:${number}?body=${text}`;
      return { success: true, message: 'Opened SMS messaging' };
    }
    case 'mailto': {
      const mailtoUrl = `mailto:?subject=${encodeURIComponent('From Zoya Assistant')}&body=${encodeURIComponent(
        payload?.message || ''
      )}`;
      window.location.href = mailtoUrl;
      return { success: true, message: 'Opened email client' };
    }
    case 'url': {
      if (action.id === 'youtube') {
        const ytApp = findAndroidApp('youtube');
        if (ytApp) {
          const res = launchAndroidApp(ytApp);
          return { success: res.success, message: res.message };
        }
      }

      let url = action.target || '';
      if (action.id === 'search' && payload?.query) {
        url = `https://www.google.com/search?q=${encodeURIComponent(payload.query)}`;
      } else if (action.id === 'maps' && payload?.query) {
        url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(payload.query)}`;
      } else if (action.id === 'whatsapp' && payload?.message) {
        url = `https://wa.me/?text=${encodeURIComponent(payload.message)}`;
      }

      const matchedApp = findAndroidApp(action.id);
      if (matchedApp) {
        const res = launchAndroidApp(matchedApp);
        return { success: res.success, message: res.message };
      }

      window.open(url, '_blank', 'noopener,noreferrer');
      return { success: true, message: `Opened ${action.title}` };
    }
    case 'torch': {
      const res = await toggleFlashlight();
      if (res.error) {
        return { success: false, message: res.error };
      }
      return { success: true, message: res.active ? 'Flashlight ON' : 'Flashlight OFF' };
    }
    case 'wakeLock': {
      const res = await toggleScreenWakeLock();
      if (res.error) {
        return { success: false, message: res.error };
      }
      return { success: true, message: res.active ? 'Screen WakeLock Active' : 'Screen WakeLock Released' };
    }
    case 'share': {
      if (navigator.share) {
        try {
          await navigator.share({
            title: 'Zoya AI Assistant',
            text: payload?.message || 'Chatting with Zoya, my personal Android AI companion!',
            url: window.location.href,
          });
          return { success: true, message: 'Shared successfully via Android Share Sheet' };
        } catch (e: any) {
          if (e.name !== 'AbortError') {
            return { success: false, message: 'Share dismissed or failed' };
          }
          return { success: true };
        }
      } else {
        // Fallback: Copy to clipboard
        await navigator.clipboard.writeText(payload?.message || window.location.href);
        return { success: true, message: 'Copied text to Android clipboard!' };
      }
    }
    case 'file': {
      const file = await promptFilePicker();
      if (file) {
        return { success: true, message: `Loaded ${file.name} (${Math.round(file.size / 1024)} KB)` };
      }
      return { success: true, message: 'File selector opened' };
    }
    default:
      return { success: false, message: 'Unsupported action type' };
  }
}
