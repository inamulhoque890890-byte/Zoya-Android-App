/**
 * Zoya Wake Word & Continuous Voice Listening Engine
 * Handles ultra-low latency detection of "Hey Zoya" / "Zoya",
 * audio wake chime playback, and Android native background service sync.
 */

// Web Audio API instant chime generator (zero network asset lag)
export function playWakeChime() {
  if (typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Smooth high two-tone anime assistant chime (E5 -> A5)
    const now = ctx.currentTime;
    
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(659.25, now); // E5
    gain1.gain.setValueAtTime(0.12, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.18);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880.0, now + 0.09); // A5
    gain2.gain.setValueAtTime(0.15, now + 0.09);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.09);
    osc2.stop(now + 0.32);

    // Haptic pulse on wake
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate([40, 30, 60]);
    }
  } catch (e) {
    console.warn('Audio chime failed:', e);
  }
}

export type WakeCallback = (query: string) => void;
export type WakeStatusCallback = (isActive: boolean, error?: string) => void;

class WakeWordManager {
  private isEnabled = false;
  private recognizer: any = null;
  private onWakeCallback: WakeCallback | null = null;
  private onStatusCallback: WakeStatusCallback | null = null;
  private restartTimeout: any = null;
  private isPausedForSpeech = false;
  private consecutiveErrors = 0;

  constructor() {
    // Register global Android Native Bridge callback
    if (typeof window !== 'undefined') {
      (window as any).onAndroidWakeWordDetected = (detectedQuery?: string) => {
        console.log('Android Native Wake Word Detected:', detectedQuery);
        playWakeChime();
        if (this.onWakeCallback) {
          this.onWakeCallback(detectedQuery || '');
        }
      };
    }
  }

  public isListening(): boolean {
    return this.isEnabled;
  }

  public pauseForActiveSpeech(paused: boolean) {
    this.isPausedForSpeech = paused;
    if (paused) {
      this.stopRecognizer();
    } else if (this.isEnabled) {
      this.startRecognizer();
    }
  }

  public setEnabled(
    enabled: boolean,
    onWake: WakeCallback,
    onStatusChange?: WakeStatusCallback
  ) {
    this.onWakeCallback = onWake;
    if (onStatusChange) this.onStatusCallback = onStatusChange;

    this.isEnabled = enabled;

    // Sync with native Android Bridge if available
    if (typeof window !== 'undefined' && (window as any).Android?.setWakeListeningEnabled) {
      try {
        (window as any).Android.setWakeListeningEnabled(enabled);
      } catch (e) {
        console.warn('Failed to notify Android Bridge about wake listening:', e);
      }
    }

    if (enabled) {
      this.consecutiveErrors = 0;
      this.startRecognizer();
    } else {
      this.stopRecognizer();
    }
  }

  private startRecognizer() {
    if (!this.isEnabled || this.isPausedForSpeech) return;
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn('SpeechRecognition API not supported for in-browser wake word.');
      if (this.onStatusCallback) {
        this.onStatusCallback(false, 'Speech recognition not supported in this browser.');
      }
      return;
    }

    try {
      if (this.recognizer) {
        try {
          this.recognizer.abort();
        } catch {
          // ignore
        }
      }

      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';
      rec.maxAlternatives = 1;

      rec.onstart = () => {
        this.consecutiveErrors = 0;
        if (this.onStatusCallback) this.onStatusCallback(true);
      };

      rec.onresult = (event: any) => {
        if (!this.isEnabled || this.isPausedForSpeech) return;

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          const transcript = result[0]?.transcript?.trim().toLowerCase() || '';

          // Look for wake triggers: "hey zoya", "hi zoya", "ok zoya", "zoya"
          const wakeRegex = /\b(hey|hi|hello|ok|okay)?\s*zoya\b/i;
          const match = transcript.match(wakeRegex);

          if (match) {
            console.log('Wake phrase matched:', transcript);
            playWakeChime();

            // Extract following command after "zoya"
            const matchIndex = match.index || 0;
            const fullMatchLen = match[0].length;
            const remainder = transcript.slice(matchIndex + fullMatchLen).trim();
            // Clean up leading punctuation or "please"
            const cleanedQuery = remainder.replace(/^[,.?! ]+/, '').trim();

            // Temporarily pause recognizer to allow processing
            this.stopRecognizer();

            if (this.onWakeCallback) {
              this.onWakeCallback(cleanedQuery);
            }
            return;
          }
        }
      };

      rec.onerror = (event: any) => {
        console.warn('Wake word recognizer event:', event.error);
        if (event.error === 'not-allowed') {
          this.isEnabled = false;
          if (this.onStatusCallback) {
            this.onStatusCallback(false, 'Microphone permission denied.');
          }
          return;
        }

        this.consecutiveErrors++;
        // If consecutive errors are high, slow down retry
        const delay = this.consecutiveErrors > 3 ? 3000 : 800;
        this.scheduleRestart(delay);
      };

      rec.onend = () => {
        // Automatically restart if still enabled (handles silence timeout)
        if (this.isEnabled && !this.isPausedForSpeech) {
          this.scheduleRestart(350);
        }
      };

      this.recognizer = rec;
      rec.start();
    } catch (e: any) {
      console.warn('Failed to start wake word recognizer:', e);
      this.scheduleRestart(1500);
    }
  }

  private scheduleRestart(delayMs = 500) {
    if (this.restartTimeout) clearTimeout(this.restartTimeout);
    if (!this.isEnabled || this.isPausedForSpeech) return;

    this.restartTimeout = setTimeout(() => {
      this.startRecognizer();
    }, delayMs);
  }

  private stopRecognizer() {
    if (this.restartTimeout) clearTimeout(this.restartTimeout);
    if (this.recognizer) {
      try {
        this.recognizer.abort();
      } catch {
        // ignore
      }
      this.recognizer = null;
    }
    if (this.onStatusCallback) {
      this.onStatusCallback(false);
    }
  }
}

export const wakeWordManager = new WakeWordManager();
