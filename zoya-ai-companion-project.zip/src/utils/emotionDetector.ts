import { EmotionType, CompanionMode } from '../types';

/**
 * Intelligent contextual emotion detector for conversational dynamics.
 * Detects the emotional climate from the user's message and recent context,
 * ensuring Zoya immediately mirrors and responds with human-like emotional awareness.
 */
export function detectContextualEmotion(
  text: string,
  mode: CompanionMode = 'girlfriend',
  currentEmotion: EmotionType = 'caring'
): EmotionType {
  if (!text) {
    return mode === 'girlfriend' ? 'loving' : 'friendly';
  }

  const lower = text.toLowerCase().trim();

  // 1. Sadness, grief, loneliness, depression, distress, exhaustion, rough day
  const sadnessPatterns = [
    /\b(sad|crying|cry|depressed|heartbroken|unhappy|down|hurts|hurt|pain|broken|miserable|grief|tears|lonely|alone|hopeless|loss)\b/,
    /\b(exhausted|tired|burnout|drained|rough day|bad day|hard day|awful day|stress|stressed|overwhelmed|struggling|anxious|anxiety|scared|worried)\b/,
    /\b(failed|fail|lost my|nobody likes me|hate myself|feel like giving up|can't do this anymore|miss you|miss him|miss her)\b/,
    // Assamese
    /(দুখীয়া|কান্দি|মন বেয়া|বহুত বেয়া|ভাগৰি পৰিছো|অকলশৰীয়া|চিন্তা|কষ্ট|হতাশ)/,
    // Hindi
    /(उदास|दुखी|रो रहा|रो रही|मन खराब|थक गया|थक गई|अकेला|अकेली|तनाव|परेशान|बहुत बुरा दिन|दर्द)/,
    // Bengali
    /(খারাপ লাগছে|মন খারাপ|কষ্ট|একা লাগছে|হতাশ|কেঁদেছি)/,
  ];

  for (const pattern of sadnessPatterns) {
    if (pattern.test(lower)) {
      return 'caring';
    }
  }

  // 2. Anger, irritation, frustration, venting
  const angerPatterns = [
    /\b(angry|mad|furious|pissed|annoyed|irritated|frustrated|hate this|rage|so mad|shut up|stupid|idiot|worst)\b/,
    /(খং উঠিছে|খং|বিরক্ত)/,
    /(गुस्सा|नाराज|परेशान कर दिया|बकवास|चिढ़)/,
  ];

  for (const pattern of angerPatterns) {
    if (pattern.test(lower)) {
      return 'calmness';
    }
  }

  // 3. Humor, teasing, playful jokes, laughing
  const humorPatterns = [
    /\b(haha|hahaha|hehe|lmao|rofl|lol|jk|just kidding|joke|funny|hilarious|silly|teasing|prank)\b/,
    /(😂|🤣|😹|😆|😜|🤪)/,
    /(ধেমালি|হাঁহি|মজা)/,
    /(मजाक|हँसी|जोक|मजेदार|हँसो)/,
  ];

  for (const pattern of humorPatterns) {
    if (pattern.test(lower)) {
      return 'amused';
    }
  }

  // 4. Excitement, celebration, great news, success
  const excitementPatterns = [
    /\b(yay|woohoo|awesome|amazing|great news|won|passed|got the job|promoted|celebrate|hurray|unbelievable|thrilled|hyped|so happy)\b/,
    /(🎉|🎊|🥳|✨|🏆)/,
    /(বহুত ভাল|জিকিলোঁ|আনন্দ|সফল)/,
    /(जीत गया|जीत गई|कमाल|शानदार|बहुत खुश|पार्टी)/,
  ];

  for (const pattern of excitementPatterns) {
    if (pattern.test(lower)) {
      return 'excited';
    }
  }

  // 5. General happiness, gratitude, affection
  const happinessPatterns = [
    /\b(happy|glad|good mood|wonderful|blessed|thank you so much|thanks zoya|love you|you are the best|sweetheart|darling|babe)\b/,
    /(❤️|💖|💕|🥰|😍|😊)/,
    /(ভাল লাগিছে|ধন্যবাদ|মৰম)/,
    /(प्यार|शुक्रिया|अच्छा लगा|खुश हूँ)/,
  ];

  for (const pattern of happinessPatterns) {
    if (pattern.test(lower)) {
      return mode === 'girlfriend' ? 'loving' : 'happy';
    }
  }

  // 6. Deep questions, curiosity, thinking
  const thoughtfulPatterns = [
    /\b(what do you think|why do you think|meaning of|future|philosophy|wondering|deep thought|advice|what should i do)\b/,
    /(ভাবি আছো|পৰামৰ্শ)/,
    /(सोच रहा हूँ|सोच रही हूँ|सलाह)/,
  ];

  for (const pattern of thoughtfulPatterns) {
    if (pattern.test(lower)) {
      return 'thoughtful';
    }
  }

  // Default baseline for Girlfriend Mode: warm, loving, attentive
  if (mode === 'girlfriend') {
    // If already in a supportive state, gently retain it
    if (currentEmotion === 'caring' || currentEmotion === 'empathy' || currentEmotion === 'supportive') {
      return 'loving';
    }
    return 'loving';
  }

  return mode === 'assistant' ? 'focused' : 'friendly';
}
