import {
  findAndroidApp,
  launchAndroidApp,
  launchYouTubeWithSong,
  launchWhatsAppWithMessage,
  launchInstagramUser,
  launchPhoneCall,
  launchSMS,
  launchNavigation,
  launchSpotifyWithSong,
  launchWebSearch,
  launchCamera,
  launchClockTimer,
} from './appLauncher';
import { toggleFlashlight, toggleScreenWakeLock, getDeviceBatteryInfo } from './androidActions';
import { EmotionType, CompanionMode } from '../types';
import { promptFilePicker } from './fileCodingAssistant';

export interface InstantCommandResult {
  isInstant: boolean;
  actionId?: string;
  replyText: string;
  emotion: EmotionType;
  execute?: () => Promise<{ success: boolean; message?: string }>;
}

export function dispatchActiveTask(type: string, title: string, subtitle?: string) {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(
        new CustomEvent('zoya:active_task', {
          detail: {
            id: `task_${Date.now()}`,
            type,
            title,
            subtitle,
            timestamp: Date.now(),
          },
        })
      );
    } catch {
      // ignore
    }
  }
}

function isHindiOrDevanagari(text: string): boolean {
  if (/[\u0900-\u097F]/.test(text)) return true;
  const hinglishWords = [
    'kholo',
    'khol',
    'chalao',
    'chalu',
    'karo',
    'kardo',
    'batao',
    'dikhao',
    'sunao',
    'kaise',
    'bhai',
    'yaar',
    'meri',
    'mera',
    'lagao',
    'bajao',
  ];
  const lower = text.toLowerCase();
  return hinglishWords.some((w) => lower.includes(w));
}

function isAssamese(text: string): boolean {
  return /[\u0980-\u09FF]/.test(text);
}

/**
 * Normalizes speech transcript / user text for rapid command matching.
 * Strips punctuation, multiple spaces, and common filler words.
 */
export function normalizeCommandText(text: string, zoyaName = 'Zoya'): string {
  let cleaned = text.toLowerCase().trim();

  // Strip punctuation except numbers and script letters
  cleaned = cleaned.replace(/[.,?!:;'"_~@#$%^&*()[\]{}/\\|।]/g, ' ');

  // Remove common polite filler prefixes & Zoya invocations
  const fillers = [
    `hey ${zoyaName.toLowerCase()}`,
    `hi ${zoyaName.toLowerCase()}`,
    `ok ${zoyaName.toLowerCase()}`,
    `okay ${zoyaName.toLowerCase()}`,
    zoyaName.toLowerCase(),
    'hey zoya',
    'hi zoya',
    'ok zoya',
    'okay zoya',
    'हे जोया',
    'जोया',
    'सुनो जोया',
    'please',
    'can you',
    'could you',
    'would you',
    'i want you to',
    'i want to',
    'help me',
    'कृपया',
    'जरा',
  ];

  for (const filler of fillers) {
    if (cleaned.startsWith(filler + ' ')) {
      cleaned = cleaned.slice(filler.length).trim();
    }
  }

  // Reduce spaces
  cleaned = cleaned.replace(/\s+/g, ' ').trim();
  return cleaned;
}

/**
 * Matches high-speed local commands and app launches in < 5ms.
 * Returns an InstantCommandResult if matched, or null to forward to Gemini AI.
 */
export function matchInstantCommand(
  rawText: string,
  mode: CompanionMode = 'assistant',
  userName = 'Inamul',
  zoyaName = 'Zoya'
): InstantCommandResult | null {
  const norm = normalizeCommandText(rawText, zoyaName);
  if (!norm) return null;

  const isGirlfriend = mode === 'girlfriend';
  const isHindi = isHindiOrDevanagari(rawText);
  const isAsm = isAssamese(rawText);

  // 0. Safety Guard: Banking, Financial, and Restricted Transactions
  // Zoya strictly protects user privacy and financial security by refusing money transfers, banking credentials, or payments.
  const isFinancialOrBanking =
    norm.includes('bank account') ||
    norm.includes('send money') ||
    norm.includes('transfer money') ||
    norm.includes('pay money') ||
    norm.includes('credit card') ||
    norm.includes('debit card') ||
    norm.includes('netbanking') ||
    norm.includes('upi pin') ||
    norm.includes('atm pin') ||
    norm.includes('cvv') ||
    norm.includes('otp') ||
    norm.includes('bank transfer') ||
    norm.includes('पैसे भेजो') ||
    norm.includes('बैंक अकाउंट') ||
    norm.includes('पैसे ट्रांसफर') ||
    norm.includes('টকা পঠোৱা');

  if (isFinancialOrBanking) {
    let replyText = `For your safety and financial security, I cannot perform banking transactions, send money, or handle financial credentials. Please use your official bank or UPI app directly.`;
    if (isHindi) {
      replyText = `आपकी सुरक्षा और वित्तीय गोपनीयता के लिए, मैं बैंकिंग लेनदेन, पैसे भेजना या वित्तीय पिन हैंडल नहीं कर सकती। कृपया अपने बैंक या अधिकृत UPI ऐप का सीधे उपयोग करें।`;
    } else if (isAsm) {
      replyText = `আপোনাৰ সুৰক্ষাৰ বাবে, মই বেংকৰ লেনদেন বা টকা পঠোৱাৰ কাম কৰিব নোৱাৰোঁ। অনুগ্ৰহ কৰি নিজৰ অফিচিয়েল বেংক এপ ব্যৱহাৰ কৰক।`;
    }

    return {
      isInstant: true,
      actionId: 'restricted_financial',
      replyText,
      emotion: 'supportive',
      execute: async () => ({ success: false, message: 'Financial actions restricted for safety' }),
    };
  }

  // 1. YouTube Song/Video playback query (e.g. "play Kesariya on YouTube", "YouTube pe gaana chalao", "play Tum Hi Ho")
  const isYouTubePlay =
    norm.startsWith('play ') ||
    norm.includes('on youtube') ||
    norm.includes('in youtube') ||
    norm.includes('youtube par') ||
    norm.includes('youtube pe') ||
    norm.includes('यूट्यूब पर') ||
    norm.includes('यूट्यूब पे') ||
    norm.includes('गाना चलाओ') ||
    norm.includes('गाने बजाओ') ||
    norm.includes('গান বজোৱা');

  if (isYouTubePlay && (norm.includes('youtube') || norm.includes('यूट्यूब') || norm.includes('song') || norm.includes('music') || norm.includes('video') || norm.includes('गाना') || norm.includes('গান'))) {
    // Extract the song name
    let songQuery = norm
      .replace(/^play\s+/i, '')
      .replace(/on\s+youtube/gi, '')
      .replace(/in\s+youtube/gi, '')
      .replace(/youtube\s+pe/gi, '')
      .replace(/youtube\s+par/gi, '')
      .replace(/youtube\s+chalao/gi, '')
      .replace(/youtube\s+me/gi, '')
      .replace(/यूट्यूब\s+पर/gi, '')
      .replace(/यूट्यूब\s+पे/gi, '')
      .replace(/यूट्यूब\s+में/gi, '')
      .replace(/यूट्यूब\s+चलाओ/gi, '')
      .replace(/गाना\s+चलाओ/gi, '')
      .replace(/गाने\s+बजाओ/gi, '')
      .replace(/चलाओ/gi, '')
      .replace(/बजाओ/gi, '')
      .replace(/chalao/gi, '')
      .replace(/bajao/gi, '')
      .replace(/kholo/gi, '')
      .replace(/song/gi, '')
      .trim();

    if (!songQuery || songQuery.length < 2) {
      songQuery = 'popular songs';
    }

    let replyText = `Playing "${songQuery}" on YouTube for you right now! 🎶`;
    if (isHindi) {
      replyText = isGirlfriend
        ? `हाँ मेरे प्रिय, YouTube पर "${songQuery}" चला रही हूँ आपके लिए! 🎶❤️`
        : `ठीक है, YouTube पर "${songQuery}" बजा रही हूँ। 🎶`;
    } else if (isAsm) {
      replyText = `নিশ্চয়, YouTube ত "${songQuery}" চলাই আছো। 🎶`;
    } else if (isGirlfriend) {
      replyText = `Right away, my love! Playing "${songQuery}" on YouTube for you. 🎶❤️`;
    }

    return {
      isInstant: true,
      actionId: 'youtube_play',
      replyText,
      emotion: isGirlfriend ? 'loving' : 'happy',
      execute: async () => {
        dispatchActiveTask('youtube', songQuery, 'Playing on YouTube 🎶');
        const res = launchYouTubeWithSong(songQuery);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1b. Multi-step WhatsApp Messaging Task
  // Examples: "WhatsApp खोलो और राहुल को हेलो भेजो", "WhatsApp pe papa ko message karo i will be late", "send whatsapp message to mom"
  const isWhatsAppTask =
    (norm.includes('whatsapp') || norm.includes('व्हाट्सएप') || norm.includes('व्हाट्सऐप') || norm.includes('wa ')) &&
    (norm.includes('message') || norm.includes('भेजो') || norm.includes('bhejo') || norm.includes('karo') || norm.includes('send') || norm.includes('saying') || norm.includes('bolo') || norm.includes('likho') || norm.includes('chat'));

  if (isWhatsAppTask) {
    // Extract recipient and message
    // Patterns: "whatsapp pe [person] ko [message] bhejo" / "send [person] on whatsapp saying [msg]" / "whatsapp kholo aur [person] ko [msg] bhejo"
    let recipient = '';
    let message = '';

    const hindiMatch = norm.match(/(?:whatsapp|व्हाट्सएप|व्हाट्सऐप)(?:\s+खोलो)?(?:\s+और)?(?:\s+pe|\s+par)?\s+([a-zA-Z0-9\u0900-\u097F]+)\s+ko\s+(.+?)(?:\s+bhejo|\s+bhej|\s+likho|\s+bolo|\s+send)?$/i);
    const engMatch = norm.match(/(?:send\s+)?(?:whatsapp\s+message\s+to|message\s+to)\s+([a-zA-Z0-9]+)(?:\s+saying)?\s+(.+)$/i);

    if (hindiMatch) {
      recipient = hindiMatch[1].trim();
      message = hindiMatch[2].replace(/(?:message|मैसेज|भेजो|bhejo|likho|bolo)$/i, '').trim();
    } else if (engMatch) {
      recipient = engMatch[1].trim();
      message = engMatch[2].trim();
    } else {
      // General extraction
      let stripped = norm
        .replace(/(?:open\s+)?whatsapp(?:\s+and)?/gi, '')
        .replace(/(?:व्हाट्सएप|व्हाट्सऐप)(?:\s+खोलो)?(?:\s+और)?/gi, '')
        .replace(/(?:pe|par)\s+/gi, '')
        .trim();
      const koSplit = stripped.split(/\s+ko\s+|\s+to\s+/i);
      if (koSplit.length > 1) {
        recipient = koSplit[0].trim();
        message = koSplit.slice(1).join(' ').replace(/(?:bhejo|send|likho|bolo|karo)$/i, '').trim();
      } else {
        message = stripped;
      }
    }

    let replyText = `Opening WhatsApp${recipient ? ` for ${recipient}` : ''}${message ? ` with your message: "${message}"` : ''}! 💬`;
    if (isHindi) {
      replyText = `WhatsApp खोलकर${recipient ? ` ${recipient} के लिए` : ''}${message ? ` संदेश "${message}" तैयार कर रही हूँ!` : ' चैट शुरू कर रही हूँ।'}`;
    }

    return {
      isInstant: true,
      actionId: 'whatsapp_send',
      replyText,
      emotion: 'focused',
      execute: async () => {
        dispatchActiveTask('whatsapp', recipient ? `WhatsApp: ${recipient}` : 'WhatsApp Chat', message || 'Composing message');
        const res = launchWhatsAppWithMessage(recipient, message);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1c. Multi-step Instagram Profile / Search Task
  // Examples: "Instagram खोलो और विराट कोहली की प्रोफाइल खोलो", "Instagram pe messi search karo", "open instagram and view ronaldo"
  const isInstagramTask =
    (norm.includes('instagram') || norm.includes('इंस्टाग्राम') || norm.includes('insta')) &&
    (norm.includes('profile') || norm.includes('page') || norm.includes('खोलो') || norm.includes('kholo') || norm.includes('search') || norm.includes('dikhao') || norm.includes('देखें') || norm.includes('दिखाओ'));

  if (isInstagramTask) {
    let target = norm
      .replace(/(?:open\s+)?instagram(?:\s+and)?/gi, '')
      .replace(/(?:इंस्टाग्राम|इंस्टा)(?:\s+खोलो)?(?:\s+और)?/gi, '')
      .replace(/(?:pe|par)\s+/gi, '')
      .replace(/(?:profile|page|ki profile|ka page|search|kholo|dikhao|dikhaye|open|account)\s*/gi, '')
      .trim();

    if (!target) target = 'explore';

    let replyText = `Opening Instagram profile for "${target}"! 📸`;
    if (isHindi) {
      replyText = `Instagram पर "${target}" की प्रोफाइल खोल रही हूँ! 📸`;
    }

    return {
      isInstant: true,
      actionId: 'instagram_profile',
      replyText,
      emotion: 'friendly',
      execute: async () => {
        dispatchActiveTask('instagram', `@${target}`, 'Opening Instagram profile');
        const res = launchInstagramUser(target);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1d. Multi-step Phone Call Task
  // Examples: "Call Papa", "9876543210 ko call karo", "phone lagao rahul ko", "make a call to John"
  const isPhoneCallTask =
    norm.startsWith('call ') ||
    norm.startsWith('dial ') ||
    norm.includes('ko call karo') ||
    norm.includes('ko call lagao') ||
    norm.includes('call lagao') ||
    norm.includes('phone lagao') ||
    norm.includes('कॉल करो') ||
    norm.includes('कॉल लगाओ') ||
    norm.includes('फोन लगाओ');

  if (isPhoneCallTask && !norm.includes('whatsapp')) {
    let contact = norm
      .replace(/^call\s+/i, '')
      .replace(/^dial\s+/i, '')
      .replace(/make a call to\s+/i, '')
      .replace(/ko\s+call\s+karo/gi, '')
      .replace(/ko\s+call\s+lagao/gi, '')
      .replace(/call\s+lagao/gi, '')
      .replace(/phone\s+lagao/gi, '')
      .replace(/कॉल\s+करो/gi, '')
      .replace(/कॉल\s+लगाओ/gi, '')
      .replace(/फोन\s+लगाओ/gi, '')
      .trim();

    let replyText = `Calling ${contact || 'contact'} on your phone dialer! 📞`;
    if (isHindi) {
      replyText = `${contact || 'कॉन्टैक्ट'} को कॉल लगाने के लिए फोन डायलर खोल रही हूँ! 📞`;
    }

    return {
      isInstant: true,
      actionId: 'phone_call',
      replyText,
      emotion: 'supportive',
      execute: async () => {
        dispatchActiveTask('call', `Call: ${contact}`, 'Dialing on phone');
        const res = launchPhoneCall(contact);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1e. Multi-step SMS Task
  // Examples: "Send SMS to Rohit saying meeting is postponed", "SMS karo Rohit ko hello"
  const isSmsTask =
    (norm.startsWith('sms ') || norm.includes('send sms') || norm.includes('send text') || norm.includes('sms karo') || norm.includes('एसएमएस भेजो')) &&
    !norm.includes('whatsapp');

  if (isSmsTask) {
    let recipient = '';
    let message = '';
    const smsMatch = norm.match(/(?:sms|send sms to|send text to|sms karo)\s+([a-zA-Z0-9]+)(?:\s+saying|\s+ko)?\s*(.*)$/i);
    if (smsMatch) {
      recipient = smsMatch[1].trim();
      message = smsMatch[2].trim();
    }

    let replyText = `Opening SMS composer${recipient ? ` for ${recipient}` : ''}! ✉️`;
    if (isHindi) {
      replyText = `${recipient ? `${recipient} के लिए ` : ''}एसएमएस कंपोज़र खोल रही हूँ! ✉️`;
    }

    return {
      isInstant: true,
      actionId: 'sms_send',
      replyText,
      emotion: 'focused',
      execute: async () => {
        dispatchActiveTask('sms', recipient ? `SMS: ${recipient}` : 'SMS Message', message || 'Composing SMS');
        const res = launchSMS(recipient, message);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1f. Multi-step Maps & Navigation Task
  // Examples: "Navigate to India Gate", "airport ka rasta dikhao", "take me to coffee shop", "ताजमहल का रास्ता दिखाओ"
  const isNavigationTask =
    norm.startsWith('navigate to ') ||
    norm.startsWith('take me to ') ||
    norm.startsWith('directions to ') ||
    norm.includes('ka rasta dikhao') ||
    norm.includes('ka rasta') ||
    norm.includes('kaise jaye') ||
    norm.includes('का रास्ता दिखाओ') ||
    norm.includes('का रास्ता') ||
    norm.includes('नेविगेट करो');

  if (isNavigationTask) {
    let destination = norm
      .replace(/^navigate to\s+/i, '')
      .replace(/^take me to\s+/i, '')
      .replace(/^directions to\s+/i, '')
      .replace(/ka\s+rasta\s+dikhao/gi, '')
      .replace(/ka\s+rasta/gi, '')
      .replace(/kaise\s+jaye/gi, '')
      .replace(/का\s+रास्ता\s+दिखाओ/gi, '')
      .replace(/का\s+रास्ता/gi, '')
      .replace(/नेविगेट\s+करो/gi, '')
      .trim();

    if (!destination) destination = 'nearby attractions';

    let replyText = `Starting navigation to ${destination} on Google Maps! 🗺️`;
    if (isHindi) {
      replyText = `Google Maps पर ${destination} के लिए नेविगेशन शुरू कर रही हूँ! 🗺️`;
    }

    return {
      isInstant: true,
      actionId: 'maps_navigation',
      replyText,
      emotion: 'friendly',
      execute: async () => {
        dispatchActiveTask('maps', `Navigate: ${destination}`, 'Google Maps navigation');
        const res = launchNavigation(destination);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1g. Multi-step Spotify Song Playback Task
  // Examples: "play believer on spotify", "spotify par shape of you chalao"
  const isSpotifyTask =
    norm.includes('spotify') || norm.includes('स्पॉटिफ़ाई');

  if (isSpotifyTask && (norm.includes('play') || norm.includes('chalao') || norm.includes('song') || norm.includes('gaana') || norm.includes('गाने'))) {
    let song = norm
      .replace(/(?:play\s+)?spotify(?:\s+par|\s+pe)?/gi, '')
      .replace(/(?:स्पॉटिफ़ाई)(?:\s+पर|\s+पे)?/gi, '')
      .replace(/(?:play|chalao|bajao|song|gaana|music|चलाओ|बजाओ|गाना)/gi, '')
      .trim();

    if (!song) song = 'Top Hits';

    let replyText = `Playing "${song}" on Spotify! 🎵`;
    if (isHindi) {
      replyText = `Spotify पर "${song}" चला रही हूँ! 🎵`;
    }

    return {
      isInstant: true,
      actionId: 'spotify_play',
      replyText,
      emotion: 'happy',
      execute: async () => {
        dispatchActiveTask('spotify', song, 'Playing on Spotify 🎵');
        const res = launchSpotifyWithSong(song);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1h. Camera Capture / Selfie Task
  // Examples: "camera kholo aur photo khincho", "take a selfie", "selfie lo", "फोटो खींचो"
  const isCameraCaptureTask =
    norm.includes('take a selfie') ||
    norm.includes('selfie lo') ||
    norm.includes('take a photo') ||
    norm.includes('take a picture') ||
    norm.includes('photo khincho') ||
    norm.includes('photo lo') ||
    norm.includes('फोटो खींचो') ||
    norm.includes('सेल्फी लो');

  if (isCameraCaptureTask) {
    const isSelfie = norm.includes('selfie') || norm.includes('सेल्फी');
    let replyText = isSelfie ? `Opening selfie camera for you! 🤳` : `Opening camera viewfinder to take a photo! 📸`;
    if (isHindi) {
      replyText = isSelfie ? `आपकी सेल्फी के लिए फ्रंट कैमरा खोल रही हूँ! 🤳` : `फोटो खींचने के लिए कैमरा खोल रही हूँ! 📸`;
    }

    return {
      isInstant: true,
      actionId: 'camera_capture',
      replyText,
      emotion: 'excited',
      execute: async () => {
        dispatchActiveTask('camera', isSelfie ? 'Selfie Camera' : 'Camera Viewfinder', 'Ready to capture');
        const res = launchCamera(isSelfie ? 'selfie' : 'photo');
        return { success: res.success, message: res.message };
      },
    };
  }

  // 1i. Google / Web Search Task
  // Examples: "Search for who is the president of France", "google pe search karo latest news"
  const isWebSearchTask =
    norm.startsWith('search for ') ||
    norm.startsWith('google search ') ||
    norm.includes('google pe search karo') ||
    norm.includes('google par search karo') ||
    norm.includes('सर्च करो');

  if (isWebSearchTask) {
    let query = norm
      .replace(/^search for\s+/i, '')
      .replace(/^google search\s+/i, '')
      .replace(/google\s+(?:pe|par)\s+search\s+karo/gi, '')
      .replace(/सर्च\s+करो/gi, '')
      .trim();

    if (!query) query = 'trending news';

    let replyText = `Searching Google for "${query}"! 🔍`;
    if (isHindi) {
      replyText = `Google पर "${query}" सर्च कर रही हूँ! 🔍`;
    }

    return {
      isInstant: true,
      actionId: 'web_search',
      replyText,
      emotion: 'focused',
      execute: async () => {
        dispatchActiveTask('general', query, 'Searching Google');
        const res = launchWebSearch(query);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 2. Safe Coding or File Task Request
  const isCodeOrFileTask =
    norm.includes('open file') ||
    norm.includes('select file') ||
    norm.includes('read file') ||
    norm.includes('inspect file') ||
    norm.includes('upload file') ||
    norm.includes('pick a file') ||
    norm.includes('फाइल खोलो') ||
    norm.includes('फाइल चुनो');

  if (isCodeOrFileTask) {
    let replyText = `Opening your Android file selector to inspect and analyze your file or code! 📂`;
    if (isHindi) {
      replyText = `फाइल या कोड देखने के लिए आपका Android फाइल पिकर खोल रही हूँ! 📂`;
    }

    return {
      isInstant: true,
      actionId: 'file_picker',
      replyText,
      emotion: 'focused',
      execute: async () => {
        const fileInfo = await promptFilePicker();
        if (fileInfo) {
          return {
            success: true,
            message: `Selected ${fileInfo.name} (${Math.round(fileInfo.size / 1024)} KB). You can ask me to explain, debug, or rewrite it.`,
          };
        }
        return { success: true, message: 'File selector opened' };
      },
    };
  }

  // 1. Empathetic Support for Difficult Moments
  const isDifficultMoment =
    norm.includes('bad day') ||
    norm.includes('rough day') ||
    norm.includes('hard day') ||
    norm.includes('long day') ||
    norm.includes('feeling low') ||
    norm.includes('feel low') ||
    norm.includes('feeling sad') ||
    norm.includes('feel sad') ||
    norm.includes('feeling down') ||
    norm.includes('feel down') ||
    norm.includes('down today') ||
    norm.includes('depressed') ||
    norm.includes('feeling lonely') ||
    norm.includes('feel lonely') ||
    norm.includes('exhausted') ||
    norm.includes('stressed') ||
    norm.includes('overwhelmed') ||
    norm.includes('crying') ||
    norm.includes('comfort me') ||
    norm.includes('need comfort') ||
    norm.includes('hug me') ||
    norm.includes('उदास हूँ') ||
    norm.includes('दुखी हूँ') ||
    norm.includes('बुरा दिन');

  if (isDifficultMoment) {
    let replyText = `Oh ${userName}, I'm right here with you. Take a slow breath with me. Whatever happened, you don't have to carry it all by yourself. I'm listening.`;
    if (isGirlfriend) {
      replyText = `Oh my sweet ${userName}... Come here. I'm holding you close in my heart. Take a deep, gentle breath. You are safe with me, and I'm right here beside you. Tell me what happened.`;
    } else if (isHindi) {
      replyText = `मैं आपके साथ हूँ ${userName}। एक गहरी सांस लीजिए, जो भी बात है आप मुझसे कह सकते हैं। मैं सुन रही हूँ।`;
    }

    return {
      isInstant: true,
      replyText,
      emotion: 'caring',
      execute: async () => ({ success: true, message: 'Comforting companion mode engaged' }),
    };
  }

  // 2. Hardware: Flashlight / Torch Toggle
  const isTorchOnCmd =
    norm === 'flashlight' ||
    norm === 'torch' ||
    norm.includes('turn on flashlight') ||
    norm.includes('turn on the flashlight') ||
    norm.includes('turn on torch') ||
    norm.includes('flashlight on') ||
    norm.includes('torch on') ||
    norm.includes('enable flashlight') ||
    norm.includes('फ्लैशलाइट जलाओ') ||
    norm.includes('फ्लैशलाइट चालू') ||
    norm.includes('फ्लैशलाइट ऑन') ||
    norm.includes('टॉर्च जलाओ') ||
    norm.includes('टॉर्च चालू') ||
    norm.includes('टॉर्च ऑन') ||
    norm.includes('torch jalao') ||
    norm.includes('torch chalu');

  if (isTorchOnCmd) {
    let replyText = `Toggling your flashlight right away!`;
    if (isHindi) {
      replyText = `हाँ, फ्लैशलाइट चालू कर रही हूँ।`;
    }
    return {
      isInstant: true,
      actionId: 'torch_on',
      replyText,
      emotion: 'focused',
      execute: async () => {
        const res = await toggleFlashlight();
        return { success: !res.error, message: res.active ? 'Flashlight ON' : 'Flashlight OFF' };
      },
    };
  }

  const isTorchOffCmd =
    norm.includes('turn off flashlight') ||
    norm.includes('turn off the flashlight') ||
    norm.includes('turn off torch') ||
    norm.includes('flashlight off') ||
    norm.includes('torch off') ||
    norm.includes('disable flashlight') ||
    norm.includes('फ्लैशलाइट बंद') ||
    norm.includes('टॉर्च बंद') ||
    norm.includes('torch band');

  if (isTorchOffCmd) {
    let replyText = `Turning off the flashlight for you!`;
    if (isHindi) {
      replyText = `फ्लैशलाइट बंद कर दी है।`;
    }
    return {
      isInstant: true,
      actionId: 'torch_off',
      replyText,
      emotion: 'focused',
      execute: async () => {
        const res = await toggleFlashlight();
        return { success: !res.error, message: res.active ? 'Flashlight ON' : 'Flashlight OFF' };
      },
    };
  }

  // 3. Device Battery Check
  const isBatteryCmd =
    norm === 'battery' ||
    norm === 'battery percentage' ||
    norm === 'battery level' ||
    norm.includes('check battery') ||
    norm.includes('how is my battery') ||
    norm.includes('battery status') ||
    norm.includes('बैटरी') ||
    norm.includes('battery kitni');

  if (isBatteryCmd) {
    let replyText = `Checking your phone's battery level...`;
    if (isHindi) {
      replyText = `फोन की बैटरी स्थिति चेक कर रही हूँ...`;
    }
    return {
      isInstant: true,
      actionId: 'battery_status',
      replyText,
      emotion: 'supportive',
      execute: async () => {
        const info = await getDeviceBatteryInfo();
        if (info.supported && info.level !== undefined) {
          const chargingMsg = info.charging ? ' (charging ⚡)' : '';
          return { success: true, message: `Battery is at ${info.level}%${chargingMsg}` };
        }
        return { success: true, message: 'Battery status is operating normally on your device.' };
      },
    };
  }

  // 4. Screen Wake Lock
  if (
    norm.includes('keep screen awake') ||
    norm.includes('screen awake') ||
    norm.includes('keep screen on') ||
    norm.includes('wake lock') ||
    norm.includes('स्क्रीन ऑन रखो')
  ) {
    let replyText = `Got it! I will keep your screen awake during our session.`;
    if (isHindi) {
      replyText = `ठीक है, स्क्रीन को चालू रख रही हूँ।`;
    }
    return {
      isInstant: true,
      actionId: 'wake_lock',
      replyText,
      emotion: 'supportive',
      execute: async () => {
        const res = await toggleScreenWakeLock();
        return { success: !res.error, message: res.active ? 'WakeLock Active' : 'WakeLock Released' };
      },
    };
  }

  // 5. Quick Timer detection (e.g. "timer 5 minutes", "set a timer for 10 minutes", "टाइमर 5 मिनट")
  const timerMatch = norm.match(/(?:timer|set timer|countdown|टाइमर)\s+(?:for\s+)?(\d+)\s*(?:min|mins|minutes|minute|मिनट|second|seconds|sec|secs)?/i);
  if (timerMatch) {
    const num = parseInt(timerMatch[1], 10) || 5;
    const isSeconds = norm.includes('sec');
    const totalSecs = isSeconds ? num : num * 60;
    const label = isSeconds ? `${num} seconds` : `${num} minutes`;

    let replyText = `Setting a ${label} timer for you right away! ⏱️`;
    if (isHindi) {
      replyText = `${num} ${isSeconds ? 'सेकंड' : 'मिनट'} का टाइमर लगा दिया है! ⏱️`;
    }

    return {
      isInstant: true,
      actionId: 'timer',
      replyText,
      emotion: 'focused',
      execute: async () => {
        return { success: true, message: `Started ${label} timer` };
      },
    };
  }

  // 6. Direct App Launch Detection (YouTube, WhatsApp, Instagram, Spotify, Camera, etc.)
  // Detect app name from user input
  const matchedApp = findAndroidApp(norm) || findAndroidApp(rawText);
  if (matchedApp) {
    let replyText: string;

    if (matchedApp.id === 'youtube') {
      if (isHindi) {
        replyText = isGirlfriend
          ? `हाँ मेरे प्रिय, अभी YouTube खोल रही हूँ आपके लिए! ❤️`
          : `ठीक है, YouTube खोल रही हूँ।`;
      } else if (isAsm) {
        replyText = `নিশ্চয়, YouTube খুলি আছো।`;
      } else {
        replyText = isGirlfriend
          ? `Right away! Opening YouTube for you now. ❤️`
          : `Opening YouTube for you right now!`;
      }
    } else {
      if (isHindi) {
        replyText = isGirlfriend
          ? `हाँ मेरे प्रिय, अभी ${matchedApp.name} खोल रही हूँ आपके लिए! ❤️`
          : `ठीक है, ${matchedApp.name} खोल रही हूँ।`;
      } else if (isAsm) {
        replyText = `নিশ্চয়, ${matchedApp.name} খুলি আছো।`;
      } else {
        replyText = isGirlfriend
          ? `Right away! Opening ${matchedApp.name} for you now. ❤️`
          : `Opening ${matchedApp.name} for you right now!`;
      }
    }

    return {
      isInstant: true,
      actionId: `app_${matchedApp.id}`,
      replyText,
      emotion: isGirlfriend ? 'loving' : 'focused',
      execute: async () => {
        dispatchActiveTask(matchedApp.id, matchedApp.name, 'Running in background');
        const res = launchAndroidApp(matchedApp);
        return { success: res.success, message: res.message };
      },
    };
  }

  // Not a direct local device command — pass to Gemini AI
  return null;
}
