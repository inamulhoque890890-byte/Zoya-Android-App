export type CompanionMode = 'girlfriend' | 'normal' | 'assistant';

export type EmotionType =
  | 'caring'
  | 'happy'
  | 'loving'
  | 'amused'
  | 'thoughtful'
  | 'excited'
  | 'supportive'
  | 'focused'
  | 'friendly'
  | 'listening'
  | 'sad'
  | 'concern'
  | 'surprise'
  | 'anger'
  | 'fear'
  | 'calmness'
  | 'shyness'
  | 'empathy';

export type LanguageCode = 'auto' | 'as' | 'hi' | 'en' | 'bn' | 'ur';

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeName: string;
  bcp47: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  emotion?: EmotionType;
  language?: LanguageCode;
  actionTriggered?: string;
}

export type VoiceProfileType = 'zoya_original' | 'boys_voice';

export interface VoiceSettings {
  autoSpeak: boolean;
  voiceURI: string;
  pitch: number;
  rate: number;
  hapticFeedback: boolean;
  wakeListening: boolean; // Continuous "Hey Zoya" wake word detection
  language?: LanguageCode;
  voiceProfile?: VoiceProfileType; // 'zoya_original' (default) | 'boys_voice'
  selectedBoyVoiceId?: string;
  selectedBoyVoiceURI?: string;
  selectedBoyVoiceName?: string;
  selectedBoyVoicePitch?: number;
  selectedBoyVoiceRate?: number;
}

export interface AppSettings {
  userName: string;
  zoyaName: string;
  geminiApiKey: string;
  selectedMode: CompanionMode;
  language: LanguageCode;
  voiceSettings: VoiceSettings;
  permissions: {
    microphone: boolean;
    speech: boolean;
    notifications: boolean;
    wakeLock: boolean;
    geolocation: boolean;
  };
}

export interface WeatherData {
  temp: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  condition: string;
  weatherCode: number;
  isDay: boolean;
  city: string;
}

export interface AndroidActionItem {
  id: string;
  title: string;
  description: string;
  category: 'communication' | 'tools' | 'navigation' | 'media';
  icon: string;
  actionType: 'url' | 'tel' | 'sms' | 'mailto' | 'torch' | 'timer' | 'share' | 'wakeLock' | 'file';
  target?: string;
  badge?: string;
}
