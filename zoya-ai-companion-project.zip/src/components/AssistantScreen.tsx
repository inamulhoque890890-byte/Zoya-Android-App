import React, { useState, useEffect } from 'react';
import {
  PhoneCall,
  MessageSquare,
  Compass,
  Flashlight,
  Clock,
  Sun,
  Camera,
  Share2,
  Mail,
  Search,
  PlayCircle,
  ShieldCheck,
  Battery,
  Wifi,
  Sparkles,
  AlertCircle,
  Play,
  RotateCcw,
  CheckCircle2,
  Zap,
  Globe,
  Music,
  ShoppingBag,
  Send,
  Film,
  Tv,
  Image,
  Calculator,
  Aperture,
  Phone,
  MessageCircle,
  FolderOpen,
} from 'lucide-react';
import { ANDROID_ACTIONS, executeAndroidAction, getTorchStatus, getWakeLockStatus, getDeviceBatteryInfo } from '../utils/androidActions';
import { ANDROID_APPS, launchAndroidApp, AndroidAppDef } from '../utils/appLauncher';
import { AndroidActionItem } from '../types';

interface AssistantScreenProps {
  onSendMessage: (text: string) => void;
  onNavigateTab: (tab: 'home' | 'chat' | 'assistant' | 'settings') => void;
}

export const AssistantScreen: React.FC<AssistantScreenProps> = ({ onSendMessage, onNavigateTab }) => {
  const [activeTorch, setActiveTorch] = useState(false);
  const [activeWakeLock, setActiveWakeLock] = useState(false);
  const [batteryData, setBatteryData] = useState<{ supported: boolean; level?: number; charging?: boolean }>({ supported: false });
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  // Timer tool state
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  useEffect(() => {
    setActiveTorch(getTorchStatus());
    setActiveWakeLock(getWakeLockStatus());
    getDeviceBatteryInfo().then(setBatteryData);
  }, []);

  // Timer effect
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsTimerRunning(false);
            // Vibrate and notify
            if (typeof navigator !== 'undefined' && navigator.vibrate) {
              navigator.vibrate([200, 100, 200, 100, 400]);
            }
            setFeedbackMessage('Timer Finished! ⏰');
            setTimeout(() => setFeedbackMessage(null), 5000);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  const handleRunAction = async (action: AndroidActionItem) => {
    const res = await executeAndroidAction(action);
    if (res.message) {
      setFeedbackMessage(res.message);
      setTimeout(() => setFeedbackMessage(null), 4000);
    }
    if (action.id === 'torch') {
      setActiveTorch(getTorchStatus());
    }
    if (action.id === 'wakeLock') {
      setActiveWakeLock(getWakeLockStatus());
    }
  };

  const handleLaunchApp = (app: AndroidAppDef) => {
    const res = launchAndroidApp(app);
    setFeedbackMessage(res.message);
    setTimeout(() => setFeedbackMessage(null), 3500);
  };

  const startQuickTimer = (secs: number) => {
    setTimerSeconds(secs);
    setIsTimerRunning(true);
    setFeedbackMessage(`Started ${secs / 60} min timer`);
    setTimeout(() => setFeedbackMessage(null), 3000);
  };

  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getActionIcon = (iconName: string) => {
    switch (iconName) {
      case 'PhoneCall': return PhoneCall;
      case 'MessageSquare': return MessageSquare;
      case 'Compass': return Compass;
      case 'Flashlight': return Flashlight;
      case 'Clock': return Clock;
      case 'Sun': return Sun;
      case 'Camera': return Camera;
      case 'Share2': return Share2;
      case 'Mail': return Mail;
      case 'Search': return Search;
      case 'PlayCircle': return PlayCircle;
      case 'FolderOpen': return FolderOpen;
      default: return Sparkles;
    }
  };

  const getAppIcon = (iconName: string) => {
    switch (iconName) {
      case 'PlayCircle': return PlayCircle;
      case 'MessageCircle': return MessageCircle;
      case 'Camera': return Camera;
      case 'Music': return Music;
      case 'Aperture': return Aperture;
      case 'Compass': return Compass;
      case 'Globe': return Globe;
      case 'Mail': return Mail;
      case 'Phone': return Phone;
      case 'MessageSquare': return MessageSquare;
      case 'Calculator': return Calculator;
      case 'Clock': return Clock;
      case 'ShoppingBag': return ShoppingBag;
      case 'Send': return Send;
      case 'Film': return Film;
      case 'Tv': return Tv;
      case 'Image': return Image;
      default: return Zap;
    }
  };

  return (
    <div className="w-full pb-24 px-4 pt-2 flex flex-col gap-4 animate-fade-in max-w-md mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-cyan-950/60 to-slate-900/80 border border-cyan-500/30 rounded-2xl p-4 backdrop-blur-md">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">Android Phone Assistant</h2>
            <p className="text-[11px] text-cyan-300">Zero-Latency App Launching & Phone Controls</p>
          </div>
        </div>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed">
          Say any app name (e.g. <span className="text-cyan-300 font-medium">"YouTube"</span>, <span className="text-cyan-300 font-medium">"Instagram"</span>, <span className="text-cyan-300 font-medium">"WhatsApp"</span>) to launch it immediately with zero lag!
        </p>
      </div>

      {/* Floating Action Feedback Notification */}
      {feedbackMessage && (
        <div className="p-3 bg-indigo-600 text-white rounded-xl shadow-xl flex items-center justify-between text-xs font-semibold animate-fade-in">
          <span>{feedbackMessage}</span>
          <CheckCircle2 className="w-4 h-4 text-emerald-300" />
        </div>
      )}

      {/* Instant Installed App Launcher Grid */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Instant App Launcher</span>
          </h3>
          <span className="text-[10px] text-slate-400">Voice or Tap to Open</span>
        </div>

        <div className="grid grid-cols-4 gap-2 bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
          {ANDROID_APPS.slice(0, 12).map((app, idx) => {
            const AppIcon = getAppIcon(app.icon);
            return (
              <button
                key={`${app.id}-${idx}`}
                onClick={() => handleLaunchApp(app)}
                className="flex flex-col items-center gap-1.5 p-2 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all text-center group"
                title={`Launch ${app.name}`}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center text-white shadow-md transition-transform group-hover:scale-105"
                  style={{ backgroundColor: app.color }}
                >
                  <AppIcon className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-semibold text-slate-300 group-hover:text-white truncate w-full">
                  {app.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Device Quick Status Bar */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Battery className="w-4 h-4 text-indigo-400" />
            <span className="text-xs text-slate-300">Battery</span>
          </div>
          <span className="text-xs font-bold text-white">
            {batteryData.supported && batteryData.level ? `${batteryData.level}%` : 'Normal'}
          </span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wifi className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-slate-300">Network</span>
          </div>
          <span className="text-xs font-bold text-emerald-400">Connected</span>
        </div>
      </div>

      {/* Built-in Assistant Timer & Stopwatch Tool */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">Quick Alarm & Timer</h3>
          </div>
          {isTimerRunning && (
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30 animate-pulse">
              Running
            </span>
          )}
        </div>

        <div className="flex items-center justify-between bg-slate-950/80 rounded-xl p-3 border border-slate-800">
          <div>
            <div className="text-2xl font-mono font-bold text-white tracking-widest">
              {formatTimer(timerSeconds)}
            </div>
            <span className="text-[10px] text-slate-400">Countdown Timer</span>
          </div>

          <div className="flex items-center gap-2">
            {isTimerRunning ? (
              <button
                onClick={() => setIsTimerRunning(false)}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold"
              >
                Pause
              </button>
            ) : timerSeconds > 0 ? (
              <button
                onClick={() => setIsTimerRunning(true)}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1"
              >
                <Play className="w-3 h-3" /> Resume
              </button>
            ) : null}

            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimerSeconds(0);
              }}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              title="Reset"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Preset quick buttons */}
        <div className="grid grid-cols-4 gap-2 mt-2.5">
          {[1, 5, 15, 30].map((mins) => (
            <button
              key={mins}
              onClick={() => startQuickTimer(mins * 60)}
              className="py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/60 text-center transition-colors active:scale-95"
            >
              +{mins}m
            </button>
          ))}
        </div>
      </div>

      {/* Permitted Android Actions Catalog */}
      <div className="flex flex-col gap-2">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-1">
          Supported Android Hardware & System Tools
        </h3>

        <div className="grid grid-cols-2 gap-2.5">
          {ANDROID_ACTIONS.map((item, idx) => {
            const IconComponent = getActionIcon(item.icon);
            const isSpecialActive =
              (item.id === 'torch' && activeTorch) || (item.id === 'wakeLock' && activeWakeLock);

            return (
              <button
                key={`${item.id}-${idx}`}
                onClick={() => handleRunAction(item)}
                className={`p-3.5 rounded-2xl text-left border transition-all duration-200 flex flex-col justify-between group active:scale-[0.98] ${
                  isSpecialActive
                    ? 'bg-amber-950/40 border-amber-500/50 text-white shadow-lg shadow-amber-500/10'
                    : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800/90 text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <div
                    className={`p-2 rounded-xl ${
                      isSpecialActive
                        ? 'bg-amber-500 text-black'
                        : 'bg-slate-800 text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white'
                    } transition-colors`}
                  >
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] uppercase font-semibold px-1.5 py-0.5 rounded bg-slate-800/90 text-slate-400 border border-slate-700/50">
                    {item.badge}
                  </span>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-white mb-0.5 group-hover:text-indigo-300">
                    {item.title}
                  </h4>
                  <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Clear Android Permissions & Security Truthfulness */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 text-xs text-slate-400 space-y-2">
        <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
          <AlertCircle className="w-4 h-4 text-indigo-400" />
          <span>Android Permission & Security Clarity</span>
        </div>
        <p className="leading-relaxed text-[11px]">
          Android operates with a strict sandboxing security model. Zoya uses standard Android Intents (dialer, messages, maps, app launching) and verified Web APIs (microphone, speech synthesis, camera flash, wake lock).
        </p>
        <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/80 text-[10px] space-y-1 text-slate-400">
          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <CheckCircle2 className="w-3 h-3" /> Fully Supported: Voice Recognition, Spoken TTS, YouTube, Instagram, WhatsApp, Spotify, Maps, Camera, Flashlight.
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            • Note: Silent background keylogging and system root tampering are intentionally restricted by Android OS for your security.
          </div>
        </div>
      </div>
    </div>
  );
};
