import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Trash2,
  Heart,
  Bot,
  Wrench,
  ExternalLink,
  PhoneCall,
  Compass,
  Flashlight,
  Clock,
  Share2,
  Play,
  FileCode,
  FolderOpen,
} from 'lucide-react';
import { AppSettings, ChatMessage, EmotionType } from '../types';
import { findAndroidApp } from '../utils/appLauncher';

interface ChatScreenProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onClearMessages: () => void;
  isListening: boolean;
  onToggleVoice: () => void;
  interimTranscript: string;
  isThinking: boolean;
  settings: AppSettings;
  onSpeakMessage: (msg: ChatMessage) => void;
  onStopSpeech: () => void;
  currentlySpeakingId: string | null;
  onExecuteAction: (actionKey: string) => void;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({
  messages,
  onSendMessage,
  onClearMessages,
  isListening,
  onToggleVoice,
  interimTranscript,
  isThinking,
  settings,
  onSpeakMessage,
  onStopSpeech,
  currentlySpeakingId,
  onExecuteAction,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking, interimTranscript]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const getEmotionBadge = (emotion?: EmotionType) => {
    switch (emotion) {
      case 'loving':
        return { label: 'Loving', icon: Heart, bg: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      case 'amused':
        return { label: 'Playful', icon: Sparkles, bg: 'bg-amber-400/20 text-amber-300 border-amber-400/30' };
      case 'caring':
        return { label: 'Caring', icon: Heart, bg: 'bg-pink-500/20 text-pink-300 border-pink-500/30' };
      case 'supportive':
        return { label: 'Supportive', icon: Heart, bg: 'bg-rose-400/20 text-rose-300 border-rose-400/30' };
      case 'empathy':
        return { label: 'Empathetic', icon: Heart, bg: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      case 'happy':
        return { label: 'Happy', icon: Sparkles, bg: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      case 'excited':
        return { label: 'Excited', icon: Sparkles, bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' };
      case 'sad':
        return { label: 'Comforting', icon: Heart, bg: 'bg-blue-500/20 text-blue-300 border-blue-500/30' };
      case 'concern':
        return { label: 'Concerned', icon: Heart, bg: 'bg-sky-500/20 text-sky-300 border-sky-500/30' };
      case 'calmness':
        return { label: 'Calm', icon: Bot, bg: 'bg-teal-500/20 text-teal-300 border-teal-500/30' };
      case 'shyness':
        return { label: 'Shy', icon: Heart, bg: 'bg-pink-500/20 text-pink-300 border-pink-500/30' };
      case 'surprise':
        return { label: 'Surprised', icon: Sparkles, bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' };
      case 'anger':
        return { label: 'Pouting', icon: Bot, bg: 'bg-red-500/20 text-red-300 border-red-500/30' };
      case 'focused':
        return { label: 'Focused', icon: Wrench, bg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' };
      case 'friendly':
        return { label: 'Friendly', icon: Bot, bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'thoughtful':
      default:
        return { label: 'Thoughtful', icon: Bot, bg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' };
    }
  };

  const getActionDetails = (actionKey?: string) => {
    if (!actionKey) return null;

    if (actionKey.startsWith('youtube_play:') || actionKey === 'youtube_play') {
      const song = actionKey.startsWith('youtube_play:') ? actionKey.replace('youtube_play:', '') : 'YouTube Video/Song';
      return {
        title: `Play "${song}" on YouTube`,
        icon: Play,
        action: actionKey,
      };
    }

    if (actionKey === 'file_picker' || actionKey === 'open_file') {
      return {
        title: 'Open File Selector',
        icon: FolderOpen,
        action: 'file_picker',
      };
    }

    if (actionKey === 'code_analysis' || actionKey === 'code_task') {
      return {
        title: 'Open Code Assistant',
        icon: FileCode,
        action: 'file_picker',
      };
    }

    if (actionKey.startsWith('app_')) {
      const appId = actionKey.replace('app_', '');
      const app = findAndroidApp(appId);
      if (app) {
        return {
          title: `Launch ${app.name}`,
          icon: ExternalLink,
          action: actionKey,
        };
      }
    }

    switch (actionKey.toLowerCase()) {
      case 'open_dialer':
        return { title: 'Launch Phone Dialer', icon: PhoneCall, action: 'dialer' };
      case 'open_maps':
        return { title: 'Open Google Maps', icon: Compass, action: 'maps' };
      case 'toggle_torch':
      case 'torch_on':
      case 'torch_off':
        return { title: 'Toggle Flashlight', icon: Flashlight, action: 'torch' };
      case 'open_clock':
      case 'set_timer':
      case 'timer':
        return { title: 'Open Timer & Clock', icon: Clock, action: 'timer' };
      case 'share_text':
        return { title: 'Open Android Share', icon: Share2, action: 'share' };
      default:
        return { title: `Run ${actionKey.replace('_', ' ')}`, icon: ExternalLink, action: actionKey };
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-125px)] max-w-md mx-auto relative bg-[#090D16]">
      {/* Chat Sub-header */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900/70 border-b border-slate-800/80 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full overflow-hidden ring-1 ring-indigo-500/40">
            <img
              src="/zoya_anime_avatar.png"
              alt="Zoya"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.endsWith('.jpg')) {
                  target.src = '/zoya_anime_avatar.jpg';
                }
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white">{settings.zoyaName}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            </div>
            <span className="text-[10px] text-slate-400 capitalize">
              {settings.selectedMode} Mode {settings.voiceSettings.autoSpeak ? '• Voice ON' : '• Voice Muted'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {currentlySpeakingId && (
            <button
              onClick={onStopSpeech}
              className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30 transition-colors"
              title="Stop speaking"
            >
              <VolumeX className="w-4 h-4 animate-pulse" />
            </button>
          )}

          <button
            onClick={onClearMessages}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="Clear chat"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Timeline */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-3.5 scroll-smooth">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 text-slate-400">
            <div className="w-16 h-16 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center mb-3">
              <Sparkles className="w-8 h-8 text-indigo-400" />
            </div>
            <h3 className="text-base font-semibold text-white">Start talking to {settings.zoyaName}</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
              Ask anything, express how you feel, or command Android phone tasks. Speak via the mic or type below.
            </p>
          </div>
        ) : (
          messages.map((msg, idx) => {
            const isUser = msg.role === 'user';
            const badge = msg.emotion ? getEmotionBadge(msg.emotion) : null;
            const actionDetails = msg.actionTriggered ? getActionDetails(msg.actionTriggered) : null;
            const isSpeakingThis = currentlySpeakingId === msg.id;

            return (
              <div
                key={`${msg.id}-${idx}`}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} gap-1 max-w-[85%] ${
                  isUser ? 'ml-auto' : 'mr-auto'
                }`}
              >
                {/* Emotion Badge for Zoya */}
                {!isUser && badge && (
                  <div className="flex items-center gap-1.5 mb-0.5 ml-1">
                    <span
                      className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full border ${badge.bg}`}
                    >
                      <badge.icon className="w-2.5 h-2.5" />
                      {badge.label}
                    </span>
                  </div>
                )}

                {/* Message Bubble */}
                <div
                  className={`chat-message response-box p-3.5 rounded-2xl text-xs leading-relaxed tracking-tight relative shadow-md ${
                    isUser
                      ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-tr-none'
                      : 'bg-slate-800/90 text-slate-100 border border-slate-700/60 rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Android Action Card inside reply */}
                  {actionDetails && (
                    <button
                      onClick={() => onExecuteAction(actionDetails.action)}
                      className="mt-2.5 w-full flex items-center justify-between p-2 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-900/60 transition-colors text-[11px] font-semibold"
                    >
                      <div className="flex items-center gap-2">
                        <actionDetails.icon className="w-4 h-4 text-indigo-400" />
                        <span>{actionDetails.title}</span>
                      </div>
                      <ExternalLink className="w-3 h-3 text-indigo-400" />
                    </button>
                  )}

                  {/* Audio Playback Controls for Zoya's replies */}
                  {!isUser && (
                    <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-700/50 text-[10px] text-slate-400">
                      <button
                        onClick={() => {
                          if (isSpeakingThis) {
                            onStopSpeech();
                          } else {
                            onSpeakMessage(msg);
                          }
                        }}
                        className={`flex items-center gap-1 font-medium transition-colors ${
                          isSpeakingThis ? 'text-rose-400' : 'hover:text-indigo-300'
                        }`}
                      >
                        {isSpeakingThis ? (
                          <>
                            <VolumeX className="w-3 h-3" /> Stop Voice
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3 h-3 text-indigo-400" /> Play Voice
                          </>
                        )}
                      </button>

                      <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}

        {/* Thinking Indicator */}
        {isThinking && (
          <div className="flex items-center gap-2 text-slate-400 text-xs pl-2 py-1">
            <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.2s]" />
            <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.4s]" />
            <span className="text-[11px] text-slate-400 italic">{settings.zoyaName} is thinking...</span>
          </div>
        )}

        {/* Live speech interim transcript */}
        {isListening && interimTranscript && (
          <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs italic animate-pulse">
            <span className="font-semibold not-italic text-[10px] uppercase text-emerald-400 block mb-0.5">Hearing:</span>
            "{interimTranscript}"
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Bar & Controls */}
      <div className="p-3 bg-slate-900/95 border-t border-slate-800/80 backdrop-blur-xl">
        <form onSubmit={handleSend} className="flex items-center gap-2">
          {/* Voice Input Mic Button */}
          <button
            type="button"
            onClick={onToggleVoice}
            className={`p-3 rounded-full transition-all duration-200 shrink-0 ${
              isListening
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/40 animate-pulse ring-2 ring-rose-400'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
            title={isListening ? 'Stop listening' : 'Start speaking'}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={isListening ? 'Listening to your voice...' : `Message ${settings.zoyaName}...`}
              className="w-full bg-slate-950 border border-slate-800 rounded-full px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputText.trim()}
            className={`p-3 rounded-full transition-all duration-200 shrink-0 ${
              inputText.trim()
                ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
            title="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
