import React from 'react';
import { motion } from 'motion/react';
import { EmotionType } from '../types';
import { Mic, Volume2, Sparkles, Loader2 } from 'lucide-react';

interface VoiceOrbProps {
  state: 'idle' | 'listening' | 'thinking' | 'speaking';
  emotion?: EmotionType;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export const VoiceOrb: React.FC<VoiceOrbProps> = ({
  state,
  emotion = 'caring',
  onClick,
  size = 'md',
}) => {
  // Theme gradients based on emotion and state
  const getGradient = () => {
    if (state === 'listening') {
      return 'from-emerald-400 via-teal-500 to-cyan-600';
    }
    if (state === 'thinking') {
      return 'from-amber-400 via-purple-500 to-indigo-600';
    }
    if (state === 'speaking') {
      switch (emotion) {
        case 'loving':
        case 'caring':
          return 'from-rose-400 via-pink-500 to-indigo-500';
        case 'happy':
        case 'excited':
          return 'from-amber-300 via-orange-400 to-rose-500';
        case 'focused':
          return 'from-cyan-400 via-blue-500 to-indigo-600';
        case 'thoughtful':
        default:
          return 'from-violet-400 via-purple-500 to-indigo-600';
      }
    }
    // Idle state
    switch (emotion) {
      case 'loving':
      case 'caring':
        return 'from-pink-500 via-rose-500 to-purple-600';
      case 'happy':
        return 'from-amber-400 via-pink-500 to-purple-600';
      case 'focused':
        return 'from-cyan-500 via-blue-600 to-indigo-700';
      default:
        return 'from-indigo-500 via-purple-500 to-pink-500';
    }
  };

  const dimensions = {
    sm: 'w-20 h-20',
    md: 'w-36 h-36',
    lg: 'w-48 h-48',
  }[size];

  return (
    <div className="relative flex items-center justify-center cursor-pointer select-none" onClick={onClick}>
      {/* Outer Ripple Rings for active states */}
      {(state === 'listening' || state === 'speaking') && (
        <>
          <motion.div
            initial={{ scale: 0.9, opacity: 0.8 }}
            animate={{ scale: [1, 1.35, 1], opacity: [0.6, 0.15, 0.6] }}
            transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }}
            className={`absolute ${dimensions} rounded-full bg-gradient-to-r ${getGradient()} blur-xl -z-10`}
          />
          <motion.div
            initial={{ scale: 1, opacity: 0.5 }}
            animate={{ scale: [1.1, 1.55, 1.1], opacity: [0.4, 0.05, 0.4] }}
            transition={{ repeat: Infinity, duration: 2.8, ease: 'easeInOut', delay: 0.4 }}
            className={`absolute ${dimensions} rounded-full bg-gradient-to-tr ${getGradient()} blur-2xl -z-20`}
          />
        </>
      )}

      {/* Main Glowing Sphere */}
      <motion.div
        animate={{
          scale: state === 'listening' ? [1, 1.08, 1] : state === 'speaking' ? [1, 1.06, 0.98, 1.05, 1] : [1, 1.03, 1],
          rotate: state === 'thinking' ? 360 : 0,
        }}
        transition={{
          repeat: Infinity,
          duration: state === 'thinking' ? 4 : state === 'speaking' ? 1.6 : 3,
          ease: 'easeInOut',
        }}
        className={`relative ${dimensions} rounded-full p-1 bg-gradient-to-tr ${getGradient()} shadow-2xl shadow-indigo-500/30 flex items-center justify-center`}
      >
        {/* Inner Glass Layer */}
        <div className="w-full h-full rounded-full bg-[#080D1A]/70 backdrop-blur-md flex flex-col items-center justify-center p-3 border border-white/20 relative overflow-hidden">
          {/* Internal Shimmer Light */}
          <div className="absolute inset-0 bg-gradient-to-b from-white/20 via-transparent to-black/30 pointer-events-none" />

          {/* Center Indicator Icon */}
          <div className="z-10 flex flex-col items-center justify-center">
            {state === 'listening' ? (
              <div className="flex flex-col items-center">
                <Mic className="w-7 h-7 text-emerald-300 animate-pulse" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300 mt-1">Listening</span>
              </div>
            ) : state === 'thinking' ? (
              <div className="flex flex-col items-center">
                <Loader2 className="w-7 h-7 text-amber-300 animate-spin" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-300 mt-1">Thinking</span>
              </div>
            ) : state === 'speaking' ? (
              <div className="flex flex-col items-center">
                <Volume2 className="w-7 h-7 text-rose-300 animate-bounce" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-rose-300 mt-1">Speaking</span>
              </div>
            ) : (
              <div className="flex flex-col items-center text-center">
                <Sparkles className="w-7 h-7 text-indigo-200 opacity-90 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-300 mt-1">Tap to Talk</span>
              </div>
            )}
          </div>

          {/* Dynamic Audio Waves for Speaking/Listening */}
          {(state === 'speaking' || state === 'listening') && (
            <div className="absolute bottom-2 flex items-center gap-0.5 h-4">
              {[0.4, 0.8, 1, 0.6, 0.9, 0.5, 0.7].map((h, i) => (
                <motion.span
                  key={i}
                  animate={{ scaleY: [1, 2.5 * h, 0.8] }}
                  transition={{ repeat: Infinity, duration: 0.6 + i * 0.1, ease: 'easeInOut' }}
                  className="w-1 bg-white/70 rounded-full h-2 origin-center"
                />
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
