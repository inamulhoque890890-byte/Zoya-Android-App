import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mic,
  MicOff,
  Volume2,
  Play,
  Pause,
  ExternalLink,
  X,
  Sparkles,
  ChevronRight,
  Maximize2,
} from 'lucide-react';

export interface FloatingTaskState {
  id: string;
  type: 'youtube' | 'whatsapp' | 'instagram' | 'spotify' | 'maps' | 'call' | 'sms' | 'camera' | 'timer' | 'general';
  title: string;
  subtitle?: string;
  timestamp: number;
}

interface FloatingVoiceControlProps {
  isListening: boolean;
  isSpeaking: boolean;
  activeTask: FloatingTaskState | null;
  onToggleVoice: () => void;
  onReturnToApp?: () => void;
  onDismissTask?: () => void;
  zoyaName?: string;
}

export const FloatingVoiceControl: React.FC<FloatingVoiceControlProps> = ({
  isListening,
  isSpeaking,
  activeTask,
  onToggleVoice,
  onReturnToApp,
  onDismissTask,
  zoyaName = 'Zoya',
}) => {
  // Floating position coordinates (draggable within viewport)
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    // Default docked on right side, middle-upper viewport
    return {
      x: typeof window !== 'undefined' ? Math.max(16, window.innerWidth - 68) : 320,
      y: typeof window !== 'undefined' ? Math.min(220, window.innerHeight * 0.3) : 200,
    };
  });

  const [isDragging, setIsDragging] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 0,
    posY: 0,
  });

  // Re-open if a new task arrives or if listening/speaking starts
  useEffect(() => {
    if (activeTask || isListening || isSpeaking) {
      setIsDismissed(false);
    }
  }, [activeTask?.timestamp, isListening, isSpeaking]);

  // Handle window resizing
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => ({
        x: Math.min(prev.x, window.innerWidth - 64),
        y: Math.min(prev.y, window.innerHeight - 80),
      }));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Touch and mouse drag handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(false);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (e.buttons === 0) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
      setIsDragging(true);
    }
    const newX = Math.max(12, Math.min(window.innerWidth - 64, dragRef.current.posX + dx));
    const newY = Math.max(48, Math.min(window.innerHeight - 100, dragRef.current.posY + dy));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    // Snap to nearest edge (left or right) for clean docking
    if (isDragging) {
      const snapToRight = position.x > window.innerWidth / 2;
      const finalX = snapToRight ? window.innerWidth - 66 : 12;
      setPosition((prev) => ({ ...prev, x: finalX }));
      setTimeout(() => setIsDragging(false), 50);
    }
  };

  // Only display when active task exists OR media/voice is playing or listening, and not manually dismissed
  const shouldShow = (!isDismissed && (Boolean(activeTask) || isListening || isSpeaking));

  if (!shouldShow) return null;

  const isNearRight = position.x > (typeof window !== 'undefined' ? window.innerWidth / 2 : 200);

  return (
    <div
      id="zoya-floating-voice-control"
      className="fixed z-50 select-none touch-none"
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
    >
      <div className="relative flex items-center">
        {/* Expanded Task & Voice Card */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, scale: 0.85, x: isNearRight ? 10 : -10 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.85 }}
              transition={{ duration: 0.18 }}
              className={`absolute top-0 ${
                isNearRight ? 'right-14' : 'left-14'
              } w-56 bg-slate-900/95 border border-slate-700/80 rounded-2xl p-3 shadow-2xl backdrop-blur-xl text-slate-100 flex flex-col gap-2`}
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                <div className="flex items-center gap-1.5">
                  <span className="relative flex h-2 w-2">
                    <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isListening ? 'bg-emerald-400' : 'bg-pink-400'} opacity-75`} />
                    <span className={`relative inline-flex rounded-full h-2 w-2 ${isListening ? 'bg-emerald-500' : 'bg-pink-500'}`} />
                  </span>
                  <span className="text-[11px] font-bold text-white tracking-wide">{zoyaName} Assistant</span>
                </div>
                <button
                  onClick={() => setIsExpanded(false)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
                  title="Minimize"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>

              {/* Task Details */}
              {activeTask ? (
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-pink-400 tracking-wider">
                      {activeTask.type === 'youtube' ? 'YouTube Task' : activeTask.type.toUpperCase()}
                    </span>
                    <span className="text-[9px] text-slate-400">In Progress</span>
                  </div>
                  <p className="text-xs font-semibold text-slate-100 truncate">{activeTask.title}</p>
                  {activeTask.subtitle && (
                    <p className="text-[10px] text-slate-400 line-clamp-1">{activeTask.subtitle}</p>
                  )}
                </div>
              ) : (
                <div className="text-xs text-slate-300">
                  {isListening ? 'Listening for your command...' : isSpeaking ? 'Zoya is speaking...' : 'Tap mic to talk to Zoya'}
                </div>
              )}

              {/* Quick Actions */}
              <div className="flex items-center gap-1.5 pt-1 border-t border-slate-800/80">
                <button
                  onClick={onToggleVoice}
                  className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md ${
                    isListening
                      ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                >
                  {isListening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                  <span>{isListening ? 'Stop' : 'Talk'}</span>
                </button>

                {onReturnToApp && (
                  <button
                    onClick={onReturnToApp}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition-colors"
                    title="Open Main Screen"
                  >
                    <Maximize2 className="w-3 h-3" />
                  </button>
                )}

                <button
                  onClick={() => {
                    setIsDismissed(true);
                    if (onDismissTask) onDismissTask();
                  }}
                  className="p-1.5 bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-xl transition-colors"
                  title="Close Floating Control"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* The Floating Pill / Button */}
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="relative group cursor-grab active:cursor-grabbing"
        >
          {/* Subtle Outer Pulse Glow when Listening or Speaking */}
          <div
            className={`absolute -inset-1 rounded-full blur-md opacity-75 transition-all duration-300 pointer-events-none ${
              isListening
                ? 'bg-emerald-500/80 animate-ping'
                : isSpeaking
                ? 'bg-rose-500/80 animate-pulse'
                : 'bg-indigo-500/40'
            }`}
          />

          {/* Floating Pill Body */}
          <div className="relative flex items-center gap-1 bg-slate-950/90 border border-slate-700/80 rounded-full p-1 shadow-2xl backdrop-blur-md">
            {/* Miniature Zoya Anime Avatar Button */}
            <button
              onClick={() => {
                if (!isDragging) {
                  setIsExpanded(!isExpanded);
                }
              }}
              className="relative w-10 h-10 rounded-full overflow-hidden border border-pink-400/50 shadow-md shrink-0 bg-slate-900 focus:outline-none"
              title={`${zoyaName} Floating Voice Control - Tap to expand`}
            >
              <img
                src="/zoya_anime_avatar.png"
                alt={zoyaName}
                className="w-full h-full object-cover select-none pointer-events-none"
                referrerPolicy="no-referrer"
              />
              {/* Sound wave / listening badge on avatar */}
              {isSpeaking && (
                <div className="absolute inset-0 bg-rose-500/30 flex items-center justify-center">
                  <Volume2 className="w-4 h-4 text-white animate-pulse" />
                </div>
              )}
            </button>

            {/* Quick Microphone Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (!isDragging) {
                  onToggleVoice();
                }
              }}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-md focus:outline-none ${
                isListening
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white animate-pulse scale-105'
                  : 'bg-slate-800 hover:bg-slate-700 text-pink-400 hover:text-pink-300'
              }`}
              title={isListening ? 'Listening... Tap to stop' : 'Tap to speak to Zoya'}
            >
              {isListening ? (
                <Mic className="w-4 h-4 text-white" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Floating Task Label Pill (visible when active task is ongoing) */}
          {activeTask && !isExpanded && (
            <div
              onClick={() => setIsExpanded(true)}
              className={`absolute top-full mt-1 ${
                isNearRight ? 'right-0' : 'left-0'
              } px-2 py-0.5 rounded-full bg-slate-900/90 border border-slate-800 shadow-lg text-[9px] font-semibold text-slate-200 whitespace-nowrap max-w-[120px] truncate cursor-pointer flex items-center gap-1`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-ping" />
              <span className="truncate">{activeTask.title}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
