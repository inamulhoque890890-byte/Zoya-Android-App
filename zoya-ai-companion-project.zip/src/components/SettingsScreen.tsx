import React, { useState, useEffect } from 'react';
import {
  Key,
  User,
  Heart,
  Bot,
  Wrench,
  Volume2,
  Shield,
  Download,
  Check,
  AlertTriangle,
  Eye,
  EyeOff,
  Sparkles,
  Play,
  RotateCcw,
  Smartphone,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  Radio,
} from 'lucide-react';
import { AppSettings, CompanionMode, VoiceProfileType } from '../types';
import { speechController, getAllBoysVoices, BoyVoiceOption } from '../utils/speech';

interface SettingsScreenProps {
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
  hasServerKey: boolean;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onSaveSettings,
  hasServerKey,
}) => {
  const [userName, setUserName] = useState(settings.userName);
  const [zoyaName, setZoyaName] = useState(settings.zoyaName);
  const [apiKey, setApiKey] = useState(settings.geminiApiKey);
  const [showKey, setShowKey] = useState(false);
  const [selectedMode, setSelectedMode] = useState<CompanionMode>(settings.selectedMode);
  const [autoSpeak, setAutoSpeak] = useState(settings.voiceSettings.autoSpeak);
  const [wakeListening, setWakeListening] = useState(Boolean(settings.voiceSettings.wakeListening));
  const [pitch, setPitch] = useState(settings.voiceSettings.pitch);
  const [rate, setRate] = useState(settings.voiceSettings.rate);
  const [voiceURI, setVoiceURI] = useState(settings.voiceSettings.voiceURI);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [isVerifyingKey, setIsVerifyingKey] = useState(false);
  const [keyValidationMsg, setKeyValidationMsg] = useState<{ success: boolean; text: string } | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);
  const [showApkGuide, setShowApkGuide] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Dedicated Boys Voice State
  const [voiceProfile, setVoiceProfile] = useState<VoiceProfileType>(
    settings.voiceSettings.voiceProfile || 'zoya_original'
  );
  const [selectedBoyVoiceId, setSelectedBoyVoiceId] = useState<string>(
    settings.voiceSettings.selectedBoyVoiceId || 'aarav'
  );
  const [selectedBoyVoiceURI, setSelectedBoyVoiceURI] = useState<string>(
    settings.voiceSettings.selectedBoyVoiceURI || ''
  );
  const [selectedBoyVoiceName, setSelectedBoyVoiceName] = useState<string>(
    settings.voiceSettings.selectedBoyVoiceName || 'Aarav (Young Indian Boy • Energetic & Warm)'
  );
  const [selectedBoyVoicePitch, setSelectedBoyVoicePitch] = useState<number>(
    settings.voiceSettings.selectedBoyVoicePitch ?? 1.0
  );
  const [selectedBoyVoiceRate, setSelectedBoyVoiceRate] = useState<number>(
    settings.voiceSettings.selectedBoyVoiceRate ?? 1.0
  );
  const [isBoysVoiceOpen, setIsBoysVoiceOpen] = useState<boolean>(true);
  const [playingBoyVoiceId, setPlayingBoyVoiceId] = useState<string | null>(null);

  const handleDownloadProjectZip = () => {
    setIsDownloadingZip(true);
    setDownloadSuccess(false);
    try {
      const link = document.createElement('a');
      link.href = '/api/download-project-zip';
      link.download = 'zoya-ai-companion-project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => {
        setIsDownloadingZip(false);
        setDownloadSuccess(true);
        setTimeout(() => setDownloadSuccess(false), 4000);
      }, 1500);
    } catch (err) {
      console.error(err);
      window.location.href = '/zoya-project-package.zip';
      setIsDownloadingZip(false);
    }
  };

  const filterUniqueVoices = (list: SpeechSynthesisVoice[]) => {
    const seen = new Set<string>();
    return list.filter((v) => {
      const identifier = `${v.name || 'unknown'}_${v.lang || ''}_${v.voiceURI || ''}`;
      if (seen.has(identifier)) return false;
      seen.add(identifier);
      return true;
    });
  };

  useEffect(() => {
    const voices = speechController.getVoices();
    if (voices.length > 0) {
      setAvailableVoices(filterUniqueVoices(voices));
    } else {
      speechController.onVoicesAvailable((v) => setAvailableVoices(filterUniqueVoices(v)));
    }
  }, []);

  const allBoysVoices = getAllBoysVoices(availableVoices);

  const handlePreviewBoyVoice = (voice: BoyVoiceOption) => {
    if (playingBoyVoiceId === voice.id) {
      speechController.stop();
      setPlayingBoyVoiceId(null);
      return;
    }

    setPlayingBoyVoiceId(voice.id);
    speechController.previewVoice(
      voice.samplePhrase,
      voice.pitch,
      voice.rate,
      voice.voiceURI,
      voice.lang,
      () => setPlayingBoyVoiceId(null),
      () => setPlayingBoyVoiceId(null)
    );
  };

  const handleSelectBoyVoice = (voice: BoyVoiceOption) => {
    setSelectedBoyVoiceId(voice.id);
    setSelectedBoyVoiceURI(voice.voiceURI || '');
    setSelectedBoyVoiceName(voice.name);
    setSelectedBoyVoicePitch(voice.pitch);
    setSelectedBoyVoiceRate(voice.rate);
    setVoiceProfile('boys_voice');
  };

  const handleSwitchToZoyaVoice = () => {
    setVoiceProfile('zoya_original');
  };

  const handleSaveAll = () => {
    const updated: AppSettings = {
      ...settings,
      userName: userName.trim() || 'User',
      zoyaName: zoyaName.trim() || 'Zoya',
      geminiApiKey: apiKey.trim(),
      selectedMode,
      voiceSettings: {
        ...settings.voiceSettings,
        autoSpeak,
        wakeListening,
        pitch,
        rate,
        voiceURI: voiceProfile === 'boys_voice' && selectedBoyVoiceURI ? selectedBoyVoiceURI : voiceURI,
        voiceProfile,
        selectedBoyVoiceId,
        selectedBoyVoiceURI,
        selectedBoyVoiceName,
        selectedBoyVoicePitch,
        selectedBoyVoiceRate,
      },
    };
    onSaveSettings(updated);
    setSaveSuccessMsg(true);
    setTimeout(() => setSaveSuccessMsg(false), 3000);
  };

  const handleTestKey = async () => {
    if (!apiKey.trim()) {
      setKeyValidationMsg({ success: false, text: 'Please enter a Gemini API key first.' });
      return;
    }
    setIsVerifyingKey(true);
    setKeyValidationMsg(null);
    try {
      const res = await fetch('/api/validate-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: apiKey.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setKeyValidationMsg({ success: true, text: data.message || 'Valid! Gemini API key verified successfully.' });
      } else {
        setKeyValidationMsg({ success: false, text: data.error || 'Key validation failed.' });
      }
    } catch (err: any) {
      setKeyValidationMsg({ success: false, text: err.message || 'Verification network error' });
    } finally {
      setIsVerifyingKey(false);
    }
  };

  const handleRemoveKey = () => {
    setApiKey('');
    const updated: AppSettings = {
      ...settings,
      geminiApiKey: '',
    };
    onSaveSettings(updated);
    setKeyValidationMsg({ success: true, text: 'API Key removed. Fallback server key active.' });
    setTimeout(() => setKeyValidationMsg(null), 3000);
  };

  const handleTestVoice = () => {
    setIsTestingVoice(true);

    if (voiceProfile === 'boys_voice') {
      const boyText = `Hey ${userName}! I'm speaking with the ${selectedBoyVoiceName || 'Boys'} voice. All voice functions are active and ready!`;
      speechController.speak(
        boyText,
        {
          ...settings.voiceSettings,
          autoSpeak: true,
          voiceProfile: 'boys_voice',
          selectedBoyVoiceId,
          selectedBoyVoiceURI,
          selectedBoyVoicePitch,
          selectedBoyVoiceRate,
        },
        'focused',
        () => setIsTestingVoice(false),
        () => setIsTestingVoice(false)
      );
    } else {
      const testText =
        selectedMode === 'girlfriend'
          ? `Hello ${userName}! I'm ${zoyaName}. It feels wonderful talking with you in my original voice.`
          : `Hello ${userName}, this is ${zoyaName}, your personal AI assistant. Original voice test complete.`;

      speechController.speak(
        testText,
        {
          ...settings.voiceSettings,
          autoSpeak: true,
          pitch,
          rate,
          voiceURI,
          voiceProfile: 'zoya_original',
        },
        selectedMode === 'girlfriend' ? 'loving' : 'focused',
        () => setIsTestingVoice(false),
        () => setIsTestingVoice(false)
      );
    }
  };

  return (
    <div className="w-full pb-28 px-4 pt-2 flex flex-col gap-4 animate-fade-in max-w-md mx-auto">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 rounded-2xl p-4 backdrop-blur-md">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">Settings & Preferences</h2>
          <p className="text-xs text-slate-400">Configure AI model, voices, names, and Android features</p>
        </div>
        <button
          onClick={handleSaveAll}
          className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 flex items-center gap-1.5 transition-all active:scale-95"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Save</span>
        </button>
      </div>

      {saveSuccessMsg && (
        <div className="p-3 bg-emerald-600 text-white rounded-xl text-xs font-semibold flex items-center justify-between shadow-lg animate-fade-in">
          <span>Settings saved successfully!</span>
          <Check className="w-4 h-4" />
        </div>
      )}

      {/* 1. User & Zoya Identity Section */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
        <div className="flex items-center gap-2 text-indigo-400 pb-1 border-b border-slate-800">
          <User className="w-4 h-4" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">Identity & Names</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-[11px] font-medium text-slate-300 block mb-1">Your Name</label>
            <input
              type="text"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="e.g. Alex"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium text-slate-300 block mb-1">AI Assistant Name</label>
            <input
              type="text"
              value={zoyaName}
              onChange={(e) => setZoyaName(e.target.value)}
              placeholder="Zoya"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* 2. Companion Modes Section */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
        <div className="flex items-center gap-2 text-indigo-400 pb-1 border-b border-slate-800">
          <Sparkles className="w-4 h-4" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">Companion Mode</h3>
        </div>

        <div className="grid grid-cols-1 gap-2">
          {/* Mode 1: Girlfriend */}
          <div
            onClick={() => setSelectedMode('girlfriend')}
            className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
              selectedMode === 'girlfriend'
                ? 'bg-rose-950/40 border-rose-500/60 shadow-md shadow-rose-500/10'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="p-2 rounded-lg bg-rose-500/20 text-rose-300 mt-0.5">
              <Heart className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Girlfriend Mode</span>
                {selectedMode === 'girlfriend' && (
                  <span className="text-[10px] font-semibold text-rose-400 bg-rose-950 px-2 py-0.5 rounded-full border border-rose-500/40">
                    Active
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                Warm, deeply caring, emotionally expressive and supportive conversation.
              </p>
            </div>
          </div>

          {/* Mode 2: Normal */}
          <div
            onClick={() => setSelectedMode('normal')}
            className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
              selectedMode === 'normal'
                ? 'bg-indigo-950/40 border-indigo-500/60 shadow-md shadow-indigo-500/10'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-300 mt-0.5">
              <Bot className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Normal Mode</span>
                {selectedMode === 'normal' && (
                  <span className="text-[10px] font-semibold text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded-full border border-indigo-500/40">
                    Active
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                Friendly, balanced, everyday conversational AI companion.
              </p>
            </div>
          </div>

          {/* Mode 3: Assistant */}
          <div
            onClick={() => setSelectedMode('assistant')}
            className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
              selectedMode === 'assistant'
                ? 'bg-cyan-950/40 border-cyan-500/60 shadow-md shadow-cyan-500/10'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-300 mt-0.5">
              <Wrench className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Assistant Mode</span>
                {selectedMode === 'assistant' && (
                  <span className="text-[10px] font-semibold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-500/40">
                    Active
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                Concise, practical behavior with direct Android phone action shortcuts.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Gemini AI Integration Section */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
          <div className="flex items-center gap-2 text-indigo-400">
            <Key className="w-4 h-4" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">Gemini AI Key</h3>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            {apiKey ? 'Custom Key' : hasServerKey ? 'Default Server Key Active' : 'No Key Set'}
          </span>
        </div>

        <p className="text-[11px] text-slate-400 leading-relaxed">
          You can provide your personal Google Gemini API key. Keys are saved locally on your device and are never hard-coded.
        </p>

        <div className="relative">
          <input
            type={showKey ? 'text' : 'password'}
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="AIzaSy..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono pr-10"
          />
          <button
            type="button"
            onClick={() => setShowKey(!showKey)}
            className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
          >
            {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>

        {/* Action Buttons for Key */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={handleTestKey}
            disabled={isVerifyingKey || !apiKey.trim()}
            className="flex-1 py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isVerifyingKey ? 'Testing Connection...' : 'Test API Key'}
          </button>

          {apiKey && (
            <button
              onClick={handleRemoveKey}
              className="py-1.5 px-3 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 text-xs font-semibold border border-rose-500/30 transition-colors"
            >
              Remove
            </button>
          )}
        </div>

        {keyValidationMsg && (
          <div
            className={`p-2.5 rounded-xl text-xs flex items-center gap-2 ${
              keyValidationMsg.success
                ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                : 'bg-rose-950/60 text-rose-300 border border-rose-500/30'
            }`}
          >
            {keyValidationMsg.success ? (
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span className="leading-snug">{keyValidationMsg.text}</span>
          </div>
        )}
      </div>

      {/* 4. Voice & Speech Synthesis Settings */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
          <div className="flex items-center gap-2 text-indigo-400">
            <Volume2 className="w-4 h-4" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">Voice & Speech Output</h3>
          </div>
          <button
            onClick={handleTestVoice}
            disabled={isTestingVoice}
            className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
          >
            <Play className="w-3 h-3" /> Test Voice
          </button>
        </div>

        {/* Auto-speak toggle */}
        <div className="flex items-center justify-between py-1">
          <div>
            <span className="text-xs font-semibold text-white">Speak Replies Aloud</span>
            <p className="text-[10px] text-slate-400">Zoya automatically speaks her replies via TTS</p>
          </div>
          <button
            onClick={() => setAutoSpeak(!autoSpeak)}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              autoSpeak ? 'bg-indigo-600' : 'bg-slate-800'
            }`}
          >
            <span
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                autoSpeak ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Continuous "Hey Zoya" Wake Listening toggle */}
        <div className="flex items-center justify-between py-1 pt-2 border-t border-slate-800/80">
          <div>
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <span>Wake Listening ("Hey Zoya")</span>
              <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${wakeListening ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>
                {wakeListening ? 'ACTIVE' : 'OFF'}
              </span>
            </span>
            <p className="text-[10px] text-slate-400">
              Continuously listens for "Hey Zoya" in foreground and background service
            </p>
          </div>
          <button
            onClick={() => setWakeListening(!wakeListening)}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              wakeListening ? 'bg-emerald-500' : 'bg-slate-800'
            }`}
          >
            <span
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                wakeListening ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Voice Selector */}
        {availableVoices.length > 0 && (
          <div>
            <label className="text-[11px] font-medium text-slate-300 block mb-1">Spoken Voice</label>
            <select
              value={voiceURI}
              onChange={(e) => setVoiceURI(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="">Default Soft Feminine Voice (Auto-selected)</option>
              {availableVoices
                .map((v, idx) => {
                  const isFeminine = /female|zira|samantha|karen|victoria|natural|neural|serena|swara|tanisha|jenny|aria|ava|emma/i.test(
                    v.name
                  );
                  return (
                    <option key={`voice-opt-${idx}-${v.voiceURI || v.name}`} value={v.voiceURI}>
                      {v.name} ({v.lang}){isFeminine ? ' • Feminine' : ''}
                    </option>
                  );
                })}
            </select>
          </div>
        )}

        {/* Pitch & Rate Sliders */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Pitch</span>
              <span className="text-slate-200 font-mono">{pitch.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.85"
              max="1.15"
              step="0.05"
              value={pitch}
              onChange={(e) => setPitch(parseFloat(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Speed</span>
              <span className="text-slate-200 font-mono">{rate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.80"
              max="1.25"
              step="0.05"
              value={rate}
              onChange={(e) => setRate(parseFloat(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* 5. Dedicated Boys Voice Selection Option: Settings → Boys Voice */}
      <div id="settings-boys-voice-section" className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
        <div
          onClick={() => setIsBoysVoiceOpen(!isBoysVoiceOpen)}
          className="flex items-center justify-between pb-1 border-b border-slate-800 cursor-pointer select-none group"
        >
          <div className="flex items-center gap-2">
            <span className="text-sm">👦</span>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider group-hover:text-indigo-400 transition-colors">
                  Settings → Boys Voice
                </h3>
              </div>
              <span className="text-[10px] text-slate-400">
                Select from all boy & male voice options
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold border transition-colors ${
                voiceProfile === 'boys_voice'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
              }`}
            >
              {voiceProfile === 'boys_voice' ? '👦 Boys Voice Active' : "🌸 Zoya Original Active"}
            </span>
            {isBoysVoiceOpen ? (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronRight className="w-4 h-4 text-slate-400" />
            )}
          </div>
        </div>

        {isBoysVoiceOpen && (
          <div className="flex flex-col gap-3.5 pt-1 animate-fade-in">
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Audition and choose any Boys voice below. Selecting a Boys voice will not delete Zoya's original voice—you can switch back to Zoya's original voice at any time with a single tap.
            </p>

            {/* Active Voice Selection Mode: Zoya Original vs Boys Voice */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Option A: Zoya Original Voice */}
              <div
                onClick={handleSwitchToZoyaVoice}
                className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                  voiceProfile === 'zoya_original'
                    ? 'bg-indigo-950/40 border-indigo-500/70 shadow-md shadow-indigo-500/10 ring-1 ring-indigo-500/40'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🌸</span>
                    <div>
                      <span className="text-xs font-bold text-white block">Zoya's Original Voice</span>
                      <span className="text-[10px] text-indigo-300">Warm, Soft & Feminine</span>
                    </div>
                  </div>
                  {voiceProfile === 'zoya_original' ? (
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/40 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Active
                    </span>
                  ) : (
                    <span className="text-[10px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                      Switch
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-2 leading-relaxed">
                  Zoya's signature soft, empathetic conversational female voice.
                </p>
              </div>

              {/* Option B: Boys Voice */}
              <div
                onClick={() => setVoiceProfile('boys_voice')}
                className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                  voiceProfile === 'boys_voice'
                    ? 'bg-amber-950/40 border-amber-500/70 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/40'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-base">👦</span>
                    <div>
                      <span className="text-xs font-bold text-white block">Boys Voice</span>
                      <span className="text-[10px] text-amber-300">
                        {selectedBoyVoiceName ? selectedBoyVoiceName.split('•')[0].trim() : 'Masculine & Youthful'}
                      </span>
                    </div>
                  </div>
                  {voiceProfile === 'boys_voice' ? (
                    <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/40 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Active
                    </span>
                  ) : (
                    <span className="text-[10px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                      Switch
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-2 leading-relaxed">
                  Energetic, brotherly, calm, and youth masculine tones.
                </p>
              </div>
            </div>

            {/* Quick Switch-Back Action Bar */}
            {voiceProfile === 'boys_voice' && (
              <div className="bg-slate-950/90 border border-indigo-500/30 rounded-xl p-3 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-2 text-slate-300 text-xs">
                  <span className="text-sm">🌸</span>
                  <span className="font-medium">Currently using Boys Voice.</span>
                </div>
                <button
                  type="button"
                  onClick={handleSwitchToZoyaVoice}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Switch back to Zoya's original voice</span>
                </button>
              </div>
            )}

            {/* Complete List of Available Boys Voices */}
            <div className="flex flex-col gap-2.5 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <span>Available Boys Voices ({allBoysVoices.length})</span>
                </span>
                <span className="text-[10px] text-slate-400">Tap Play to hear • Tap Select to use</span>
              </div>

              <div className="flex flex-col gap-2 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
                {allBoysVoices.map((voice) => {
                  const isSelected = selectedBoyVoiceId === voice.id && voiceProfile === 'boys_voice';
                  const isPlayingThis = playingBoyVoiceId === voice.id;

                  return (
                    <div
                      key={`boy-voice-card-${voice.id}`}
                      className={`p-3 rounded-xl border transition-all flex flex-col gap-2 ${
                        isSelected
                          ? 'bg-amber-950/30 border-amber-500/70 shadow-sm shadow-amber-500/10 ring-1 ring-amber-500/30'
                          : 'bg-slate-950/70 border-slate-800/90 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm shrink-0 mt-0.5 ${
                            isSelected ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-300'
                          }`}>
                            👦
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-bold text-white">{voice.name}</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-amber-300 font-medium border border-slate-700">
                                {voice.tag}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400 block mt-0.5">{voice.subtitle}</span>
                          </div>
                        </div>

                        {/* Play/Preview Button */}
                        <button
                          type="button"
                          onClick={() => handlePreviewBoyVoice(voice)}
                          className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-all shrink-0 active:scale-95 ${
                            isPlayingThis
                              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30 animate-pulse'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                          }`}
                        >
                          <Play className={`w-3 h-3 ${isPlayingThis ? 'fill-current' : ''}`} />
                          <span>{isPlayingThis ? 'Playing...' : 'Play'}</span>
                        </button>
                      </div>

                      <p className="text-[10px] text-slate-400 italic bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-800/60">
                        "{voice.samplePhrase}"
                      </p>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-800/60">
                        <span className="text-[10px] text-slate-500 font-mono">
                          Pitch: {voice.pitch.toFixed(2)}x • Speed: {voice.rate.toFixed(2)}x
                        </span>

                        {/* Select Button */}
                        <button
                          type="button"
                          onClick={() => handleSelectBoyVoice(voice)}
                          className={`px-3 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-all active:scale-95 ${
                            isSelected
                              ? 'bg-amber-500 text-slate-950 shadow-sm font-bold'
                              : 'bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30'
                          }`}
                        >
                          {isSelected ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Selected</span>
                            </>
                          ) : (
                            <span>Select Voice</span>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Direct Save Button inside Boys Voice section */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleSaveAll}
                  className="w-full py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 flex items-center justify-center gap-1.5 transition-all active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  <span>Save Voice Selection</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 6. Android APK & Project Package Export */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-md">
        <div className="flex items-center justify-between text-indigo-400 pb-1 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">Android APK & Project Package</h3>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
            ZIP Ready
          </span>
        </div>

        <p className="text-[11px] text-slate-300 leading-relaxed">
          Download the updated full source code package, including the Android Studio project, transparent assets, build configs, and instructions for APK generation.
        </p>

        {/* Prominent Download Project & APK ZIP Button */}
        <button
          onClick={handleDownloadProjectZip}
          disabled={isDownloadingZip}
          className="w-full p-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all active:scale-98 disabled:opacity-75"
        >
          {isDownloadingZip ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Packaging Project ZIP...</span>
            </>
          ) : downloadSuccess ? (
            <>
              <Check className="w-4 h-4 text-emerald-300" />
              <span>Downloaded Successfully!</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Download Project & APK Package (ZIP)</span>
            </>
          )}
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              if ((window as any).deferredPrompt) {
                (window as any).deferredPrompt.prompt();
              } else {
                alert("To install on Android: Tap Chrome's menu (⋮) -> 'Install App' or 'Add to Home screen'.");
              }
            }}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5"
          >
            <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
            <span>Install on Android</span>
          </button>

          <button
            onClick={() => setShowApkGuide(!showApkGuide)}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>{showApkGuide ? 'Hide Guide' : 'APK Build Guide'}</span>
          </button>
        </div>

        {showApkGuide && (
          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-300 space-y-2 mt-1">
            <h4 className="font-bold text-white text-xs">How to Build the Final Android APK:</h4>
            <ol className="list-decimal pl-4 space-y-2 text-slate-400">
              <li>
                <strong className="text-slate-200">Option 1 (Android Studio Native APK):</strong>
                <p className="mt-0.5 text-slate-300">
                  Unzip the downloaded package, open the <code className="text-indigo-300">android/</code> folder in Android Studio, and select <em>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</em>.
                </p>
              </li>
              <li>
                <strong className="text-slate-200">Option 2 (Google Bubblewrap CLI):</strong>
                <pre className="bg-slate-900 p-2 rounded text-[10px] text-indigo-300 font-mono mt-1 overflow-x-auto">
npm run build{'\n'}
npx @bubblewrap/cli init --manifest=public/manifest.json{'\n'}
npx @bubblewrap/cli build
                </pre>
                This generates <code className="text-white">app-release-signed.apk</code> ready to install on any Android phone.
              </li>
              <li>
                <strong className="text-slate-200">Option 3 (Instant Android PWA):</strong> In Android Chrome or Samsung Internet, tap the browser menu (⋮) and tap <em>"Install App"</em>.
              </li>
            </ol>
          </div>
        )}
      </div>
    </div>
  );
};
