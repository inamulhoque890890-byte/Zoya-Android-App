# Zoya AI Companion - Android APK & Project Deployment Guide

This package contains the complete source code, configuration files, and Android native project structure for Zoya AI Companion.

---

## 1. Project Manifest & Checklist Verification

| Item | Status & Location | Description |
|---|---|---|
| **Environment Configuration** | `.env` & `.env.example` | Pre-configured with `GEMINI_API_KEY`, `PORT=3000`, and signing credentials. |
| **Dependency Manifest** | `package.json` | Node 18+/20+ dependencies: React 19, Vite, Express, Lucide, Tailwind CSS. |
| **Android Signing Keystore** | `android/app/keystore.jks` | Official release signing key (alias: `zoyakey`, password: `zoya123456`). |
| **Native Android Sources** | `android/app/src/main/java/` | `MainActivity.kt`, `AndroidBridge.kt`, `ZoyaWakeListeningService.kt`. |
| **Android Manifest & Assets** | `android/app/src/main/` | `AndroidManifest.xml`, security config, high-res mipmap app icons. |
| **Web UI & State Engine** | `src/` | Complete React TypeScript components, speech synthesizers, anime avatar. |
| **Automated APK Workflow** | `.github/workflows/build-apk.yml` | Pre-configured GitHub Actions workflow to build and upload APKs. |

---

## 2. Quick Start (Web & Local Testing)

1. Install dependencies:
   ```bash
   npm install
   ```

2. Configure environment variables in `.env`:
   ```env
   GEMINI_API_KEY="your-gemini-api-key-here"
   PORT=3000
   APP_URL="http://localhost:3000"
   ```

3. Start local development server:
   ```bash
   npm run dev
   ```
   Open http://localhost:3000 in your browser.

---

## 3. Building the Android APK

### Option A: Automatic Build via GitHub Actions (Zero Setup)
1. Push this repository to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Zoya AI Assistant"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
2. Navigate to the **Actions** tab on your GitHub repo.
3. The **Build Zoya Android APK** workflow will automatically run.
4. Download the signed **Zoya-Assistant-Release-APK** or **Zoya-Assistant-Debug-APK** directly from GitHub workflow artifacts!

### Option B: Local Build via Android Studio
1. Open the `android` directory in Android Studio.
2. Gradle will automatically sync project dependencies (target SDK 34, Java 17).
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The output APK will be placed at:
   - Debug APK: `android/app/build/outputs/apk/debug/app-debug.apk`
   - Signed Release APK: `android/app/build/outputs/apk/release/app-release.apk`

### Option C: Local Command Line Build (Terminal)
```bash
# 1. Compile web bundle and copy to Android assets
npm run build:android

# 2. Build Debug or Signed Release APK with Gradle Wrapper
cd android
chmod +x ./gradlew

# Build Debug APK:
./gradlew assembleDebug

# Build Official Signed Release APK (signed with keystore.jks):
./gradlew assembleRelease
```

---

## 4. Keystore & Signing Details

- **Keystore File**: `android/app/keystore.jks`
- **Key Alias**: `zoyakey`
- **Keystore Password**: `zoya123456`
- **Key Password**: `zoya123456`
- **Configured in**: `android/app/build.gradle` (under `signingConfigs.release`)
