package com.zoya.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.regex.Pattern

/**
 * Android Foreground Service for continuous background "Hey Zoya" wake word detection.
 * Maintains microphone listening with minimal resource overhead and rapid voice trigger.
 */
class ZoyaWakeListeningService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var shouldKeepListening = true
    private var isDestroyed = false

    companion object {
        const val TAG = "ZoyaWakeService"
        const val CHANNEL_ID = "zoya_wake_listening_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.zoya.assistant.action.START_WAKE_LISTENING"
        const val ACTION_STOP = "com.zoya.assistant.action.STOP_WAKE_LISTENING"
        const val EXTRA_WAKE_QUERY = "com.zoya.assistant.extra.WAKE_QUERY"

        @Volatile
        var isServiceRunning = false

        fun startService(context: Context) {
            val intent = Intent(context, ZoyaWakeListeningService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, ZoyaWakeListeningService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopWakeListening()
            stopSelf()
            return START_NOT_STICKY
        }

        shouldKeepListening = true
        isDestroyed = false
        startAsForeground()
        initAndStartRecognizer()
        isServiceRunning = true

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Zoya Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Zoya voice listening active for 'Hey Zoya'"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startAsForeground() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Zoya is Listening")
            .setContentText("Say \"Hey Zoya\" to chat or give a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initAndStartRecognizer() {
        mainHandler.post {
            if (isDestroyed || !shouldKeepListening) return@post

            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            isListening = true
                        }

                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            isListening = false
                        }

                        override fun onError(error: Int) {
                            isListening = false
                            // Re-arm listener after a short pause
                            scheduleRestart(if (error == SpeechRecognizer.ERROR_NO_MATCH) 200 else 800)
                        }

                        override fun onResults(results: Bundle?) {
                            isListening = false
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            checkMatchesForWakeWord(matches)
                            scheduleRestart(250)
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val triggered = checkMatchesForWakeWord(matches)
                            if (triggered) {
                                try {
                                    speechRecognizer?.stopListening()
                                } catch (e: Exception) {
                                    // ignore
                                }
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }

                startListeningInternal()
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing wake recognizer: ${e.message}")
                scheduleRestart(1500)
            }
        }
    }

    private fun startListeningInternal() {
        if (!shouldKeepListening || isDestroyed) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speechRecognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            Log.w(TAG, "startListeningInternal failed: ${e.message}")
            scheduleRestart(1000)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (!shouldKeepListening || isDestroyed) return
        mainHandler.postDelayed({
            if (shouldKeepListening && !isDestroyed && !isListening) {
                startListeningInternal()
            }
        }, delayMs)
    }

    private fun checkMatchesForWakeWord(matches: List<String>?): Boolean {
        if (matches.isNullOrEmpty()) return false

        val wakePattern = Pattern.compile("\\b(hey|hi|hello|ok|okay)?\\s*zoya\\b", Pattern.CASE_INSENSITIVE)

        for (text in matches) {
            val matcher = wakePattern.matcher(text)
            if (matcher.find()) {
                val matchEnd = matcher.end()
                val query = if (matchEnd < text.length) text.substring(matchEnd).trim() else ""
                val cleanQuery = query.replace(Regex("^[,.?! ]+"), "").trim()

                Log.d(TAG, "Wake word matched in background service: '$text' -> Query: '$cleanQuery'")
                handleWakeWordTriggered(cleanQuery)
                return true
            }
        }
        return false
    }

    private fun handleWakeWordTriggered(query: String) {
        // Haptic feedback
        vibrateOnWake()

        // Bring MainActivity to front or deliver intent
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra(EXTRA_WAKE_QUERY, query)
        }
        startActivity(launchIntent)

        // Also notify direct active bridge if available
        MainActivity.activeInstance?.onWakeWordDetected(query)
    }

    private fun vibrateOnWake() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 40, 50, 70), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 40, 50, 70), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(100L)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibration on wake failed: ${e.message}")
        }
    }

    private fun stopWakeListening() {
        shouldKeepListening = false
        isServiceRunning = false
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.destroy()
                speechRecognizer = null
                isListening = false
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping recognizer: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        isDestroyed = true
        stopWakeListening()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
