# Proguard rules for Zoya AI Assistant

# Keep JavaScript Interface methods so ProGuard does not obfuscate or strip them
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.zoya.assistant.AndroidBridge {
    public *;
}

-keepattributes JavascriptInterface
-keepattributes *Annotation*
